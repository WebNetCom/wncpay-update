<?php
/**
 * Analytics bridge — v0.13.0.
 *
 * Hands the platform's GA4-style events (view_item, add_to_cart, begin_checkout,
 * purchase, generate_lead…) from the embedded frames to THIS site's dataLayer, so the
 * site's own Google Tag Manager container sees them as native events. Optionally
 * injects the GTM container itself (when no other plugin does), passes the visitor's
 * ad-click ids + GA client id into the frames for server-side attribution, and gives
 * the marketing / SEO team their own settings screen + WordPress role.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Analytics
 */
final class WNCPAY_Analytics {

	public const OPTION     = 'wncpay_analytics';
	public const CAP        = 'wncpay_manage_analytics';
	public const ROLE       = 'wncpay_marketing';
	public const COOKIE     = 'wncpay_attr';
	public const PAGE       = 'wncpay-analytics';

	/** Event → group (mirrors the platform). Unknown events pass through. */
	private const GROUPS = [
		'view_item_list' => 'catalog', 'view_item' => 'catalog', 'select_item' => 'catalog',
		'add_to_cart' => 'cart', 'remove_from_cart' => 'cart', 'view_cart' => 'cart',
		'begin_checkout' => 'checkout', 'add_payment_info' => 'checkout',
		'purchase' => 'purchase', 'refund' => 'purchase', 'balance_payment' => 'purchase',
		'generate_lead' => 'leads', 'sign_up' => 'leads', 'quote_viewed' => 'leads', 'quote_accepted' => 'leads', 'cfc_signed' => 'leads', 'gift_designer_start' => 'leads',
		'whatsapp_click' => 'engagement', 'phone_click' => 'engagement',
		'virtual_page_view' => 'pageviews',
	];

	private const GROUP_LABELS = [
		'catalog'    => 'Catalog — view_item_list, view_item, select_item',
		'cart'       => 'Quote basket — add_to_cart, remove_from_cart, view_cart',
		'checkout'   => 'Checkout — begin_checkout, add_payment_info',
		'purchase'   => 'Money — purchase, balance_payment, refund',
		'leads'      => 'Leads — generate_lead, quote_viewed, quote_accepted, cfc_signed, gift_designer_start',
		'engagement' => 'Engagement inside the frames — whatsapp_click, phone_click',
		'pageviews'  => 'In-frame navigation — virtual_page_view',
	];

	public function __construct() {
		add_action( 'init', [ $this, 'ensure_role' ] );
		add_action( 'admin_menu', [ $this, 'register_page' ] );
		add_action( 'admin_init', [ $this, 'register_settings' ] );
		add_action( 'wp_head', [ $this, 'print_head' ], 1 );
		add_action( 'wp_body_open', [ $this, 'print_noscript' ], 1 );
		add_action( 'wp_footer', [ $this, 'print_bridge' ], 6 );
	}

	// ── Options ──────────────────────────────────────────────────────────────

	/**
	 * Defaults.
	 *
	 * @return array
	 */
	public static function defaults(): array {
		return [
			'enabled'        => '1',
			'container_mode' => 'datalayer', // off | inject | datalayer
			'gtm_id'         => '',
			'datalayer'      => 'dataLayer',
			'groups'         => [ 'catalog', 'cart', 'checkout', 'purchase', 'leads', 'engagement', 'pageviews' ],
			'attribution'    => '1',
			'host_clicks'    => '',
			'debug'          => '',
		];
	}

	/**
	 * Read an option (with defaults).
	 *
	 * @param string $key Key.
	 * @return mixed
	 */
	public static function opt( string $key ) {
		$o = get_option( self::OPTION, [] );
		$d = self::defaults();
		return is_array( $o ) && array_key_exists( $key, $o ) ? $o[ $key ] : ( $d[ $key ] ?? '' );
	}

	/**
	 * Whether the bridge is on (needs a platform origin too).
	 */
	public static function enabled(): bool {
		return '1' === (string) self::opt( 'enabled' ) && '' !== WNCPAY_Embed::platform_origin();
	}

	/**
	 * Sanitize.
	 *
	 * @param mixed $in Raw.
	 * @return array
	 */
	public function sanitize( $in ): array {
		$in  = is_array( $in ) ? $in : [];
		$out = self::defaults();
		$out['enabled']        = ! empty( $in['enabled'] ) ? '1' : '';
		$mode                  = isset( $in['container_mode'] ) ? (string) $in['container_mode'] : 'datalayer';
		$out['container_mode'] = in_array( $mode, [ 'off', 'inject', 'datalayer' ], true ) ? $mode : 'datalayer';
		$gtm                   = strtoupper( trim( (string) ( $in['gtm_id'] ?? '' ) ) );
		$out['gtm_id']         = preg_match( '/^GTM-[A-Z0-9]{4,12}$/', $gtm ) ? $gtm : '';
		$dl                    = trim( (string) ( $in['datalayer'] ?? 'dataLayer' ) );
		$out['datalayer']      = preg_match( '/^[A-Za-z_$][\w$]{0,40}$/', $dl ) ? $dl : 'dataLayer';
		$groups                = isset( $in['groups'] ) && is_array( $in['groups'] ) ? array_map( 'sanitize_key', $in['groups'] ) : [];
		$out['groups']         = array_values( array_intersect( array_keys( self::GROUP_LABELS ), $groups ) );
		$out['attribution']    = ! empty( $in['attribution'] ) ? '1' : '';
		$out['host_clicks']    = ! empty( $in['host_clicks'] ) ? '1' : '';
		$out['debug']          = ! empty( $in['debug'] ) ? '1' : '';
		return $out;
	}

	// ── Role / capability ────────────────────────────────────────────────────

	/**
	 * Administrators get the capability; a dedicated "Marketing / SEO" role exists so an
	 * external person can edit ONLY this screen. Runs once per plugin version.
	 */
	public function ensure_role(): void {
		if ( get_option( 'wncpay_analytics_role_v' ) === WNCPAY_VERSION ) {
			return;
		}
		$admin = get_role( 'administrator' );
		if ( $admin && ! $admin->has_cap( self::CAP ) ) {
			$admin->add_cap( self::CAP );
		}
		if ( ! get_role( self::ROLE ) ) {
			add_role( self::ROLE, 'Marketing / SEO (WNC Pay)', [ 'read' => true, self::CAP => true ] );
		} else {
			get_role( self::ROLE )->add_cap( self::CAP );
		}
		update_option( 'wncpay_analytics_role_v', WNCPAY_VERSION, false );
	}

	// ── Admin screen ─────────────────────────────────────────────────────────

	public function register_page(): void {
		add_options_page( __( 'WNC Pay Analytics', 'wncpay' ), __( 'WNC Pay Analytics', 'wncpay' ), self::CAP, self::PAGE, [ $this, 'render_page' ] );
	}

	public function register_settings(): void {
		register_setting( 'wncpay_analytics', self::OPTION, [ 'type' => 'array', 'sanitize_callback' => [ $this, 'sanitize' ], 'default' => self::defaults() ] );
	}

	/**
	 * Platform's public analytics config (read-only display), cached 5 minutes.
	 *
	 * @return array|null
	 */
	private function platform_config(): ?array {
		$base = WNCPAY_Embed::platform_url();
		if ( '' === $base ) {
			return null;
		}
		$key = 'wncpay_analytics_cfg';
		$c   = get_transient( $key );
		if ( is_array( $c ) ) {
			return $c;
		}
		$res = wp_remote_get( $base . '/api/analytics/config', [ 'timeout' => 6 ] );
		if ( is_wp_error( $res ) || 200 !== wp_remote_retrieve_response_code( $res ) ) {
			return null;
		}
		$j = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( ! is_array( $j ) ) {
			return null;
		}
		set_transient( $key, $j, 5 * MINUTE_IN_SECONDS );
		return $j;
	}

	/**
	 * GTM4WP's own settings (container id + dataLayer variable), when it is active.
	 * Same option keys in GTM4WP 1.x and 2.x ('gtm4wp-options' → 'gtm-code',
	 * 'gtm-datalayer-variable-name'), so the bridge follows whatever the SEO team
	 * configured there and the two plugins can never disagree on the dataLayer name.
	 *
	 * @return array{version:string,gtm_id:string,datalayer:string}|array{}
	 */
	public static function gtm4wp_settings(): array {
		if ( ! defined( 'GTM4WP_VERSION' ) && ! function_exists( 'gtm4wp_the_gtm_tag' ) ) {
			return [];
		}
		$o  = get_option( 'gtm4wp-options', [] );
		$o  = is_array( $o ) ? $o : [];
		$dl = isset( $o['gtm-datalayer-variable-name'] ) ? trim( (string) $o['gtm-datalayer-variable-name'] ) : '';
		if ( ! preg_match( '/^[A-Za-z_$][\w$]{0,40}$/', $dl ) ) {
			$dl = 'dataLayer';
		}
		$id = isset( $o['gtm-code'] ) ? strtoupper( trim( (string) $o['gtm-code'] ) ) : '';
		return [
			'version'   => defined( 'GTM4WP_VERSION' ) ? (string) GTM4WP_VERSION : '',
			'gtm_id'    => $id,
			'datalayer' => $dl,
		];
	}

	/**
	 * The dataLayer variable the bridge pushes to: in "dataLayer only" mode with
	 * GTM4WP active, GTM4WP's own name (it loads the container); otherwise ours.
	 */
	public static function datalayer_name(): string {
		if ( 'datalayer' === (string) self::opt( 'container_mode' ) ) {
			$g = self::gtm4wp_settings();
			if ( ! empty( $g['datalayer'] ) ) {
				return (string) $g['datalayer'];
			}
		}
		return (string) self::opt( 'datalayer' );
	}

	/**
	 * Detect another GTM injector (GTM4WP, Site Kit…).
	 */
	private function other_gtm_plugin(): string {
		if ( defined( 'GTM4WP_VERSION' ) || function_exists( 'gtm4wp_the_gtm_tag' ) ) {
			$g = self::gtm4wp_settings();
			return 'Google Tag Manager for WordPress (GTM4WP' . ( ! empty( $g['version'] ) ? ' ' . $g['version'] : '' ) . ')'
				. ( ! empty( $g['gtm_id'] ) ? ' — ' . __( 'container', 'wncpay' ) . ' ' . $g['gtm_id'] : '' )
				. ( ! empty( $g['datalayer'] ) ? ' · dataLayer: ' . $g['datalayer'] : '' );
		}
		if ( defined( 'GOOGLESITEKIT_VERSION' ) ) {
			return 'Site Kit by Google';
		}
		return '';
	}

	public function render_page(): void {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$o        = array_merge( self::defaults(), (array) get_option( self::OPTION, [] ) );
		$pcfg     = $this->platform_config();
		$other    = $this->other_gtm_plugin();
		$platform = WNCPAY_Embed::platform_url();
		$name     = self::OPTION;
		?>
		<div class="wrap">
			<h1 style="display:flex;align-items:center;gap:12px;">
				<img src="<?php echo esc_url( WNCPAY_URL . 'assets/images/wncpay-logo.png' ); ?>" alt="" style="height:44px;width:auto;" />
				<?php esc_html_e( 'WNC Pay — Analytics (GTM · GA4 · Google Ads)', 'wncpay' ); ?>
			</h1>
			<p><?php esc_html_e( 'The booking platform runs inside frames on this site, which a tag manager cannot see into. This bridge receives the platform\'s GA4-style events (view_item, add_to_cart, begin_checkout, purchase, generate_lead…) and pushes them onto THIS site\'s dataLayer, so your Google Tag Manager container treats them exactly like WooCommerce events. Paid bookings are additionally sent from the platform server (GA4 Measurement Protocol / Google Ads) so ad-blockers never lose revenue.', 'wncpay' ); ?></p>

			<?php if ( '' === $platform ) : ?>
				<div class="notice notice-error inline"><p><?php esc_html_e( 'Set the Platform URL under Settings → WNC Pay first.', 'wncpay' ); ?></p></div>
			<?php endif; ?>

			<div style="margin:12px 0;padding:10px 14px;border-left:4px solid <?php echo $other ? '#46b450' : '#ffb900'; ?>;background:#fff;">
				<?php if ( $other ) : ?>
					<strong>✓ <?php echo esc_html( $other ); ?></strong> — <?php esc_html_e( 'detected. Keep "dataLayer only" below: that plugin loads the container, this bridge only adds the platform events.', 'wncpay' ); ?>
				<?php else : ?>
					<strong><?php esc_html_e( 'No GTM plugin detected.', 'wncpay' ); ?></strong> <?php esc_html_e( 'Either install', 'wncpay' ); ?> <a href="https://wordpress.org/plugins/duracelltomi-google-tag-manager/" target="_blank" rel="noopener">Google Tag Manager for WordPress (GTM4WP)</a> <?php esc_html_e( 'and keep "dataLayer only", or choose "Inject the container" below and enter your GTM ID.', 'wncpay' ); ?>
				<?php endif; ?>
			</div>

			<form action="options.php" method="post">
				<?php settings_fields( 'wncpay_analytics' ); ?>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><?php esc_html_e( 'Bridge', 'wncpay' ); ?></th><td>
						<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[enabled]" value="1" <?php checked( '1', $o['enabled'] ); ?> /> <?php esc_html_e( 'Push platform events onto this site\'s dataLayer', 'wncpay' ); ?></label>
					</td></tr>
					<tr><th scope="row"><?php esc_html_e( 'GTM container', 'wncpay' ); ?></th><td>
						<fieldset>
							<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[container_mode]" value="datalayer" <?php checked( 'datalayer', $o['container_mode'] ); ?> /> <?php esc_html_e( 'dataLayer only — the container is loaded by another plugin / theme (recommended with GTM4WP)', 'wncpay' ); ?></label><br />
							<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[container_mode]" value="inject" <?php checked( 'inject', $o['container_mode'] ); ?> /> <?php esc_html_e( 'Inject the container on every page (head snippet + noscript) using the ID below', 'wncpay' ); ?></label><br />
							<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[container_mode]" value="off" <?php checked( 'off', $o['container_mode'] ); ?> /> <?php esc_html_e( 'Off — do not touch the container (events still push to the dataLayer when the bridge is on)', 'wncpay' ); ?></label>
						</fieldset>
						<p style="margin-top:8px;"><input type="text" class="regular-text code" name="<?php echo esc_attr( $name ); ?>[gtm_id]" value="<?php echo esc_attr( $o['gtm_id'] ); ?>" placeholder="GTM-XXXXXXX" /> <span class="description"><?php esc_html_e( 'Only used by "Inject".', 'wncpay' ); ?></span></p>
					</td></tr>
					<tr><th scope="row"><?php esc_html_e( 'dataLayer variable', 'wncpay' ); ?></th><td>
						<input type="text" class="regular-text code" name="<?php echo esc_attr( $name ); ?>[datalayer]" value="<?php echo esc_attr( $o['datalayer'] ); ?>" placeholder="dataLayer" />
						<p class="description"><?php esc_html_e( 'Leave as dataLayer unless your container uses a custom name.', 'wncpay' ); ?>
						<?php if ( self::gtm4wp_settings() ) : ?> <strong><?php esc_html_e( 'With GTM4WP active and "dataLayer only" selected, the bridge follows the variable name set in GTM4WP automatically — this field is ignored.', 'wncpay' ); ?></strong><?php endif; ?></p>
					</td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Forward these events', 'wncpay' ); ?></th><td>
						<?php foreach ( self::GROUP_LABELS as $g => $label ) : ?>
							<label style="display:block;margin:2px 0;"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[groups][]" value="<?php echo esc_attr( $g ); ?>" <?php checked( in_array( $g, (array) $o['groups'], true ) ); ?> /> <?php echo esc_html( $label ); ?></label>
						<?php endforeach; ?>
						<p class="description"><?php esc_html_e( 'Which events the platform emits at all is set on the platform (Dashboard → Settings → Analytics); this list filters what reaches this site.', 'wncpay' ); ?></p>
					</td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Attribution', 'wncpay' ); ?></th><td>
						<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[attribution]" value="1" <?php checked( '1', $o['attribution'] ); ?> /> <?php esc_html_e( 'Hand the visitor\'s Google click id (gclid / gbraid / wbraid), UTM tags and GA4 client + session id to the platform frames', 'wncpay' ); ?></label>
						<p class="description"><?php esc_html_e( 'Needed for server-side purchases to be attributed to the ad click and the GA4 session. Remembered in a first-party cookie for 90 days; passed by a message after the frame loads, so it is safe with page caching.', 'wncpay' ); ?></p>
					</td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Host page clicks', 'wncpay' ); ?></th><td>
						<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[host_clicks]" value="1" <?php checked( '1', $o['host_clicks'] ); ?> /> <?php esc_html_e( 'Also push whatsapp_click / phone_click for tel: and wa.me links on THIS site\'s pages (skip if GTM already has link-click triggers for them)', 'wncpay' ); ?></label>
					</td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Debug', 'wncpay' ); ?></th><td>
						<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[debug]" value="1" <?php checked( '1', $o['debug'] ); ?> /> <?php esc_html_e( 'console.log every forwarded event (visitors with ?wncpay_debug=1 in the URL see it too)', 'wncpay' ); ?></label>
					</td></tr>
				</table>
				<?php submit_button(); ?>
			</form>

			<hr />
			<h2><?php esc_html_e( 'Platform side (read-only)', 'wncpay' ); ?></h2>
			<?php if ( $pcfg ) : ?>
				<table class="widefat striped" style="max-width:860px;">
					<tbody>
						<tr><td style="width:280px;"><?php esc_html_e( 'Tracking enabled on the platform', 'wncpay' ); ?></td><td><?php echo ! empty( $pcfg['enabled'] ) ? '✓ ' . esc_html__( 'yes', 'wncpay' ) : '✗ ' . esc_html__( 'no — switch it on at Dashboard → Settings → Analytics', 'wncpay' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'GTM container on the platform domain (direct visits)', 'wncpay' ); ?></td><td><code><?php echo esc_html( $pcfg['containerId'] ?: '—' ); ?></code></td></tr>
						<tr><td><?php esc_html_e( 'Event groups emitted', 'wncpay' ); ?></td><td><?php echo esc_html( implode( ', ', (array) ( $pcfg['groups'] ?? [] ) ) ); ?></td></tr>
						<tr><td><?php esc_html_e( 'item_id carries', 'wncpay' ); ?></td><td><?php echo esc_html( ( $pcfg['itemIdMode'] ?? 'id' ) === 'matchkey' ? 'CRM match key' : 'platform product id' ); ?><?php echo ! empty( $pcfg['itemIdPrefix'] ) ? ' · prefix <code>' . esc_html( $pcfg['itemIdPrefix'] ) . '</code>' : ''; ?></td></tr>
						<tr><td><?php esc_html_e( 'purchase value', 'wncpay' ); ?></td><td><?php echo esc_html( ( $pcfg['valueMode'] ?? '' ) === 'amount_paid' ? 'amount actually charged' : 'booking total (amount_paid / deposit_amount / balance_due ride along)' ); ?> · <?php echo esc_html( $pcfg['currency'] ?? 'ILS' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Enhanced conversions (sha256 user_data)', 'wncpay' ); ?></td><td><?php echo ! empty( $pcfg['userData'] ) ? '✓' : '✗'; ?></td></tr>
					</tbody>
				</table>
			<?php else : ?>
				<p class="description"><?php esc_html_e( 'Could not read the platform configuration (platform unreachable or not configured).', 'wncpay' ); ?></p>
			<?php endif; ?>
			<p>
				<a class="button" href="<?php echo esc_url( $platform . '/dashboard/analytics' ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Open the platform Analytics page (settings, event log) ↗', 'wncpay' ); ?></a>
				<a class="button" href="<?php echo esc_url( $platform . '/dashboard/wiki/analytics-tracking' ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Tracking guide for the SEO team ↗', 'wncpay' ); ?></a>
			</p>

			<h2><?php esc_html_e( 'How to verify', 'wncpay' ); ?></h2>
			<ol>
				<li><?php esc_html_e( 'Open a page with an embedded catalog or tour, add ?wncpay_debug=1 to the URL, open the browser console: every forwarded event is logged as [wncpay-analytics].', 'wncpay' ); ?></li>
				<li><?php esc_html_e( 'GTM Preview (Tag Assistant) on this site shows the events as custom events with the ecommerce object — the same as WooCommerce.', 'wncpay' ); ?></li>
				<li><?php esc_html_e( 'The platform Analytics page keeps an event log (browser + server) for every event, with the payload.', 'wncpay' ); ?></li>
			</ol>
		</div>
		<?php
	}

	// ── Front end ────────────────────────────────────────────────────────────

	/**
	 * Head: GTM container (inject mode) or a dataLayer bootstrap; attribution cookie.
	 */
	public function print_head(): void {
		if ( is_admin() || ! self::enabled() ) {
			return;
		}
		$dl   = self::datalayer_name();
		$mode = (string) self::opt( 'container_mode' );
		$gtm  = (string) self::opt( 'gtm_id' );
		if ( 'inject' === $mode && '' !== $gtm ) {
			// The standard GTM snippet (custom dataLayer name supported).
			printf(
				"<!-- WNC Pay: Google Tag Manager -->\n<script data-cfasync=\"false\">(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script',%s,%s);</script>\n<!-- End Google Tag Manager -->\n",
				wp_json_encode( $dl ),
				wp_json_encode( $gtm )
			);
		} else {
			printf( "<script data-cfasync=\"false\">window[%s]=window[%s]||[];</script>\n", wp_json_encode( $dl ), wp_json_encode( $dl ) );
		}
		if ( '1' === (string) self::opt( 'attribution' ) ) {
			// Remember the ad click on landing (first-party cookie, 90 days) so frames on
			// LATER pages still receive it.
			?>
			<script data-cfasync="false">
			( function () {
				try {
					var q = new URLSearchParams( window.location.search ), keep = [ 'gclid', 'gbraid', 'wbraid', 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content' ], out = [];
					for ( var i = 0; i < keep.length; i++ ) { var v = q.get( keep[ i ] ); if ( v ) { out.push( keep[ i ] + '=' + encodeURIComponent( v.slice( 0, 200 ) ) ); } }
					if ( out.length ) { document.cookie = <?php echo wp_json_encode( self::COOKIE ); ?> + '=' + encodeURIComponent( out.join( '&' ) ) + ';path=/;max-age=7776000;SameSite=Lax' + ( location.protocol === 'https:' ? ';Secure' : '' ); }
				} catch ( e ) {}
			} )();
			</script>
			<?php
		}
	}

	/**
	 * GTM noscript (inject mode only).
	 */
	public function print_noscript(): void {
		if ( is_admin() || ! self::enabled() || 'inject' !== (string) self::opt( 'container_mode' ) ) {
			return;
		}
		$gtm = (string) self::opt( 'gtm_id' );
		if ( '' === $gtm ) {
			return;
		}
		printf( '<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=%s" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>' . "\n", esc_attr( $gtm ) );
	}

	/**
	 * Footer: the bridge listener (platform frame → this site's dataLayer).
	 */
	public function print_bridge(): void {
		if ( is_admin() || ! self::enabled() ) {
			return;
		}
		$origin = WNCPAY_Embed::platform_origin();
		$groups = (array) self::opt( 'groups' );
		$map    = [];
		foreach ( self::GROUPS as $ev => $g ) {
			$map[ $ev ] = $g;
		}
		?>
		<script id="wncpay-analytics" data-cfasync="false" data-no-optimize="1">
		( function () {
			var allowed = <?php echo wp_json_encode( $origin ); ?>;
			var dlName  = <?php echo wp_json_encode( self::datalayer_name() ); ?>;
			var groups  = <?php echo wp_json_encode( array_values( $groups ) ); ?>;
			var map     = <?php echo wp_json_encode( $map ); ?>;
			var debug   = <?php echo '1' === (string) self::opt( 'debug' ) ? 'true' : 'false'; ?> || /[?&]wncpay_debug=1/.test( window.location.search );
			var hostClicks = <?php echo '1' === (string) self::opt( 'host_clicks' ) ? 'true' : 'false'; ?>;
			function dl() { window[ dlName ] = window[ dlName ] || []; return window[ dlName ]; }
			function push( objects, source ) {
				for ( var i = 0; i < objects.length; i++ ) {
					var o = objects[ i ];
					if ( o && typeof o === 'object' ) { o.wncpay_source = source; dl().push( o ); }
				}
				if ( debug ) { try { console.log( '[wncpay-analytics]', source, objects[ objects.length - 1 ] ); } catch ( e ) {} }
			}
			window.addEventListener( 'message', function ( e ) {
				if ( e.origin !== allowed ) { return; }
				var d = e.data;
				if ( ! d || 'wncpay:track' !== d.type || ! Array.isArray( d.objects ) ) { return; }
				var ev = String( d.event || '' );
				var g  = map[ ev ];
				if ( g && groups.indexOf( g ) === -1 ) { return; }
				// Only frames this plugin rendered.
				var frames = document.querySelectorAll( 'iframe.wncpay-embed' ), mine = false;
				for ( var i = 0; i < frames.length; i++ ) { if ( frames[ i ].contentWindow === e.source ) { mine = true; break; } }
				if ( ! mine ) { return; }
				push( d.objects, 'embed' );
			} );
			// Attribution handshake (page-cache safe: nothing per-visitor is server-rendered).
			// The visitor's ad-click ids + UTM (URL now, or the landing cookie) and the GA4
			// client / session ids are posted INTO every platform frame, which stores them
			// so a server-side purchase can be attributed to this click and session.
			var attribution = <?php echo '1' === (string) self::opt( 'attribution' ) ? 'true' : 'false'; ?>;
			function readAttr() {
				var a = {};
				try {
					var keys = [ 'gclid', 'gbraid', 'wbraid', 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content' ];
					var m = document.cookie.match( new RegExp( '(?:^|;\\s*)' + <?php echo wp_json_encode( self::COOKIE ); ?> + '=([^;]*)' ) );
					var c = m ? new URLSearchParams( decodeURIComponent( m[ 1 ] ) ) : null;
					var q = new URLSearchParams( window.location.search );
					for ( var i = 0; i < keys.length; i++ ) { var v = q.get( keys[ i ] ) || ( c && c.get( keys[ i ] ) ); if ( v ) { a[ keys[ i ] ] = String( v ).slice( 0, 200 ); } }
					var g = document.cookie.match( /(?:^|;\s*)_ga=GA\d\.\d\.(\d+\.\d+)/ ); if ( g ) { a.ga_cid = g[ 1 ]; }
					var sid = document.cookie.match( /_ga_[A-Z0-9]+=GS\d\.\d\.s?(\d{9,11})/ ); if ( sid ) { a.ga_sid = sid[ 1 ]; }
					a.host = window.location.host; a.landing = window.location.pathname;
				} catch ( e ) {}
				return a;
			}
			function sendAttr( frame ) {
				if ( ! attribution || ! frame || ! frame.contentWindow ) { return; }
				try { frame.contentWindow.postMessage( { type: 'wncpay:attr', attr: readAttr() }, allowed ); } catch ( e ) {}
			}
			if ( attribution ) {
				var aframes = document.querySelectorAll( 'iframe.wncpay-embed' );
				for ( var f = 0; f < aframes.length; f++ ) { aframes[ f ].addEventListener( 'load', ( function ( fr ) { return function () { sendAttr( fr ); }; } )( aframes[ f ] ) ); }
				window.addEventListener( 'message', function ( e ) {
					if ( e.origin !== allowed || ! e.data || 'wncpay:resize' !== e.data.type ) { return; }
					var fr = document.querySelectorAll( 'iframe.wncpay-embed' );
					for ( var i = 0; i < fr.length; i++ ) { if ( fr[ i ].contentWindow === e.source && ! fr[ i ].__wncpayAttrSent ) { fr[ i ].__wncpayAttrSent = true; sendAttr( fr[ i ] ); break; } }
				} );
			}
			if ( hostClicks && groups.indexOf( 'engagement' ) !== -1 ) {
				document.addEventListener( 'click', function ( e ) {
					var a = e.target && e.target.closest ? e.target.closest( 'a[href]' ) : null;
					if ( ! a ) { return; }
					var href = a.getAttribute( 'href' ) || '';
					if ( /^tel:/i.test( href ) ) { push( [ { event: 'phone_click', link_url: href.slice( 0, 60 ), page_path: location.pathname } ], 'site' ); }
					else if ( /wa\.me|api\.whatsapp\.com|whatsapp:\/\//i.test( href ) ) { push( [ { event: 'whatsapp_click', link_url: href.slice( 0, 120 ), page_path: location.pathname } ], 'site' ); }
				}, true );
			}
		} )();
		</script>
		<?php
	}

}
