<?php
/**
 * Plugin Name:       WNC Pay
 * Plugin URI:        https://github.com/WebNetCom/wncpay-plugin
 * Description:       Embed elements from your connected platform — gift card designer and more — via shortcode, Elementor widget, or block. The plugin only places secure embeds; all checkout and payment flows run on the platform.
 * Version:           0.11.9
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            WebNetCom
 * Author URI:        https://webnetcom.co.il
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wncpay
 * Domain Path:       /languages
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

define( 'WNCPAY_VERSION', '0.11.9' );
define( 'WNCPAY_FILE', __FILE__ );
define( 'WNCPAY_PATH', plugin_dir_path( __FILE__ ) );
define( 'WNCPAY_URL', plugin_dir_url( __FILE__ ) );

// v0.10.2 -- DEFENSIVE loading. A plugin update can leave the folder briefly
// (or, on a broken copy, permanently) incomplete; a hard require_once on a
// missing file then fatals EVERY request and takes the whole site down (the
// 2026-08-20 incident). Missing files now simply skip: the plugin degrades to
// inert, the site stays up, and an admin notice says to reinstall.
$wncpay_includes = [
	'includes/class-wncpay-embed.php',
	'includes/class-wncpay-api.php',
	'includes/class-wncpay-settings.php',
	'includes/class-wncpay-shortcodes.php',
	'includes/class-wncpay-gift-button.php',
	'includes/class-wncpay-login-icon.php',
	'includes/class-wncpay-section.php',
	'includes/class-wncpay-product-meta.php',
	'includes/class-wncpay-blocks.php',
	'includes/elementor/class-wncpay-elementor.php',
	'includes/gateway/class-wncpay-woocommerce.php',
	'includes/class-wncpay-plugin.php',
];
$wncpay_missing = [];
foreach ( $wncpay_includes as $wncpay_file ) {
	if ( file_exists( WNCPAY_PATH . $wncpay_file ) ) {
		require_once WNCPAY_PATH . $wncpay_file;
	} else {
		$wncpay_missing[] = $wncpay_file;
	}
}
if ( $wncpay_missing ) {
	add_action(
		'admin_notices',
		static function () use ( $wncpay_missing ) {
			printf(
				'<div class="notice notice-error"><p><strong>WNC Pay:</strong> %s (%s). %s</p></div>',
				esc_html__( 'the plugin folder is incomplete — an update did not copy fully', 'wncpay' ),
				esc_html( implode( ', ', $wncpay_missing ) ),
				esc_html__( 'Please reinstall the plugin (Plugins → Add New → Upload) to restore it.', 'wncpay' )
			);
		}
	);
}

/**
 * Return the main plugin instance (null while the folder is incomplete).
 *
 * @return WNCPAY_Plugin|null
 */
function wncpay(): ?WNCPAY_Plugin {
	return class_exists( 'WNCPAY_Plugin' ) ? WNCPAY_Plugin::instance() : null;
}

wncpay();

/**
 * Native WordPress updates, served from the public update channel
 * (https://github.com/WebNetCom/wncpay-update — metadata JSON + built ZIPs
 * only, source stays private). When the plugin enters the wordpress.org
 * repository its update system takes over: remove this block.
 */
if ( file_exists( WNCPAY_PATH . 'lib/plugin-update-checker/plugin-update-checker.php' ) ) {
	require_once WNCPAY_PATH . 'lib/plugin-update-checker/plugin-update-checker.php';

	YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
		'https://raw.githubusercontent.com/WebNetCom/wncpay-update/main/wncpay.json',
		WNCPAY_FILE,
		'wncpay'
	);
}
