<?php
/**
 * Embed URL building and iframe rendering.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Embed
 */
final class WNCPAY_Embed {

	/**
	 * Whether at least one embed was rendered on this page.
	 *
	 * @var bool
	 */
	private static bool $rendered = false;

	/**
	 * Get a plugin option value.
	 *
	 * @param string $key Option key.
	 *
	 * @return string
	 */
	public static function get_option( string $key ): string {
		$options = get_option( 'wncpay_options', [] );

		return isset( $options[ $key ] ) ? (string) $options[ $key ] : '';
	}

	/**
	 * Configured platform base URL (no trailing slash), or empty string.
	 *
	 * @return string
	 */
	public static function platform_url(): string {
		return untrailingslashit( self::get_option( 'platform_url' ) );
	}

	/**
	 * The scheme://host[:port] origin of the platform URL, or empty string.
	 *
	 * @return string
	 */
	public static function platform_origin(): string {
		$parts = wp_parse_url( self::platform_url() );

		if ( empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			return '';
		}

		$origin = $parts['scheme'] . '://' . $parts['host'];

		if ( ! empty( $parts['port'] ) ) {
			$origin .= ':' . $parts['port'];
		}

		return $origin;
	}

	/**
	 * Current two-letter locale, WPML-aware.
	 *
	 * @return string
	 */
	public static function locale(): string {
		$lang = apply_filters( 'wpml_current_language', null );

		if ( ! is_string( $lang ) || '' === $lang ) {
			$lang = substr( get_locale(), 0, 2 );
		}

		return sanitize_key( $lang );
	}

	/**
	 * Build an embed URL for a platform path.
	 *
	 * @param string $path   Path on the platform (e.g. "/gift").
	 * @param array  $params Extra query parameters.
	 *
	 * @return string Empty string when the platform URL is not configured.
	 */
	public static function url( string $path, array $params = [] ): string {
		$base = self::platform_url();

		if ( '' === $base ) {
			return '';
		}

		$params = array_filter(
			$params,
			static function ( $value ) {
				return null !== $value && '' !== $value;
			}
		);

		// WordPress lowercases shortcode attribute names (and sanitize_key does
		// the same for widget/block params), but the platform reads camelCase
		// `dealId` — map it back so [wncpay_gift_designer dealid="…"] works.
		if ( isset( $params['dealid'] ) && ! isset( $params['dealId'] ) ) {
			$params['dealId'] = $params['dealid'];
			unset( $params['dealid'] );
		}

		$params['embed'] = '1';
		$params['lang']  = self::locale();

		$url = add_query_arg( urlencode_deep( $params ), $base . '/' . ltrim( $path, '/' ) );

		/**
		 * Filter the final embed URL.
		 *
		 * @param string $url    Embed URL.
		 * @param string $path   Requested platform path.
		 * @param array  $params Query parameters.
		 */
		return (string) apply_filters( 'wncpay_embed_url', $url, $path, $params );
	}

	/**
	 * Render an embed iframe.
	 *
	 * @param string $path   Path on the platform (e.g. "/gift").
	 * @param array  $params Extra query parameters.
	 * @param array  $args   Display arguments: min_height (int), title (string).
	 *
	 * @return string
	 */
	public static function render( string $path, array $params = [], array $args = [] ): string {
		$url = self::url( $path, $params );

		if ( '' === $url ) {
			if ( current_user_can( 'manage_options' ) ) {
				return '<div class="wncpay-notice" style="padding:12px;border:1px dashed #c00;color:#c00;">'
					. esc_html__( 'WNC Pay: set the Platform URL under Settings → WNC Pay to display this element. (Only administrators see this message.)', 'wncpay' )
					. '</div>';
			}

			return '';
		}

		$min_height = isset( $args['min_height'] ) ? absint( $args['min_height'] ) : 0;
		$min_height = $min_height > 0 ? max( 200, min( 20000, $min_height ) ) : 900;
		$title      = ! empty( $args['title'] ) ? (string) $args['title'] : __( 'Embedded platform content', 'wncpay' );
		// v0.7.2 -- embed mode: 'auto' (frame grows to full content height,
		// page scrolls normally) or 'window' (frame is sized to the visitor's
		// screen and the content scrolls INSIDE it -- sticky toolbars and
		// popups behave natively; used by the tour catalog).
		$mode = ( isset( $args['mode'] ) && 'window' === $args['mode'] ) ? 'window' : 'auto';
		// v0.8.0 -- dedicated single-page embeds (e.g. [wncpay_tour]) must not
		// auto-expand to full screen on load; that behavior is for in-catalog
		// navigation. The JS honors this attribute for wncpay:page messages.
		$noexpand = ! empty( $args['noexpand'] ) ? ' data-wncpay-noexpand="1"' : '';

		self::$rendered = true;

		// Cross-site failover (v0.6.0): some environments never let the frame
		// load (aggressive privacy modes, corporate proxies, content blockers).
		// The platform posts a wncpay:resize message as soon as the page runs;
		// if no message arrives within the timeout, the resize script below
		// swaps the frame for this card, whose button opens the same page
		// full-screen (without embed=1). The visitor is never left with a blank hole.
		$full_url = remove_query_arg( 'embed', $url );
		$fallback = sprintf(
			'<div class="wncpay-embed-fallback" hidden style="padding:28px 20px;border:1px solid #e5e7eb;border-radius:14px;text-align:center;background:#fafafa">'
			. '<p style="margin:0 0 14px;font-size:15px">%s</p>'
			. '<a href="%s" target="_blank" rel="noopener" style="display:inline-block;background:#f5a623;color:#111;font-weight:700;padding:10px 22px;border-radius:999px;text-decoration:none">%s</a>'
			. '</div>',
			esc_html__( 'This section could not load inside the page (a browser privacy setting may be blocking it).', 'wncpay' ),
			esc_url( $full_url ),
			esc_html__( 'Open it in a new tab', 'wncpay' )
		);

		return sprintf(
			'<div class="wncpay-embed-wrap" data-wncpay-pending="1"><iframe class="wncpay-embed" data-wncpay-mode="%s"%s src="%s" title="%s" loading="lazy" allow="payment" style="width:100%%;border:0;display:block;min-height:%dpx"></iframe>%s</div>',
			esc_attr( $mode ),
			$noexpand,
			esc_url( $url ),
			esc_attr( $title ),
			$min_height,
			$fallback
		);
	}

	/**
	 * Print the auto-height listener once per page.
	 *
	 * Inlined (not enqueued) so page optimizers that defer or delay JavaScript
	 * do not postpone iframe resizing. Only messages from the configured
	 * platform origin are accepted, and only for frames this plugin rendered.
	 *
	 * @return void
	 */
	public static function print_resize_script(): void {
		if ( ! self::$rendered ) {
			return;
		}

		$origin = self::platform_origin();

		if ( '' === $origin ) {
			return;
		}

		?>
		<script id="wncpay-resize" data-cfasync="false" data-no-optimize="1">
		( function () {
			var allowed = <?php echo wp_json_encode( $origin ); ?>;

			// v0.7.5 -- pass the SAME-SITE page the visitor came from into
			// catalog frames (ref=<path>) BEFORE they lazy-load: the platform
			// opens the matching tour directly or pre-filters its category
			// ("Get more info" from an individual tour page). Cross-site
			// referrers are never sent.
			// v0.9.0 -- gift-designer frames get the same context: the floating
			// "Gift this adventure" button links with ?fromtour=<path>, which
			// wins over the referrer; the platform prefills that tour's photos
			// + name on the card.
			try {
				var ctxPath = '';
				try { ctxPath = new URLSearchParams( window.location.search ).get( 'fromtour' ) || ''; } catch ( qErr ) {}
				var refUrl  = document.referrer ? new URL( document.referrer ) : null;
				var refPath = ( refUrl && refUrl.host === window.location.host && refUrl.pathname && '/' !== refUrl.pathname ) ? refUrl.pathname : '';
				var refFrames = document.querySelectorAll( 'iframe.wncpay-embed' );
				for ( var r = 0; r < refFrames.length; r++ ) {
					var refSrc = refFrames[ r ].getAttribute( 'src' ) || '';
					if ( refSrc.indexOf( 'ref=' ) !== -1 ) {
						continue;
					}
					var want = '';
					if ( refSrc.indexOf( '/tours' ) !== -1 ) {
						want = refPath;
					} else if ( refSrc.indexOf( '/gift' ) !== -1 ) {
						want = ctxPath || refPath;
					}
					if ( ! want ) {
						continue;
					}
					refFrames[ r ].setAttribute( 'src', refSrc + ( refSrc.indexOf( '?' ) === -1 ? '?' : '&' ) + 'ref=' + encodeURIComponent( want ) );
				}
			} catch ( refErr ) {
				// URL() unsupported or blocked referrer -- catalog just shows everything.
			}
			window.addEventListener( 'message', function ( e ) {
				if ( e.origin !== allowed ) {
					return;
				}
				var d = e.data;
				if ( ! d || 'wncpay:resize' !== d.type ) {
					return;
				}
				var h = parseInt( d.height, 10 );
				if ( ! h || h < 100 || h > 20000 ) {
					return;
				}
				var frames = document.querySelectorAll( 'iframe.wncpay-embed' );
				for ( var i = 0; i < frames.length; i++ ) {
					if ( frames[ i ].contentWindow === e.source ) {
						// v0.7.2 -- window-mode frames keep their viewport-based
						// height (set below); the content scrolls inside them.
						// v0.10.3 -- unless the page asked to FLOW (tour pages):
						// then the frame takes its full content height so the
						// site page scrolls as ONE document (header above,
						// site footer after the content).
						if ( 'window' !== frames[ i ].getAttribute( 'data-wncpay-mode' ) || frames[ i ].__wncpayFlow ) {
							frames[ i ].style.height = h + 'px';
							frames[ i ].style.minHeight = '0';
						}
						var wrap = frames[ i ].closest( '.wncpay-embed-wrap' );
						if ( wrap ) {
							// First message = the embed is alive; cancel the failover.
							wrap.removeAttribute( 'data-wncpay-pending' );
						}
						break;
					}
				}
			} );

			// Failover: an embed that has not posted a resize message within the
			// timeout AFTER becoming visible is assumed blocked (privacy mode /
			// proxy / content blocker). Swap the frame for the open-in-new-tab
			// card so the visitor is never stuck on a blank hole. The countdown
			// is armed per-frame on visibility because loading="lazy" means an
			// off-screen frame legitimately hasn't even started loading yet.
			var swapOne = function ( wrap ) {
				if ( ! wrap.hasAttribute( 'data-wncpay-pending' ) ) {
					return;
				}
				var frame = wrap.querySelector( 'iframe.wncpay-embed' );
				var card  = wrap.querySelector( '.wncpay-embed-fallback' );
				if ( frame ) { frame.style.display = 'none'; }
				if ( card ) { card.hidden = false; }
			};
			var arm = function ( wrap ) {
				if ( wrap.__wncpayArmed ) {
					return;
				}
				wrap.__wncpayArmed = true;
				setTimeout( function () { swapOne( wrap ); }, 10000 );
			};
			var wraps = document.querySelectorAll( '.wncpay-embed-wrap[data-wncpay-pending]' );
			if ( 'IntersectionObserver' in window ) {
				var io = new IntersectionObserver( function ( entries ) {
					for ( var i = 0; i < entries.length; i++ ) {
						if ( entries[ i ].isIntersecting ) {
							arm( entries[ i ].target );
							io.unobserve( entries[ i ].target );
						}
					}
				}, { rootMargin: '200px' } );
				for ( var i = 0; i < wraps.length; i++ ) {
					io.observe( wraps[ i ] );
				}
			} else {
				for ( var j = 0; j < wraps.length; j++ ) {
					arm( wraps[ j ] );
				}
			}

			// v0.7.1 -- Viewport streaming: the platform pages can't use CSS
			// sticky inside the auto-height iframe (the frame never scrolls
			// itself), so on parent scroll/resize we stream each frame's pin
			// offset -- how far the frame's top has scrolled past the visible
			// top of the viewport, plus the height of any fixed/sticky site
			// menu bar -- and the embedded page pins its own toolbar there.
			// Purely visual; the platform ignores it outside embed mode.
			var menuOffset = function () {
				var best = 0;
				if ( ! document.elementsFromPoint ) {
					return best;
				}
				var els = document.elementsFromPoint( Math.max( 1, window.innerWidth / 2 ), 1 ) || [];
				for ( var i = 0; i < els.length; i++ ) {
					var el = els[ i ];
					if ( el === document.documentElement || el === document.body ) {
						continue;
					}
					var cs = window.getComputedStyle( el );
					if ( 'fixed' !== cs.position && 'sticky' !== cs.position ) {
						continue;
					}
					var r = el.getBoundingClientRect();
					if ( r.top <= 1 && r.width > window.innerWidth * 0.5 && r.bottom > best && r.bottom < window.innerHeight * 0.4 ) {
						best = r.bottom;
					}
				}
				return best;
			};
			var vpRaf = 0;
			var sendViewport = function () {
				vpRaf = 0;
				var frames = document.querySelectorAll( 'iframe.wncpay-embed' );
				if ( ! frames.length ) {
					return;
				}
				var offset = menuOffset();
				for ( var i = 0; i < frames.length; i++ ) {
					// v0.7.2 -- window mode: the frame fills the visible screen
					// below the site's menu and its content scrolls internally.
					// Sticky bars and popups then behave natively -- no pin
					// streaming (and none is sent to these frames).
					if ( 'window' === frames[ i ].getAttribute( 'data-wncpay-mode' ) && ! frames[ i ].__wncpayFlow ) {
						var wh = Math.max( 480, window.innerHeight - offset );
						frames[ i ].style.height = wh + 'px';
						frames[ i ].style.minHeight = '0';
						continue;
					}
					var win = frames[ i ].contentWindow;
					if ( ! win ) {
						continue;
					}
					var rect = frames[ i ].getBoundingClientRect();
					var pin = Math.max( 0, offset - rect.top );
					// Don't pin past the bottom of the frame (small frames).
					pin = Math.min( pin, Math.max( 0, rect.height - 200 ) );
					try {
						// v0.10.4 -- vh: visible height of the frame region (screen minus the
						// sticky menu). The embed centers floating chips with it.
						win.postMessage( { type: 'wncpay:viewport', pin: pin, vh: Math.max( 240, window.innerHeight - offset ) }, allowed );
					} catch ( err ) {
						// Frame not on the platform origin (failover card shown) -- ignore.
					}
				}
			};
			var scheduleViewport = function () {
				if ( ! vpRaf ) {
					vpRaf = window.requestAnimationFrame( sendViewport );
				}
			};
			window.addEventListener( 'scroll', scheduleViewport, { passive: true } );
			window.addEventListener( 'resize', scheduleViewport, { passive: true } );

			// v0.8.1 -- Dock-on-pause: a window-mode frame half-visible on the
			// page leaves the visitor juggling two scrollbars ("jumpy"). When
			// scrolling pauses with the frame's top in the docking band (below
			// the menu, above mid-screen), glide the page so the frame sits
			// FLUSH under the menu -- from there the inner scroll takes over,
			// and scrolling up past the catalog's top chains back to the page
			// naturally. Deliberately scrolling past the frame is never fought.
			var dockTimer = 0;
			var dockFrames = function () {
				var frames = document.querySelectorAll( 'iframe.wncpay-embed[data-wncpay-mode="window"]' );
				if ( ! frames.length ) {
					return;
				}
				var offset = menuOffset();
				for ( var i = 0; i < frames.length; i++ ) {
					if ( frames[ i ].__wncpayExpanded || frames[ i ].__wncpayFlow ) {
						continue;
					}
					var rect = frames[ i ].getBoundingClientRect();
					if ( rect.top > offset + 1 && rect.top < window.innerHeight * 0.55 ) {
						window.scrollTo( { top: window.pageYOffset + rect.top - offset, behavior: 'smooth' } );
						break;
					}
				}
			};
			window.addEventListener( 'scroll', function () {
				if ( dockTimer ) {
					clearTimeout( dockTimer );
				}
				dockTimer = setTimeout( dockFrames, 170 );
			}, { passive: true } );

			// v0.7.3/0.7.4 -- Full-screen expansion. Two triggers, one behavior:
			//   wncpay:modal {open}  -- transient (quote form / basket open)
			//   wncpay:page {expand} -- per-page (individual tour pages, which
			//                           are unusable squeezed into the window)
			// While either flag is on, the frame covers the whole screen (above
			// the site menu and floating buttons); when both are off it is
			// restored and re-sized. Messages only from the platform origin.
			var applyExpand = function ( f ) {
				var want = !! ( f.__wncpayModal || f.__wncpayPage );
				if ( want && ! f.__wncpayExpanded ) {
					f.__wncpayExpanded = true;
					f.__wncpaySavedStyle = f.getAttribute( 'style' ) || '';
					f.__wncpaySavedScrollLock = document.documentElement.style.overflow || '';
					f.style.position = 'fixed';
					f.style.top = '0';
					f.style.left = '0';
					f.style.width = '100vw';
					f.style.height = '100vh';
					f.style.minHeight = '0';
					f.style.zIndex = '2147483000';
					f.style.border = '0';
					f.style.background = '#000';
					document.documentElement.style.overflow = 'hidden';
				} else if ( ! want && f.__wncpayExpanded ) {
					f.__wncpayExpanded = false;
					f.setAttribute( 'style', f.__wncpaySavedStyle || '' );
					document.documentElement.style.overflow = f.__wncpaySavedScrollLock || '';
					scheduleViewport();
				}
			};
			window.addEventListener( 'message', function ( e ) {
				if ( e.origin !== allowed ) {
					return;
				}
				var d = e.data;
				if ( ! d || ( 'wncpay:modal' !== d.type && 'wncpay:page' !== d.type && 'wncpay:scrolltop' !== d.type ) ) {
					return;
				}
				var frames = document.querySelectorAll( 'iframe.wncpay-embed' );
				for ( var i = 0; i < frames.length; i++ ) {
					var f = frames[ i ];
					if ( f.contentWindow !== e.source ) {
						continue;
					}
					// v0.10.1 -- after an in-frame page change (e.g. the short
					// thank-you page after paying), glide the page so the frame's
					// top is back in view instead of stranding the visitor in
					// empty space. Full-screen frames need no alignment.
					if ( 'wncpay:scrolltop' === d.type ) {
						if ( ! f.__wncpayExpanded ) {
							var off = menuOffset();
							var rc = f.getBoundingClientRect();
							if ( rc.top < off - 4 || rc.top > window.innerHeight * 0.6 ) {
								window.scrollTo( { top: window.pageYOffset + rc.top - off, behavior: 'smooth' } );
							}
						}
						break;
					}
					if ( 'wncpay:modal' === d.type ) {
						f.__wncpayModal = !! d.open;
					} else {
						// v0.8.0 -- dedicated single-page embeds opt out of
						// page-level expansion ([wncpay_tour] etc.).
						if ( f.hasAttribute( 'data-wncpay-noexpand' ) ) {
							return;
						}
						f.__wncpayPage = !! d.expand;
						// v0.10.3 -- FLOW mode (tour pages): frame grows to its
						// content height inside the page instead of covering
						// the screen; leaving the tour restores window mode.
						f.__wncpayFlow = !! d.flow;
					}
					applyExpand( f );
					break;
				}
			} );
			sendViewport();
			window.setTimeout( sendViewport, 1500 );
		} )();
		</script>
		<?php
	}
}
