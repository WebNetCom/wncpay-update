<?php
/**
 * Group tours (scheduled group departures) — v0.12.0.
 *
 * The platform sells scheduled group departures per person (early-bird + regular
 * price, seat limit, minimum participants). This file puts them on the main site:
 *
 *   [wncpay_group_tours]            — the "Group tours" page (all open departures,
 *                                     booking flow completes inside the frame)
 *   [wncpay_group_tour id="…"]      — ONE departure's flyer page (id from
 *                                     Dashboard → Group departures → Share)
 *
 * …plus a one-click "Create the Group Tours page" button under Settings → WNC Pay
 * that publishes a page (slug group-tours) holding the shortcode, so the site has
 * its OWN page at /group-tours/ without editing anything by hand.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Group_Tours
 */
final class WNCPAY_Group_Tours {

	/**
	 * Option holding the auto-created page id.
	 */
	public const PAGE_OPTION = 'wncpay_group_tours_page';

	/**
	 * WNCPAY_Group_Tours constructor.
	 */
	public function __construct() {
		add_shortcode( 'wncpay_group_tours', [ $this, 'render_list' ] );
		add_shortcode( 'wncpay_group_tour', [ $this, 'render_one' ] );
		add_action( 'admin_post_wncpay_create_group_page', [ $this, 'create_page' ] );
		add_action( 'admin_notices', [ $this, 'notices' ] );
	}

	/**
	 * [wncpay_group_tours min_height="" title="" mode="auto|window"].
	 *
	 * @param array|string $atts Shortcode attributes.
	 *
	 * @return string
	 */
	public function render_list( $atts ): string {
		$atts = is_array( $atts ) ? $atts : [];
		$args = self::display_args( $atts );
		if ( empty( $args['title'] ) ) {
			$args['title'] = __( 'Group tours', 'wncpay' );
		}
		// Page mode: the frame grows with the list and the visitor scrolls the
		// site page normally (the flyer pages + booking form work the same way).
		if ( empty( $args['mode'] ) ) {
			$args['mode'] = 'auto';
		}
		$args['noexpand'] = true;

		return WNCPAY_Embed::render( '/group-tours', [], $args );
	}

	/**
	 * [wncpay_group_tour id="<departure id>"].
	 *
	 * @param array|string $atts Shortcode attributes.
	 *
	 * @return string
	 */
	public function render_one( $atts ): string {
		$atts = is_array( $atts ) ? $atts : [];
		$id   = ! empty( $atts['id'] ) ? sanitize_text_field( (string) $atts['id'] ) : '';

		if ( '' === $id ) {
			if ( current_user_can( 'manage_options' ) ) {
				return '<div class="wncpay-notice" style="padding:12px;border:1px dashed #c00;color:#c00;">'
					. esc_html__( 'WNC Pay: [wncpay_group_tour] needs an id attribute (the departure id — Dashboard → Group departures → Share link). Only administrators see this message.', 'wncpay' )
					. '</div>';
			}

			return '';
		}

		$args = self::display_args( $atts );
		if ( empty( $args['title'] ) ) {
			$args['title'] = __( 'Group tour', 'wncpay' );
		}
		if ( empty( $args['mode'] ) ) {
			$args['mode'] = 'auto';
		}
		$args['noexpand'] = true;

		return WNCPAY_Embed::render( '/group/' . rawurlencode( $id ), [], $args );
	}

	/**
	 * min_height / title / mode from shortcode attributes.
	 *
	 * @param array $atts Shortcode attributes.
	 *
	 * @return array
	 */
	private static function display_args( array $atts ): array {
		$args = [];
		if ( ! empty( $atts['min_height'] ) ) {
			$args['min_height'] = absint( $atts['min_height'] );
		}
		if ( ! empty( $atts['mode'] ) && in_array( $atts['mode'], [ 'window', 'auto' ], true ) ) {
			$args['mode'] = $atts['mode'];
		}
		if ( ! empty( $atts['title'] ) ) {
			$args['title'] = sanitize_text_field( (string) $atts['title'] );
		}

		return $args;
	}

	/**
	 * The auto-created (or detected) Group Tours page, if any.
	 *
	 * @return WP_Post|null
	 */
	public static function page(): ?WP_Post {
		$id = (int) get_option( self::PAGE_OPTION, 0 );
		if ( $id > 0 ) {
			$post = get_post( $id );
			if ( $post instanceof WP_Post && 'trash' !== $post->post_status ) {
				return $post;
			}
		}

		// Not created by us — maybe the editor pasted the shortcode somewhere already.
		$found = get_posts(
			[
				'post_type'      => 'page',
				'post_status'    => [ 'publish', 'draft', 'private' ],
				'posts_per_page' => 1,
				's'              => '[wncpay_group_tours',
				'fields'         => 'ids',
			]
		);
		if ( $found ) {
			$post = get_post( (int) $found[0] );
			if ( $post instanceof WP_Post ) {
				update_option( self::PAGE_OPTION, $post->ID, false );

				return $post;
			}
		}

		return null;
	}

	/**
	 * URL of the "create page" action (nonced), for the settings screen.
	 *
	 * @return string
	 */
	public static function create_url(): string {
		return wp_nonce_url( admin_url( 'admin-post.php?action=wncpay_create_group_page' ), 'wncpay_create_group_page' );
	}

	/**
	 * admin-post handler: publish the page holding [wncpay_group_tours].
	 *
	 * @return void
	 */
	public function create_page(): void {
		if ( ! current_user_can( 'publish_pages' ) ) {
			wp_die( esc_html__( 'You are not allowed to create pages.', 'wncpay' ) );
		}
		check_admin_referer( 'wncpay_create_group_page' );

		$back = admin_url( 'options-general.php?page=wncpay' );

		$existing = self::page();
		if ( $existing ) {
			wp_safe_redirect( add_query_arg( 'wncpay_group_page', 'exists', $back ) );
			exit;
		}

		$he = 0 === strpos( (string) get_locale(), 'he' );
		$id = wp_insert_post(
			[
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_title'   => $he ? 'טיולי קבוצה' : 'Group Tours',
				'post_name'    => 'group-tours',
				'post_content' => '[wncpay_group_tours]',
				'post_author'  => get_current_user_id(),
				'meta_input'   => [ '_wncpay_generated' => 'group_tours' ],
			],
			true
		);

		if ( is_wp_error( $id ) ) {
			wp_safe_redirect( add_query_arg( 'wncpay_group_page', 'error', $back ) );
			exit;
		}

		update_option( self::PAGE_OPTION, (int) $id, false );
		wp_safe_redirect( add_query_arg( 'wncpay_group_page', 'created', $back ) );
		exit;
	}

	/**
	 * Result notice after the create action.
	 *
	 * @return void
	 */
	public function notices(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display-only flag.
		$flag = isset( $_GET['wncpay_group_page'] ) ? sanitize_key( (string) wp_unslash( $_GET['wncpay_group_page'] ) ) : '';
		if ( '' === $flag ) {
			return;
		}
		$page = self::page();
		$link = $page ? sprintf( ' <a href="%s" target="_blank" rel="noopener">%s</a>', esc_url( get_permalink( $page ) ), esc_html( get_permalink( $page ) ) ) : '';
		if ( 'created' === $flag ) {
			printf( '<div class="notice notice-success is-dismissible"><p>%s%s</p></div>', esc_html__( 'WNC Pay: the Group Tours page was created and published.', 'wncpay' ), $link ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built above with esc_*.
		} elseif ( 'exists' === $flag ) {
			printf( '<div class="notice notice-info is-dismissible"><p>%s%s</p></div>', esc_html__( 'WNC Pay: a Group Tours page already exists.', 'wncpay' ), $link ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} elseif ( 'error' === $flag ) {
			printf( '<div class="notice notice-error is-dismissible"><p>%s</p></div>', esc_html__( 'WNC Pay: the Group Tours page could not be created.', 'wncpay' ) );
		}
	}

	/**
	 * Settings-screen block: status + create button + shortcode hints.
	 *
	 * @return void
	 */
	public static function render_settings_block(): void {
		$page = self::page();
		echo '<h2>🌟 ' . esc_html__( 'Group tours page', 'wncpay' ) . '</h2>';
		echo '<p>' . esc_html__( 'Scheduled group departures (e.g. the Friday tours) sold per person with early-bird and regular prices, seat limits and a minimum to run. They are managed on the platform (Dashboard → Group departures); this puts them on YOUR site as its own page.', 'wncpay' ) . '</p>';
		if ( $page ) {
			printf(
				'<p><strong>✓ %s</strong> — <a href="%s" target="_blank" rel="noopener">%s</a> · <a href="%s">%s</a>%s</p>',
				esc_html__( 'Page in place', 'wncpay' ),
				esc_url( get_permalink( $page ) ),
				esc_html( get_permalink( $page ) ),
				esc_url( get_edit_post_link( $page ) ),
				esc_html__( 'Edit', 'wncpay' ),
				'publish' === $page->post_status ? '' : ' <em>(' . esc_html( $page->post_status ) . ')</em>'
			);
			echo '<p class="description">' . esc_html__( 'Add it to your menu (Appearance → Menus) and link your Friday-tour ads to it. To place the list somewhere else instead, paste the shortcode below into any page.', 'wncpay' ) . '</p>';
		} else {
			printf(
				'<p><a class="button button-primary" href="%s">%s</a> <span class="description">%s</span></p>',
				esc_url( self::create_url() ),
				esc_html__( 'Create the Group Tours page', 'wncpay' ),
				esc_html__( 'Publishes a page at /group-tours/ containing [wncpay_group_tours]. You can rename or move it afterwards like any page.', 'wncpay' )
			);
		}
	}
}
