<?php
/**
 * Header login icon.
 *
 * v0.11.2 -- Talie: a small person icon in the site header, next to the
 * cart/gift icons, that takes the visitor to their account on the platform
 * (sign-in happens there when needed). The icon is injected client-side so no
 * theme/Elementor template edit is required. Placement: an explicit CSS
 * selector from settings wins; otherwise it lands after the configured gift
 * page link in the header, else after the WooCommerce menu-cart widget.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Login_Icon
 */
final class WNCPAY_Login_Icon {

	/**
	 * WNCPAY_Login_Icon constructor.
	 */
	public function __construct() {
		add_action( 'wp_footer', [ $this, 'render' ], 6 );
	}

	/**
	 * Print the injector when enabled.
	 *
	 * @return void
	 */
	public function render(): void {
		if ( is_admin() || '1' !== WNCPAY_Embed::get_option( 'login_icon' ) ) {
			return;
		}

		$platform = WNCPAY_Embed::platform_url();
		$url      = trim( WNCPAY_Embed::get_option( 'login_icon_url' ) );
		if ( '' === $url ) {
			if ( '' === $platform ) {
				return;
			}
			$url = $platform . '/account';
		}

		$after     = trim( WNCPAY_Embed::get_option( 'login_icon_after' ) );
		$gift_page = trim( WNCPAY_Embed::get_option( 'gift_button_page' ) );
		$gift_path = '' !== $gift_page ? (string) wp_parse_url( $gift_page, PHP_URL_PATH ) : '';
		?>
		<style>
		/* v0.11.7 -- Hebrew/RTL header fix: the injected header icons must never
		   wrap the header column onto a second line (the login icon used to drop
		   below the button on the RTL template). Let the icon row keep one line
		   and size to its content. */
		.elementor-widget-wrap:has(> .wncpay-login-icon),
		.elementor-widget-wrap:has(> .wncpay-cart-icon) { flex-wrap: nowrap !important; width: max-content; max-width: none; }
		.wncpay-login-icon, .wncpay-cart-icon { flex: 0 0 auto; }
		</style>
		<script>
		( function () {
			'use strict';
			var url      = <?php echo wp_json_encode( esc_url( $url ) ); ?>;
			var after    = <?php echo wp_json_encode( $after ); ?>;
			var giftPath = <?php echo wp_json_encode( $gift_path ); ?>;
			var place = function () {
				if ( document.querySelector( '.wncpay-login-icon' ) ) {
					return;
				}
				var anchor = null;
				if ( after ) {
					try { anchor = document.querySelector( after ); } catch ( e ) {}
				}
				if ( ! anchor && giftPath ) {
					// v0.12.1 -- pick the header's gift ICON, not any link that happens
					// to point at the gift page: the news ticker (a JetEngine listing
					// slider) had a "Read More" link to /gift-certificates/, so the icon
					// landed inside a slide and only showed on that slide. Links inside
					// sliders/listings are skipped, and a link wrapping an icon/image
					// wins over a text link.
					// v0.12.2 -- and only a VISIBLE link outside menus: the Hebrew
					// header's first gift link sat inside the (closed) mega-menu
					// drop-down, so the icon was inserted where nobody could see it.
					var links = document.querySelectorAll( 'header a, .elementor-location-header a' );
					var visible = function ( el ) {
						var r = el.getBoundingClientRect();
						if ( r.width < 1 || r.height < 1 ) { return false; }
						for ( var n = el; n && n !== document.body; n = n.parentElement ) {
							var cs = window.getComputedStyle( n );
							if ( 'none' === cs.display || 'hidden' === cs.visibility ) { return false; }
						}
						return true;
					};
					var textFallback = null, hiddenFallback = null;
					for ( var i = 0; i < links.length; i++ ) {
						var href = links[ i ].getAttribute( 'href' ) || '';
						if ( href.indexOf( giftPath ) === -1 ) {
							continue;
						}
						if ( links[ i ].closest && links[ i ].closest( '.swiper, .swiper-slide, .jet-listing, .jet-listing-grid, .elementor-widget-jet-listing-grid, .jet-sub-mega-menu, .jet-mega-menu-sub, .sub-menu, .elementor-nav-menu--dropdown' ) ) {
							continue;
						}
						var isIcon = !! links[ i ].querySelector( 'img, svg, i, .elementor-icon' );
						if ( ! visible( links[ i ] ) ) {
							if ( ! hiddenFallback && isIcon ) { hiddenFallback = links[ i ]; }
							continue;
						}
						if ( isIcon ) {
							anchor = links[ i ];
							break;
						}
						if ( ! textFallback ) {
							textFallback = links[ i ];
						}
					}
					if ( ! anchor ) {
						anchor = textFallback || hiddenFallback;
					}
				}
				if ( ! anchor ) {
					anchor = document.querySelector( '.elementor-widget-woocommerce-menu-cart' );
				}
				if ( ! anchor ) {
					return;
				}
				var host = anchor.closest ? ( anchor.closest( '.elementor-widget' ) || anchor ) : anchor;
				var a = document.createElement( 'a' );
				a.className = 'wncpay-login-icon';
				a.href = url;
				a.setAttribute( 'aria-label', 'My account' );
				a.title = 'My account';
				// v0.11.3 -- explicit white: currentColor inherited the theme's dark
				// text (#333) and the icon vanished on the black header.
				// v0.11.4 -- the theme overrides even that with an !important
				// color rule, so: !important on the anchor AND the stroke set
				// directly on the SVG, out of reach of text-color CSS.
				a.style.cssText = 'display:inline-flex;align-items:center;justify-content:center;margin-inline-start:12px;opacity:.9;';
				a.style.setProperty( 'color', '#fff', 'important' );
				a.onmouseover = function () { a.style.opacity = '1'; };
				a.onmouseout = function () { a.style.opacity = '.9'; };
				a.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#fff" style="stroke:#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6.5 8-6.5s8 2.5 8 6.5"/></svg>';
				host.insertAdjacentElement( 'afterend', a );
			};
			if ( 'loading' === document.readyState ) {
				document.addEventListener( 'DOMContentLoaded', place );
			} else {
				place();
			}
			// Elementor sticky headers clone the header markup -- place again
			// shortly after load so the clone gets the icon too.
			window.setTimeout( place, 1200 );
		} )();
		</script>
		<?php
	}
}
