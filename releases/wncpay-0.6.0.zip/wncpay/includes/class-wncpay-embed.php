<?php
/**
 * Embed URL building and iframe rendering.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Embed
 */
final class WNCPAY_Embed {

	/**
	 * Whether at least one embed was rendered on this page.
	 *
	 * @var bool
	 */
	private static bool $rendered = false;

	/**
	 * Get a plugin option value.
	 *
	 * @param string $key Option key.
	 *
	 * @return string
	 */
	public static function get_option( string $key ): string {
		$options = get_option( 'wncpay_options', [] );

		return isset( $options[ $key ] ) ? (string) $options[ $key ] : '';
	}

	/**
	 * Configured platform base URL (no trailing slash), or empty string.
	 *
	 * @return string
	 */
	public static function platform_url(): string {
		return untrailingslashit( self::get_option( 'platform_url' ) );
	}

	/**
	 * The scheme://host[:port] origin of the platform URL, or empty string.
	 *
	 * @return string
	 */
	public static function platform_origin(): string {
		$parts = wp_parse_url( self::platform_url() );

		if ( empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			return '';
		}

		$origin = $parts['scheme'] . '://' . $parts['host'];

		if ( ! empty( $parts['port'] ) ) {
			$origin .= ':' . $parts['port'];
		}

		return $origin;
	}

	/**
	 * Current two-letter locale, WPML-aware.
	 *
	 * @return string
	 */
	public static function locale(): string {
		$lang = apply_filters( 'wpml_current_language', null );

		if ( ! is_string( $lang ) || '' === $lang ) {
			$lang = substr( get_locale(), 0, 2 );
		}

		return sanitize_key( $lang );
	}

	/**
	 * Build an embed URL for a platform path.
	 *
	 * @param string $path   Path on the platform (e.g. "/gift").
	 * @param array  $params Extra query parameters.
	 *
	 * @return string Empty string when the platform URL is not configured.
	 */
	public static function url( string $path, array $params = [] ): string {
		$base = self::platform_url();

		if ( '' === $base ) {
			return '';
		}

		$params = array_filter(
			$params,
			static function ( $value ) {
				return null !== $value && '' !== $value;
			}
		);

		// WordPress lowercases shortcode attribute names (and sanitize_key does
		// the same for widget/block params), but the platform reads camelCase
		// `dealId` — map it back so [wncpay_gift_designer dealid="…"] works.
		if ( isset( $params['dealid'] ) && ! isset( $params['dealId'] ) ) {
			$params['dealId'] = $params['dealid'];
			unset( $params['dealid'] );
		}

		$params['embed'] = '1';
		$params['lang']  = self::locale();

		$url = add_query_arg( urlencode_deep( $params ), $base . '/' . ltrim( $path, '/' ) );

		/**
		 * Filter the final embed URL.
		 *
		 * @param string $url    Embed URL.
		 * @param string $path   Requested platform path.
		 * @param array  $params Query parameters.
		 */
		return (string) apply_filters( 'wncpay_embed_url', $url, $path, $params );
	}

	/**
	 * Render an embed iframe.
	 *
	 * @param string $path   Path on the platform (e.g. "/gift").
	 * @param array  $params Extra query parameters.
	 * @param array  $args   Display arguments: min_height (int), title (string).
	 *
	 * @return string
	 */
	public static function render( string $path, array $params = [], array $args = [] ): string {
		$url = self::url( $path, $params );

		if ( '' === $url ) {
			if ( current_user_can( 'manage_options' ) ) {
				return '<div class="wncpay-notice" style="padding:12px;border:1px dashed #c00;color:#c00;">'
					. esc_html__( 'WNC Pay: set the Platform URL under Settings → WNC Pay to display this element. (Only administrators see this message.)', 'wncpay' )
					. '</div>';
			}

			return '';
		}

		$min_height = isset( $args['min_height'] ) ? absint( $args['min_height'] ) : 0;
		$min_height = $min_height > 0 ? max( 200, min( 20000, $min_height ) ) : 900;
		$title      = ! empty( $args['title'] ) ? (string) $args['title'] : __( 'Embedded platform content', 'wncpay' );

		self::$rendered = true;

		// Cross-site failover (v0.6.0): some environments never let the frame
		// load (aggressive privacy modes, corporate proxies, content blockers).
		// The platform posts a wncpay:resize message as soon as the page runs;
		// if no message arrives within the timeout, the resize script below
		// swaps the frame for this card, whose button opens the same page
		// full-screen (without embed=1). The visitor is never left with a blank hole.
		$full_url = remove_query_arg( 'embed', $url );
		$fallback = sprintf(
			'<div class="wncpay-embed-fallback" hidden style="padding:28px 20px;border:1px solid #e5e7eb;border-radius:14px;text-align:center;background:#fafafa">'
			. '<p style="margin:0 0 14px;font-size:15px">%s</p>'
			. '<a href="%s" target="_blank" rel="noopener" style="display:inline-block;background:#f5a623;color:#111;font-weight:700;padding:10px 22px;border-radius:999px;text-decoration:none">%s</a>'
			. '</div>',
			esc_html__( 'This section could not load inside the page (a browser privacy setting may be blocking it).', 'wncpay' ),
			esc_url( $full_url ),
			esc_html__( 'Open it in a new tab', 'wncpay' )
		);

		return sprintf(
			'<div class="wncpay-embed-wrap" data-wncpay-pending="1"><iframe class="wncpay-embed" src="%s" title="%s" loading="lazy" allow="payment" style="width:100%%;border:0;display:block;min-height:%dpx"></iframe>%s</div>',
			esc_url( $url ),
			esc_attr( $title ),
			$min_height,
			$fallback
		);
	}

	/**
	 * Print the auto-height listener once per page.
	 *
	 * Inlined (not enqueued) so page optimizers that defer or delay JavaScript
	 * do not postpone iframe resizing. Only messages from the configured
	 * platform origin are accepted, and only for frames this plugin rendered.
	 *
	 * @return void
	 */
	public static function print_resize_script(): void {
		if ( ! self::$rendered ) {
			return;
		}

		$origin = self::platform_origin();

		if ( '' === $origin ) {
			return;
		}

		?>
		<script id="wncpay-resize" data-cfasync="false" data-no-optimize="1">
		( function () {
			var allowed = <?php echo wp_json_encode( $origin ); ?>;
			window.addEventListener( 'message', function ( e ) {
				if ( e.origin !== allowed ) {
					return;
				}
				var d = e.data;
				if ( ! d || 'wncpay:resize' !== d.type ) {
					return;
				}
				var h = parseInt( d.height, 10 );
				if ( ! h || h < 100 || h > 20000 ) {
					return;
				}
				var frames = document.querySelectorAll( 'iframe.wncpay-embed' );
				for ( var i = 0; i < frames.length; i++ ) {
					if ( frames[ i ].contentWindow === e.source ) {
						frames[ i ].style.height = h + 'px';
						frames[ i ].style.minHeight = '0';
						var wrap = frames[ i ].closest( '.wncpay-embed-wrap' );
						if ( wrap ) {
							// First message = the embed is alive; cancel the failover.
							wrap.removeAttribute( 'data-wncpay-pending' );
						}
						break;
					}
				}
			} );

			// Failover: an embed that has not posted a resize message within the
			// timeout AFTER becoming visible is assumed blocked (privacy mode /
			// proxy / content blocker). Swap the frame for the open-in-new-tab
			// card so the visitor is never stuck on a blank hole. The countdown
			// is armed per-frame on visibility because loading="lazy" means an
			// off-screen frame legitimately hasn't even started loading yet.
			var swapOne = function ( wrap ) {
				if ( ! wrap.hasAttribute( 'data-wncpay-pending' ) ) {
					return;
				}
				var frame = wrap.querySelector( 'iframe.wncpay-embed' );
				var card  = wrap.querySelector( '.wncpay-embed-fallback' );
				if ( frame ) { frame.style.display = 'none'; }
				if ( card ) { card.hidden = false; }
			};
			var arm = function ( wrap ) {
				if ( wrap.__wncpayArmed ) {
					return;
				}
				wrap.__wncpayArmed = true;
				setTimeout( function () { swapOne( wrap ); }, 10000 );
			};
			var wraps = document.querySelectorAll( '.wncpay-embed-wrap[data-wncpay-pending]' );
			if ( 'IntersectionObserver' in window ) {
				var io = new IntersectionObserver( function ( entries ) {
					for ( var i = 0; i < entries.length; i++ ) {
						if ( entries[ i ].isIntersecting ) {
							arm( entries[ i ].target );
							io.unobserve( entries[ i ].target );
						}
					}
				}, { rootMargin: '200px' } );
				for ( var i = 0; i < wraps.length; i++ ) {
					io.observe( wraps[ i ] );
				}
			} else {
				for ( var j = 0; j < wraps.length; j++ ) {
					arm( wraps[ j ] );
				}
			}
		} )();
		</script>
		<?php
	}
}
