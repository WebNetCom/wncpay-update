=== WNC Pay ===
Contributors: webnetcom
Tags: embed, gift cards, elementor, shortcode, block
Requires at least: 6.0
Tested up to: 7.0
Stable tag: 0.14.0
Requires PHP: 8.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Embed elements from your connected platform — gift card designer and more — via shortcode, Elementor widget, or block.

== Description ==

WNC Pay turns a WordPress/WooCommerce site into the storefront for a full booking-and-payment platform — without moving any customer data, card details, or checkout logic into WordPress. The platform does the heavy lifting (catalog, quotes, deposits, saved cards, documents, CRM); the plugin's job is to place that platform's live elements anywhere on the site and to route WooCommerce checkout to it securely.

Everything below is real and shipping today — this is a mature integration, not a stub.

= What it can do =

* **Show your real catalog and tour pages on WordPress.** The catalog, individual tour pages, the trip-planner wizard and the "How it works" explainer all embed as live elements that follow the site language (WPML-aware) and resize automatically. Tour pages opened from the catalog **flow inside your site** — one natural scroll under your own header, footer always visible — rather than taking over the screen.
* **SEO-friendly synced sections (no iframe).** `[wncpay_tour_section]` pulls REAL HTML from the platform (cached ~15 min with a 24-hour stale backup for outages), so a tour's description is crawlable and styleable on your own page. It auto-detects the tour from the page's linked "WNC Tour", its URL, or falls back to a category grid, with "Order this trip" and "🎁 Gift this adventure" buttons pointing at pages you choose.
* **Take payments through WooCommerce.** A "WNC Pay" gateway sends checkout to the platform's secure PayMe page and back; orders are completed by a **cryptographically signed webhook** (HMAC, replay-protected — a late failure can never overwrite a paid order). **No card data ever touches WordPress.** HPOS-compatible, ILS carts.
* **Deposits and full-payment items.** Tours that need office confirmation charge a configurable **deposit** now (default 30%, "pay in full" offered on the platform), the office charges the balance later, and the order auto-completes when the balance webhook arrives. Instant/non-tour products can be flagged to charge 100% immediately and skip the date question.
* **Sell gift cards.** A floating "🎁 Gift this adventure" tab on tour pages and the `[wncpay_gift_designer]` element open the gift-card designer, preselecting the tour's photos and name; buyer details and CRM deal can be prefilled.
* **Pass real booking context to your CRM.** Traveller counts, preferred dates, and buyer details flow to the platform and land on the CRM deal automatically.
* **Marketing analytics bridge (GTM · GA4 · Google Ads).** The platform's GA4-style events (view_item, add_to_cart, begin_checkout, purchase, generate_lead…) fired inside the embedded frames are pushed onto THIS site's dataLayer, so your existing Google Tag Manager container sees them exactly like WooCommerce events — works alongside GTM4WP / Site Kit or injects the container itself. Ad-click ids and the GA client id are passed into the frames so paid bookings sent from the platform server are attributed correctly. Own settings screen + a "Marketing / SEO" WordPress role.
* **Test mode.** A gateway Test mode (and a magic test id at checkout) runs orders against the PayMe sandbox, stamps them loudly as TEST on the WooCommerce order, and excludes them from revenue and the CRM.

= Three ways to place any element =

* **Elementor widgets** — a native "WNC Pay" category.
* **Shortcodes** — e.g. `[wncpay_gift_designer amount="750"]`, or the generic `[wncpay_embed path="/gift"]`.
* **Blocks** — search for "WNC Pay" in the block inserter.

= Shortcode examples =

* `[wncpay_gift_designer]` — the gift designer, no options needed.
* `[wncpay_gift_designer amount="750"]` — pre-selected amount.
* `[wncpay_gift_designer matchkey="masada-sunrise"]` — a specific tour's photo card.
* `[wncpay_gift_designer dealid="123456789012" name="Dana" email="dana@example.com"]` — filed on a CRM deal, buyer prefilled.
* `[wncpay_embed path="/gift" product="abc123" min_height="1200"]` — generic embed of any platform path; unknown attributes pass through as URL parameters.

The site language (WPML) is passed automatically. The full attribute reference lives on Settings → WNC Pay.

Elements render as secure embeds of the platform with automatic height, and follow the site language (WPML-aware). The plugin's job ends at rendering the embed: styling and placement belong to the site developer; the content and flows inside the frame belong to the platform. No payment data, checkout flow, or personal information is processed or stored by this plugin or by WordPress.

= Elements =

* Tour Catalog — browse and pick tours (`[wncpay_tour_catalog]`)
* Tour Page — a single tour's full page (`[wncpay_tour id="..."]`)
* Tour Section (synced) — SEO-friendly real HTML, no iframe (`[wncpay_tour_section]`)
* Trip Planner — build-your-itinerary wizard (`[wncpay_trip_planner]`)
* How It Works — the planner explainer (`[wncpay_how_it_works]`)
* Gift Card Designer (`[wncpay_gift_designer]`)
* Pay Page — a specific payment request (`[wncpay_pay reference="..."]`)
* Generic Embed — any platform path (`[wncpay_embed path="/..."]`)
* WooCommerce payment gateway — "WNC Pay" at checkout
* Floating "🎁 Gift this adventure" tab on tour pages

== External Services ==

This plugin embeds pages served from the platform URL configured by the site administrator under Settings → WNC Pay. When a visitor views a page containing a WNC Pay element, the visitor's browser loads that element directly from the configured platform, which will receive the visitor's IP address and user agent as with any embedded content. All checkout and payment flows run entirely on the connected platform and are subject to the platform operator's terms of service and privacy policy. No data is sent to the platform by the plugin itself.

The plugin also periodically contacts github.com (the public wncpay-update repository) to check for new plugin versions; only standard HTTP request metadata is transmitted. This mechanism is removed when the plugin is distributed through wordpress.org.

When the WNC Pay payment gateway is enabled, checkout sends the order summary and the customer's billing name, email and phone to the configured platform over an authenticated server-to-server call, so the platform can process the payment and issue documents. No card data ever touches WordPress. Payment confirmations arrive as cryptographically signed webhooks from the platform.

== Installation ==

1. Upload and activate the plugin.
2. Go to Settings → WNC Pay and enter the Platform URL and Site Key provided by your platform operator.
3. Place an element via an Elementor widget, shortcode, or block.

= Shortcodes =

* [wncpay_tour_catalog] — interactive tour catalog (window mode by default; mode="auto" for full-height; context-aware "Get more info")
* [wncpay_tour id="..."] — a single tour's full page (id = product id from the platform catalog)
* [wncpay_trip_planner] — build-your-itinerary wizard
* [wncpay_gift_designer] — gift card designer (amount, matchkey, product, dealid, name/email/phone)
* [wncpay_how_it_works] — the planner's "How it works" explainer page
* [wncpay_pay reference="..."] — a specific payment request's pay page
* [wncpay_embed path="/..."] — any platform path; extra attributes become URL parameters

All accept min_height and title. Full reference with examples: Settings → WNC Pay.

= Performance / caching note =

Embeds are page-cache safe. If your site delays JavaScript execution (e.g. WP Rocket's "Delay JavaScript execution"), add `wncpay` to the exclusion list so embeds resize immediately.

== Changelog ==

= 0.14.0 =
* New: **Website form bridge** (Settings → WNC Pay Form bridge, off by default). Mirrors this site's Elementor Pro form submissions to the booking platform — signed, server-side — so a tour inquiry sent through the site's own contact form lands in the platform's New Inquiries. Nothing in the site's flow changes: Elementor still sends its emails and the site's CRM plugin still creates the lead; the platform only receives a copy, decides whether it is a tour inquiry (tour page / trip date / keywords, configured on the platform), and checks a few minutes later that the CRM lead exists (creating it, with the Google click id, only if it does not). Passes along Zoho's zc_gad click token, the visitor's gclid / UTM tags (from the analytics cookie), the page and its linked tour.
* New: optional **confirmation sheet** — before an allowed form sends, the visitor sees the platform's one-screen "is this right?" with the page's tour and "When are you thinking of?"; on confirm the original form submits exactly as before. Per-form on/off by Elementor form id.

= 0.13.1 =
* Analytics bridge: follows **GTM4WP** (Google Tag Manager for WordPress, wordpress.org/plugins/duracelltomi-google-tag-manager) automatically — with GTM4WP active and "dataLayer only" selected, the bridge pushes to the dataLayer variable name configured in GTM4WP (1.x and 2.x), and the Analytics screen shows the detected GTM4WP version, container id and dataLayer name. No more setting the name in two places.

= 0.13.0 =
* New: **Analytics bridge** (Settings → WNC Pay Analytics). Events the platform emits inside its frames (GA4 ecommerce: view_item_list, view_item, add_to_cart, remove_from_cart, view_cart, begin_checkout, add_payment_info, purchase, balance_payment, refund; leads: generate_lead, quote_accepted, cfc_signed, gift_designer_start; engagement: whatsapp_click, phone_click; in-frame virtual_page_view) are pushed onto this site's dataLayer, so the site's own GTM container fires GA4 / Google Ads tags for them. Container modes: "dataLayer only" (recommended with GTM4WP / Site Kit), "Inject" (the plugin prints the GTM snippet), "Off". Per-group forwarding filters, custom dataLayer name, debug logging (?wncpay_debug=1), optional tel:/wa.me click events on the site's own pages.
* New: attribution passthrough — gclid / gbraid / wbraid, UTM tags (remembered in a first-party cookie for 90 days) and the GA4 client + session id are appended to every embed URL, so the platform's server-side purchase / refund events (GA4 Measurement Protocol, Google Ads) are attributed to the visitor's ad click and session.
* New: "Marketing / SEO (WNC Pay)" WordPress role + `wncpay_manage_analytics` capability — an external SEO person can manage only the analytics screen. Administrators get the capability automatically.
* The Analytics screen shows the platform's own analytics settings (read-only) with links to the platform Analytics page and the tracking guide.

= 0.12.2 =
* Fix: Hebrew header — the account icon (and with it the injected cart icon) was placed next to the gift link inside the closed mega-menu drop-down, so neither was visible on the RTL site. Placement now only considers VISIBLE gift links outside sliders and menus.

= 0.12.1 =
* Fix: the header login (account) icon is placed next to the header's gift ICON. It used to attach to the first header link pointing at the gift page — on israel-extreme.com that was the news ticker's "Read More", so the icon sat inside one rotating slide. Links inside sliders/listings are now skipped and an icon link is preferred over a text link. "Place login icon after (CSS selector)" still overrides everything.

= 0.12.0 =
* New: Group tours on the main site. [wncpay_group_tours] embeds the platform's Group tours page (scheduled departures sold per person — early-bird / regular prices, seats left, booking inside the page); [wncpay_group_tour id="…"] embeds one departure's flyer page. Settings → WNC Pay gains a one-click "Create the Group Tours page" button that publishes /group-tours/ with the shortcode, so the site has its own page to link ads and menus to.

= 0.11.9 =
* Fix: embeds (catalog, tour pages) no longer show "This section could not load" over a perfectly good frame on cold loads of a heavy page. The failover now cancels the moment the frame loads (not only when its resize handshake arrives), and its timeout is raised from 10s to 20s so slow connections aren't cut off early. Only a frame that genuinely never loads still falls back to the open-in-new-tab card.

= 0.11.8 =
* Docs: the readme now fully describes what the plugin does (catalog & tour pages, SEO-friendly synced sections, the WooCommerce payment gateway, deposits, gift cards, CRM context, test mode) and lists every current element. No functional change.

= 0.11.7 =
* Hebrew/RTL header fix: the injected account icon no longer wraps the header column onto a second line.
* Cart icon on every header: when a header template has no cart widget (e.g. the Hebrew site), the plugin injects its own cart icon with a live count badge next to the account icon.

= 0.10.3 =
* Tour pages opened inside the catalog now FLOW as part of the site page (platform ≥ v3.69.104): the frame grows to the tour's full height right under the site header, with the site footer after the content — one natural scroll, no full-screen takeover, the site's own header and footer always visible.

= 0.10.2 =
* Hardened loading: if a plugin update ever leaves the folder incomplete, the plugin now goes inert with an admin notice instead of taking the whole site down with a critical error.

= 0.10.1 =
* Embedded pages now re-announce themselves on every in-frame navigation (platform ≥ v3.69.103): the full-screen tour view reliably closes again on Back / All tours, so visitors always see the site's own header and footer around the catalog.
* After an in-frame page change (e.g. the thank-you page after paying), the page glides back to the frame's top instead of stranding the visitor in empty space.
* The synced tour section's category cards now stay on THIS site (the tour's own page, or your configured order page) — never a new tab, never another domain.

= 0.10.0 =
* New: [wncpay_tour_section] shortcode + "Tour Section (synced)" Elementor widget — REAL HTML synced from the platform (no iframe, SEO-friendly), cached ~15 minutes with a 24-hour stale backup for outages. Auto-detects the tour from the page's linked WNC Tour, its URL, or falls back to a category grid. "Order this trip" and "🎁 Gift this adventure" buttons point at your configured pages (Settings → WNC Pay).
* New: "WNC Tour" dropdown in the page/post editor sidebar AND in Quick Edit — link any page to a platform catalog item; the tour section, the floating gift button, and all future matching use this explicit link instead of guessing from slugs.
* The floating gift button now passes the linked product id when the page has one.

= 0.9.0 =
* New: floating "🎁 Gift this adventure" tab on tour pages (Settings → WNC Pay → Gift button) — left edge in English, right edge in Hebrew, about a third down the screen. It opens your gift-card page with the tour context, and the gift designer preselects that tour's photos + name on the card.
* Gift-designer embeds now receive the visitor's tour context (?fromtour= from the button, or the same-site referrer) as ref=, like the catalog does.

= 0.8.1 =
* Smoother catalog scrolling: when the page pauses with the catalog window partly visible, it now docks flush under the site menu automatically — one scroll instead of two competing ones. Scrolling up from the catalog top (or deliberately past it) still reaches the rest of the page.

= 0.8.0 =
* Three new shortcodes: [wncpay_tour id="..."] (a single tour's full page), [wncpay_how_it_works] (the planner explainer), and [wncpay_pay reference="..."] (a specific payment request's pay page).
* mode="window|auto" is now a proper attribute on every shortcode.
* Settings → WNC Pay gained a full shortcode reference table — every element, its attributes, and examples in one place.

= 0.7.5 =
* "Get more info" is now context-aware: the catalog embed learns which page of the site the visitor came from and opens the matching tour directly, or pre-filters to the matching category, instead of always showing everything. Same-site referrers only; nothing to configure.

= 0.7.4 =
* Individual tour pages opened from the embedded catalog now take the whole screen while viewed (a full tour page was unusable squeezed into the catalog window); Back returns to the catalog and restores the window.

= 0.7.3 =
* Forms and popups opened inside an embed (quote basket, request form, previews) now expand the frame to cover the full screen for as long as they're open — they stack above the site menu and floating contact buttons, then the frame shrinks back on close.

= 0.7.2 =
* Tour catalog now embeds in "window mode": the frame is sized to the visitor's screen (below the site menu) and the catalog scrolls inside it. The toolbar sticks natively with zero lag, and the quote cart and popups open centered in view. [wncpay_tour_catalog mode="auto"] restores the old full-height behavior.

= 0.7.1 =
* Embedded pages can now pin their own toolbar below the site's menu while the visitor scrolls: the plugin streams each embed frame's viewport position (scroll pin offset, including the height of any fixed/sticky site header) into the frame. Purely visual; nothing to configure.

= 0.7.0 =
* Test transactions are now stamped on the WooCommerce order itself: when the platform reports a payment as TEST (gateway Test mode OR the magic test ID typed at checkout), the order gets a loud TEST order note and the _wncpay_test meta — a test order can never be mistaken for real revenue.

= 0.6.0 =
* New embeds: [wncpay_trip_planner] (interactive trip-builder wizard) and [wncpay_tour_catalog] (browse and pick multiple tours in one place) — host the platform's planner and catalog inside the site so visitors never leave.
* Cross-site failover: if an embed cannot load (privacy mode, proxy, content blocker), it is replaced automatically with an "Open it in a new tab" card instead of a blank frame. Armed per-frame on visibility, so lazy-loaded embeds are unaffected.

= 0.5.0 =
* Test mode (gateway setting): checkouts are sent as TEST transactions — the platform processes them against the PayMe sandbox, the PayMe test card approves for real, no actual money moves, everything is stamped [TEST] and excluded from revenue and the CRM. A yellow TEST banner shows at checkout while enabled.

= 0.4.0 =
* Deposit flow: orders containing tours that need office availability confirmation charge a configurable deposit now (default 30%; the platform pay page also offers "pay in full"), with the stipulation shown at checkout; the office confirms and charges the balance on the platform, and the order completes automatically when the balance webhook arrives (on-hold until then).
* Product editor checkbox "WNC Pay: full payment" — flagged products (non-tours / instant items) charge 100% immediately, skip confirmation and the date question.
* Preferred-date question at checkout for every tour item (sites without a booking plugin): required, saved on the order line, shown in emails, and sent to the platform + CRM deal.

= 0.3.6 =
* Gateway sends the traveller count with each order (WooCommerce Appointments persons meta when present, item quantities otherwise) — lands in the CRM deal's Amount of People field automatically.

= 0.3.5 =
* Full shortcode reference with examples on Settings → WNC Pay (and in this readme) — amount, matchkey, product, dealid, name/email/phone prefills, min_height, title.
* Fix: dealid attribute now reaches the platform correctly (WordPress lowercases shortcode attributes; the plugin maps it back to dealId).

= 0.3.4 =
* Multi-item carts use the platform's multiple-tours document variant (docType cfc_multiple).

= 0.3.3 =
* After a WNC Pay payment, the order-received page and the customer's order emails link to their platform account (locale-aware; filter: wncpay_account_url).

= 0.3.2 =
* Brand logo: checkout icon for the WNC Pay gateway, Settings page header, and plugin icons on the WordPress update screens.

= 0.3.1 =
* Rebuild: the 0.3.0 package was built from the pre-release commit and shipped 0.2.0 code. Identical feature set to 0.3.0.

= 0.3.0 =
* WooCommerce payment gateway: "WNC Pay" appears under WooCommerce → Settings → Payments. Checkout redirects to the platform's secure payment page and returns; orders are completed by a signed platform webhook (HMAC, replay-protected, late failures never overwrite a paid order). ILS carts only. HPOS compatible.
* Connection status indicator on Settings → WNC Pay (live authorize check against the platform).

= 0.2.0 =
* Native WordPress updates via the public wncpay-update release channel (Plugin Update Checker).

= 0.1.0 =
* First release: settings page, embed core with auto-height and WPML-aware locale, Gift Card Designer as Elementor widget + shortcode + block.
