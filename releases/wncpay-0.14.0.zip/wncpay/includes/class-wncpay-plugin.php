<?php
/**
 * Main plugin bootstrap.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Plugin
 */
final class WNCPAY_Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var WNCPAY_Plugin|null
	 */
	private static ?WNCPAY_Plugin $instance = null;

	/**
	 * Get the singleton instance.
	 *
	 * @return WNCPAY_Plugin
	 */
	public static function instance(): WNCPAY_Plugin {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * WNCPAY_Plugin constructor.
	 */
	private function __construct() {
		add_action( 'init', [ $this, 'load_textdomain' ] );

		// v0.10.2 -- class_exists guards: an incomplete update (missing include)
		// must degrade the feature, never fatal the site.
		foreach ( [ 'WNCPAY_Settings', 'WNCPAY_Shortcodes', 'WNCPAY_Gift_Button',
			'WNCPAY_Login_Icon', 'WNCPAY_Section', 'WNCPAY_Group_Tours', 'WNCPAY_Product_Meta', 'WNCPAY_Analytics', 'WNCPAY_Form_Bridge', 'WNCPAY_Blocks', 'WNCPAY_Elementor', 'WNCPAY_WooCommerce' ] as $wncpay_class ) {
			if ( class_exists( $wncpay_class ) ) {
				new $wncpay_class();
			}
		}

		add_action( 'wp_footer', [ 'WNCPAY_Embed', 'print_resize_script' ], 5 );
	}

	/**
	 * Load translations.
	 *
	 * @return void
	 */
	public function load_textdomain(): void {
		load_plugin_textdomain( 'wncpay', false, dirname( plugin_basename( WNCPAY_FILE ) ) . '/languages' );
	}
}
