<?php
/**
 * Website form bridge (v0.14.0).
 *
 * Mirrors this site's Elementor Pro form submissions to the booking platform
 * (signed, server-side) so a real tour inquiry sent through the site's own contact
 * form lands in the platform's New Inquiries — without changing anything in the
 * site's flow: Elementor still emails the office and the site's CRM plugin still
 * creates the lead. The platform decides what to file (tour page / trip date /
 * keywords) and runs a delayed Zoho-lead safety net.
 *
 * Optional "confirmation sheet": before an allowed form is submitted, the platform's
 * one-screen "is this right?" (with the page's tour and "When are you thinking of?")
 * opens over the page; on confirm the ORIGINAL form submits exactly as before, with
 * two extra hidden inputs riding along (wncpay_iid, wncpay_when) that only this
 * bridge reads. Close the sheet and the form is left untouched for editing.
 *
 * Off by default. Settings → WNC Pay Form bridge.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Form_Bridge
 */
final class WNCPAY_Form_Bridge {

	public const OPTION = 'wncpay_form_bridge';
	public const PAGE   = 'wncpay-form-bridge';
	public const STATUS = 'wncpay_form_bridge_status';

	/**
	 * Hooks.
	 */
	public function __construct() {
		add_action( 'admin_menu', [ $this, 'register_page' ] );
		add_action( 'admin_init', [ $this, 'register_settings' ] );
		add_action( 'elementor_pro/forms/new_record', [ $this, 'on_record' ], 10, 2 );
		add_action( 'wp_footer', [ $this, 'print_script' ], 7 );
	}

	/**
	 * Defaults.
	 *
	 * @return array
	 */
	public static function defaults(): array {
		return [
			'mode'          => 'off', // off | file | confirm
			'form_ids'      => '',    // comma-separated Elementor form ids; empty = every Elementor form
			'confirm_ids'   => '',    // comma-separated ids that get the confirmation sheet; empty = same as form_ids
			'skip_names'    => 'newsletter', // form names (substring, case-insensitive) never mirrored
			'debug'         => '',
		];
	}

	/**
	 * Option with defaults.
	 *
	 * @param string $key Key.
	 * @return mixed
	 */
	public static function opt( string $key ) {
		$o = get_option( self::OPTION, [] );
		$d = self::defaults();
		return is_array( $o ) && array_key_exists( $key, $o ) ? $o[ $key ] : ( $d[ $key ] ?? '' );
	}

	/**
	 * Whether submissions are mirrored at all.
	 */
	public static function enabled(): bool {
		return in_array( (string) self::opt( 'mode' ), [ 'file', 'confirm' ], true ) && '' !== WNCPAY_Embed::platform_url() && '' !== WNCPAY_Embed::get_option( 'site_key' );
	}

	/**
	 * Parse a comma / space separated id list.
	 *
	 * @param string $s Raw.
	 * @return string[]
	 */
	private static function ids( string $s ): array {
		$out = [];
		foreach ( preg_split( '/[\s,]+/', $s ) as $id ) {
			$id = strtolower( trim( $id ) );
			if ( preg_match( '/^[a-z0-9]{3,16}$/', $id ) ) {
				$out[] = $id;
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Is this form mirrored?
	 *
	 * @param string $form_id   Elementor form widget id.
	 * @param string $form_name Form name.
	 */
	public static function form_allowed( string $form_id, string $form_name ): bool {
		foreach ( preg_split( '/[\s,]+/', (string) self::opt( 'skip_names' ) ) as $skip ) {
			$skip = trim( $skip );
			if ( '' !== $skip && false !== stripos( $form_name, $skip ) ) {
				return false;
			}
		}
		$ids = self::ids( (string) self::opt( 'form_ids' ) );
		return empty( $ids ) || in_array( strtolower( $form_id ), $ids, true );
	}

	/**
	 * Sanitize.
	 *
	 * @param mixed $in Raw.
	 * @return array
	 */
	public function sanitize( $in ): array {
		$in   = is_array( $in ) ? $in : [];
		$out  = self::defaults();
		$mode = isset( $in['mode'] ) ? (string) $in['mode'] : 'off';
		$out['mode']        = in_array( $mode, [ 'off', 'file', 'confirm' ], true ) ? $mode : 'off';
		$out['form_ids']    = implode( ', ', self::ids( (string) ( $in['form_ids'] ?? '' ) ) );
		$out['confirm_ids'] = implode( ', ', self::ids( (string) ( $in['confirm_ids'] ?? '' ) ) );
		$out['skip_names']  = sanitize_text_field( (string) ( $in['skip_names'] ?? 'newsletter' ) );
		$out['debug']       = ! empty( $in['debug'] ) ? '1' : '';
		return $out;
	}

	// ── Field mapping ────────────────────────────────────────────────────────

	/**
	 * Map Elementor's record fields to the platform's shape. Works for any form:
	 * types first (email / tel / date / textarea), then labels, then position.
	 *
	 * @param array $fields Elementor record fields: id => [id, type, title, value, raw_value].
	 * @return array{fields: array, other: array}
	 */
	public static function map_fields( array $fields ): array {
		$m     = [ 'firstName' => '', 'lastName' => '', 'name' => '', 'email' => '', 'phone' => '', 'tripDate' => '', 'message' => '', 'leadSource' => '' ];
		$other = [];
		$texts = [];
		foreach ( $fields as $id => $f ) {
			$id    = strtolower( (string) $id );
			$type  = strtolower( (string) ( $f['type'] ?? 'text' ) );
			$title = strtolower( (string) ( $f['title'] ?? '' ) );
			$val   = trim( (string) ( $f['value'] ?? '' ) );
			if ( '' === $val ) {
				continue;
			}
			$hay = $id . ' ' . $title;
			if ( 'email' === $type || preg_match( '/mail|אימייל|דוא/u', $hay ) ) {
				$m['email'] = $m['email'] ?: $val;
			} elseif ( 'tel' === $type || preg_match( '/phone|tel|mobile|whatsapp|טלפון|נייד/u', $hay ) ) {
				$m['phone'] = $m['phone'] ?: $val;
			} elseif ( 'date' === $type || preg_match( '/date|תאריך/u', $hay ) ) {
				$m['tripDate'] = $m['tripDate'] ?: $val;
			} elseif ( 'textarea' === $type || preg_match( '/message|details|comment|הודעה|פרטים/u', $hay ) ) {
				$m['message'] = $m['message'] ? $m['message'] . "\n" . $val : $val;
			} elseif ( preg_match( '/leadsource|lead_source/', $hay ) ) {
				$m['leadSource'] = $val;
			} elseif ( preg_match( '/posttitle|post_title|referer|queried/', $hay ) ) {
				continue; // the page title travels in page.postTitle (read by the caller)
			} elseif ( in_array( $type, [ 'acceptance', 'checkbox', 'hidden', 'recaptcha', 'recaptcha_v3', 'honeypot', 'html', 'step' ], true ) ) {
				continue;
			} elseif ( preg_match( '/first|fname|given|שם פרטי/u', $hay ) ) {
				$m['firstName'] = $m['firstName'] ?: $val;
			} elseif ( preg_match( '/last|lname|surname|family|שם משפחה/u', $hay ) ) {
				$m['lastName'] = $m['lastName'] ?: $val;
			} elseif ( preg_match( '/^name$|full ?name|שם מלא|^שם$/u', $hay ) || preg_match( '/name|שם/u', $hay ) ) {
				$m['name'] = $m['name'] ?: $val;
			} else {
				$texts[ $id ] = $val;
			}
		}
		// No name field recognised: the first two plain text fields are first/last name.
		if ( '' === $m['firstName'] && '' === $m['name'] && $texts ) {
			$vals            = array_values( $texts );
			$m['firstName'] = $vals[0];
			$m['lastName']  = $vals[1] ?? '';
			$texts          = array_slice( $texts, 2, null, true );
		}
		foreach ( $texts as $id => $v ) {
			$other[ $id ] = $v;
		}
		return [ 'fields' => $m, 'other' => $other ];
	}

	/**
	 * Attribution from this plugin's own first-party cookie (set by the analytics bridge)
	 * + the raw POST (Zoho's zc_gad token lives outside Elementor's field list).
	 *
	 * @return array
	 */
	private static function attribution(): array {
		$a = [ 'zcGad' => '', 'gclid' => '', 'gbraid' => '', 'wbraid' => '', 'utm' => [] ];
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		if ( isset( $_POST['zc_gad'] ) ) {
			$a['zcGad'] = substr( sanitize_text_field( wp_unslash( (string) $_POST['zc_gad'] ) ), 0, 500 );
		}
		// phpcs:enable
		$cookie = isset( $_COOKIE['wncpay_attr'] ) ? (string) $_COOKIE['wncpay_attr'] : '';
		if ( '' !== $cookie ) {
			parse_str( rawurldecode( $cookie ), $q );
			foreach ( [ 'gclid', 'gbraid', 'wbraid' ] as $k ) {
				if ( ! empty( $q[ $k ] ) ) {
					$a[ $k ] = substr( sanitize_text_field( (string) $q[ $k ] ), 0, 200 );
				}
			}
			foreach ( [ 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content' ] as $k ) {
				if ( ! empty( $q[ $k ] ) ) {
					$a['utm'][ $k ] = substr( sanitize_text_field( (string) $q[ $k ] ), 0, 200 );
				}
			}
		}
		return $a;
	}

	// ── Server hook ──────────────────────────────────────────────────────────

	/**
	 * Elementor Pro: a form was submitted and validated. Mirror it to the platform.
	 *
	 * @param \ElementorPro\Modules\Forms\Classes\Form_Record $record  Record.
	 * @param mixed                                          $handler Ajax handler.
	 */
	public function on_record( $record, $handler ): void { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		if ( ! self::enabled() || ! is_object( $record ) || ! method_exists( $record, 'get_form_settings' ) ) {
			return;
		}
		$form_id   = (string) $record->get_form_settings( 'id' );
		$form_name = (string) $record->get_form_settings( 'form_name' );
		if ( ! self::form_allowed( $form_id, $form_name ) ) {
			return;
		}
		$raw     = (array) $record->get( 'fields' );
		$mapped  = self::map_fields( $raw );
		$fields  = $mapped['fields'];
		$other   = $mapped['other'];

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$post_id    = isset( $_POST['post_id'] ) ? (int) $_POST['post_id'] : 0;
		$queried_id = isset( $_POST['queried_id'] ) ? (int) $_POST['queried_id'] : 0;
		$iid        = isset( $_POST['wncpay_iid'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['wncpay_iid'] ) ) : '';
		$when       = isset( $_POST['wncpay_when'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['wncpay_when'] ) ) : '';
		// phpcs:enable
		$page_id    = $queried_id ?: $post_id;
		$referer    = wp_get_referer();
		$page_url   = $referer ? esc_url_raw( $referer ) : ( $page_id ? (string) get_permalink( $page_id ) : '' );
		$page_title = $page_id ? (string) get_the_title( $page_id ) : '';
		$post_title = '';
		foreach ( $raw as $id => $f ) {
			if ( preg_match( '/posttitle|post_title/i', (string) $id ) ) {
				$post_title = trim( (string) ( $f['value'] ?? '' ) );
			}
		}
		$product = ( $page_id && class_exists( 'WNCPAY_Product_Meta' ) ) ? WNCPAY_Product_Meta::product_for( $page_id ) : '';

		$payload = [
			'iid'         => preg_match( '/^[A-Za-z0-9_-]{8,64}$/', $iid ) ? $iid : null,
			'origin'      => 'server',
			'form'        => [ 'id' => $form_id, 'name' => $form_name, 'postId' => $page_id ],
			'page'        => [ 'url' => $page_url, 'title' => $page_title, 'postTitle' => $post_title ?: $page_title, 'productId' => $product ],
			'fields'      => array_merge( $fields, [ 'other' => (object) $other ] ),
			'attribution' => self::attribution(),
			'when'        => substr( $when, 0, 80 ),
			'lang'        => WNCPAY_Embed::locale(),
			'submittedAt' => time(),
		];

		$res = WNCPAY_Api::post( '/api/intake/website-form', $payload, 8 );
		$status = [
			'at'     => time(),
			'form'   => $form_name ?: $form_id,
			'page'   => $post_title ?: $page_title,
			'ok'     => ! is_wp_error( $res ),
			'detail' => is_wp_error( $res ) ? $res->get_error_message() : sprintf( '%s — %s', (string) ( $res['decision'] ?? '?' ), (string) ( $res['reason'] ?? '' ) ),
		];
		update_option( self::STATUS, $status, false );
		if ( is_wp_error( $res ) ) {
			error_log( '[wncpay] form bridge: ' . $res->get_error_message() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		}
	}

	// ── Confirmation sheet (front end) ───────────────────────────────────────

	/**
	 * Footer script: intercepts the submit of the configured forms, opens the
	 * platform's confirmation sheet, and re-submits the ORIGINAL form on confirm.
	 */
	public function print_script(): void {
		if ( 'confirm' !== (string) self::opt( 'mode' ) || ! self::enabled() || is_admin() ) {
			return;
		}
		$origin = WNCPAY_Embed::platform_origin();
		if ( '' === $origin ) {
			return;
		}
		$ids     = self::ids( (string) self::opt( 'confirm_ids' ) );
		if ( empty( $ids ) ) {
			$ids = self::ids( (string) self::opt( 'form_ids' ) );
		}
		$skip    = array_values( array_filter( array_map( 'trim', preg_split( '/[\s,]+/', (string) self::opt( 'skip_names' ) ) ) ) );
		$product = '';
		$qid     = get_queried_object_id();
		if ( $qid && class_exists( 'WNCPAY_Product_Meta' ) ) {
			$product = WNCPAY_Product_Meta::product_for( (int) $qid );
		}
		$sheet = WNCPAY_Embed::platform_url() . ( 'he' === WNCPAY_Embed::locale() ? '/he' : '' ) . '/embed/confirm-inquiry?host=' . rawurlencode( WNCPAY_Api::site_host() );
		$debug = '1' === (string) self::opt( 'debug' );
		?>
		<script id="wncpay-form-bridge">
		( function () {
			var ORIGIN = <?php echo wp_json_encode( $origin ); ?>, SHEET = <?php echo wp_json_encode( $sheet ); ?>;
			var IDS = <?php echo wp_json_encode( $ids ); ?>, SKIP = <?php echo wp_json_encode( $skip ); ?>, PRODUCT = <?php echo wp_json_encode( $product ); ?>;
			var LANG = <?php echo wp_json_encode( WNCPAY_Embed::locale() ); ?>, DEBUG = <?php echo $debug ? 'true' : 'false'; ?> || /[?&]wncpay_debug=1/.test( location.search );
			var PAGE = { title: <?php echo wp_json_encode( $qid ? (string) get_the_title( (int) $qid ) : wp_get_document_title() ); ?>, url: location.href.split( '#' )[ 0 ], productId: PRODUCT };
			function log() { if ( DEBUG && window.console ) { console.log.apply( console, [ '[wncpay form bridge]' ].concat( [].slice.call( arguments ) ) ); } }
			function uid() { var s = ''; var c = 'abcdefghijklmnopqrstuvwxyz0123456789'; try { var a = new Uint8Array( 20 ); crypto.getRandomValues( a ); for ( var i = 0; i < 20; i++ ) { s += c[ a[ i ] % 36 ]; } } catch ( e ) { for ( var j = 0; j < 20; j++ ) { s += c[ Math.floor( Math.random() * 36 ) ]; } } return s; }
			function formId( form ) { var i = form.querySelector( 'input[name="form_id"]' ); return i ? String( i.value ).toLowerCase() : ''; }
			function formName( form ) { return String( form.getAttribute( 'name' ) || form.getAttribute( 'aria-label' ) || '' ); }
			function wanted( form ) {
				if ( ! form.classList.contains( 'elementor-form' ) ) { return false; }
				var name = formName( form ).toLowerCase();
				for ( var i = 0; i < SKIP.length; i++ ) { if ( SKIP[ i ] && name.indexOf( SKIP[ i ].toLowerCase() ) !== -1 ) { return false; } }
				return ! IDS.length || IDS.indexOf( formId( form ) ) !== -1;
			}
			function labelFor( form, el ) {
				var id = el.getAttribute( 'id' ); var l = id ? form.querySelector( 'label[for="' + id + '"]' ) : null;
				var t = l ? l.textContent : ( el.getAttribute( 'placeholder' ) || el.getAttribute( 'aria-label' ) || el.name );
				return String( t || '' ).replace( /\*/g, '' ).trim().slice( 0, 80 );
			}
			function collect( form ) {
				var out = []; var els = form.querySelectorAll( 'input, textarea, select' );
				for ( var i = 0; i < els.length; i++ ) {
					var el = els[ i ]; var n = el.name || '';
					if ( n.indexOf( 'form_fields[' ) !== 0 ) { continue; }
					var type = ( el.getAttribute( 'type' ) || el.tagName ).toLowerCase(); var kind = type;
					if ( type === 'checkbox' || type === 'radio' ) { if ( ! el.checked ) { continue; } kind = /accept|privacy|terms|agree/i.test( n + ' ' + labelFor( form, el ) ) ? 'acceptance' : 'choice'; }
					if ( type === 'hidden' ) { kind = 'hidden'; }
					if ( type === 'textarea' ) { kind = 'message'; }
					if ( type === 'date' || /\[date\]|תאריך|date of/i.test( n + ' ' + labelFor( form, el ) ) ) { kind = 'date'; }
					var v = String( el.value || '' ).trim(); if ( ! v ) { continue; }
					out.push( { label: labelFor( form, el ), value: v.slice( 0, 1000 ), kind: kind } );
				}
				return out;
			}
			var overlay = null, frame = null, current = null;
			function close() { if ( overlay && overlay.parentNode ) { overlay.parentNode.removeChild( overlay ); } overlay = null; frame = null; current = null; document.documentElement.style.overflow = ''; }
			function open( form ) {
				close();
				current = { form: form, iid: uid() };
				overlay = document.createElement( 'div' );
				overlay.setAttribute( 'style', 'position:fixed;inset:0;z-index:2147483000;background:rgba(0,0,0,.72);display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:24px 8px;' );
				frame = document.createElement( 'iframe' );
				frame.setAttribute( 'style', 'width:100%;max-width:560px;height:80vh;min-height:520px;border:0;border-radius:18px;background:transparent;' );
				frame.setAttribute( 'title', 'Confirm your request' );
				frame.src = SHEET;
				overlay.appendChild( frame );
				overlay.addEventListener( 'click', function ( e ) { if ( e.target === overlay ) { close(); } } );
				document.body.appendChild( overlay );
				document.documentElement.style.overflow = 'hidden';
				log( 'sheet opened for form', formId( form ), current.iid );
			}
			function send( form, iid, when ) {
				var add = function ( name, value ) { var i = form.querySelector( 'input[name="' + name + '"]' ); if ( ! i ) { i = document.createElement( 'input' ); i.type = 'hidden'; i.name = name; form.appendChild( i ); } i.value = value; };
				add( 'wncpay_iid', iid ); add( 'wncpay_when', when || '' );
				form.setAttribute( 'data-wncpay-confirmed', '1' );
				close();
				log( 'confirmed — submitting original form', iid, when );
				// requestSubmit() fires a real submit event (our capture listener lets it through
				// because of the flag) which Elementor's own jQuery handler then processes by AJAX.
				setTimeout( function () { form.removeAttribute( 'data-wncpay-confirmed' ); }, 1500 );
				try {
					if ( form.requestSubmit ) { form.requestSubmit(); } else if ( window.jQuery ) { window.jQuery( form ).trigger( 'submit' ); } else { form.submit(); }
				} catch ( e ) { if ( window.jQuery ) { window.jQuery( form ).trigger( 'submit' ); } else { form.submit(); } }
			}
			window.addEventListener( 'message', function ( e ) {
				if ( e.origin !== ORIGIN || ! e.data || ! current ) { return; }
				var d = e.data;
				if ( d.type === 'wncpay:confirm:ready' && frame && frame.contentWindow ) {
					frame.contentWindow.postMessage( { type: 'wncpay:confirm:data', iid: current.iid, lang: LANG, fields: collect( current.form ), page: PAGE }, ORIGIN );
				} else if ( d.type === 'wncpay:confirm:done' ) {
					send( current.form, String( d.iid || current.iid ), String( d.when || '' ).slice( 0, 80 ) );
				} else if ( d.type === 'wncpay:confirm:edit' ) {
					close();
				}
			} );
			// Capture phase, on the document: runs BEFORE Elementor's own submit handler.
			document.addEventListener( 'submit', function ( e ) {
				var form = e.target;
				if ( ! form || form.tagName !== 'FORM' || ! wanted( form ) ) { return; }
				if ( form.getAttribute( 'data-wncpay-confirmed' ) === '1' ) { form.removeAttribute( 'data-wncpay-confirmed' ); return; }
				if ( ! form.checkValidity || form.checkValidity() ) {
					e.preventDefault(); e.stopImmediatePropagation();
					open( form );
				}
			}, true );
			log( 'ready', IDS );
		} )();
		</script>
		<?php
	}

	// ── Admin screen ─────────────────────────────────────────────────────────

	public function register_page(): void {
		add_options_page( __( 'WNC Pay Form bridge', 'wncpay' ), __( 'WNC Pay Form bridge', 'wncpay' ), 'manage_options', self::PAGE, [ $this, 'render_page' ] );
	}

	public function register_settings(): void {
		register_setting( 'wncpay_form_bridge', self::OPTION, [ 'type' => 'array', 'sanitize_callback' => [ $this, 'sanitize' ], 'default' => self::defaults() ] );
	}

	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o        = array_merge( self::defaults(), (array) get_option( self::OPTION, [] ) );
		$name     = self::OPTION;
		$platform = WNCPAY_Embed::platform_url();
		$status   = (array) get_option( self::STATUS, [] );
		$elementor = class_exists( '\ElementorPro\Plugin' );
		?>
		<div class="wrap">
			<h1 style="display:flex;align-items:center;gap:12px;">
				<img src="<?php echo esc_url( WNCPAY_URL . 'assets/images/wncpay-logo.png' ); ?>" alt="" style="height:44px;width:auto;" />
				<?php esc_html_e( 'WNC Pay — Website form bridge', 'wncpay' ); ?>
			</h1>
			<p><?php esc_html_e( 'Mirrors this site\'s Elementor form submissions to the booking platform so tour inquiries sent through the contact form land in the platform\'s New Inquiries. Nothing in the site\'s own flow changes: Elementor still sends its emails and your CRM plugin still creates the lead — the platform only receives a signed copy, decides whether it is a tour inquiry (tour page / trip date / keywords, configured on the platform), and checks a few minutes later that the CRM lead exists (creating it only if it does not).', 'wncpay' ); ?></p>
			<?php if ( '' === $platform || '' === WNCPAY_Embed::get_option( 'site_key' ) ) : ?>
				<div class="notice notice-error inline"><p><?php esc_html_e( 'Set the Platform URL and Site Key under Settings → WNC Pay first.', 'wncpay' ); ?></p></div>
			<?php endif; ?>
			<?php if ( ! $elementor ) : ?>
				<div class="notice notice-warning inline"><p><?php esc_html_e( 'Elementor Pro does not seem to be active — the bridge listens to Elementor Pro forms.', 'wncpay' ); ?></p></div>
			<?php endif; ?>
			<form action="options.php" method="post">
				<?php settings_fields( 'wncpay_form_bridge' ); ?>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><?php esc_html_e( 'Mode', 'wncpay' ); ?></th><td>
						<fieldset>
							<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[mode]" value="off" <?php checked( 'off', $o['mode'] ); ?> /> <?php esc_html_e( 'Off — nothing is sent to the platform', 'wncpay' ); ?></label><br />
							<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[mode]" value="file" <?php checked( 'file', $o['mode'] ); ?> /> <?php esc_html_e( 'File on the platform — silent server-side copy of each submission (recommended first step)', 'wncpay' ); ?></label><br />
							<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[mode]" value="confirm" <?php checked( 'confirm', $o['mode'] ); ?> /> <?php esc_html_e( 'File + confirmation sheet — before the form sends, the visitor sees "is this right?" with the page\'s tour and "When are you thinking of?"; the original form then submits as usual', 'wncpay' ); ?></label>
						</fieldset>
					</td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Forms to mirror', 'wncpay' ); ?></th><td>
						<input type="text" class="regular-text code" name="<?php echo esc_attr( $name ); ?>[form_ids]" value="<?php echo esc_attr( $o['form_ids'] ); ?>" placeholder="1cfb5bd, 333b4f1" />
						<p class="description"><?php esc_html_e( 'Elementor form ids (the hidden form_id input), comma-separated. Empty = every Elementor form except the skipped names below.', 'wncpay' ); ?></p>
					</td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Confirmation sheet on', 'wncpay' ); ?></th><td>
						<input type="text" class="regular-text code" name="<?php echo esc_attr( $name ); ?>[confirm_ids]" value="<?php echo esc_attr( $o['confirm_ids'] ); ?>" placeholder="<?php esc_attr_e( 'same as above', 'wncpay' ); ?>" />
						<p class="description"><?php esc_html_e( 'Form ids that get the confirmation sheet (mode "File + confirmation sheet"). Empty = the same forms as above. Use this to keep the sheet off the Contact page form while it still files.', 'wncpay' ); ?></p>
					</td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Never mirror forms named', 'wncpay' ); ?></th><td>
						<input type="text" class="regular-text" name="<?php echo esc_attr( $name ); ?>[skip_names]" value="<?php echo esc_attr( $o['skip_names'] ); ?>" />
						<p class="description"><?php esc_html_e( 'Comma-separated, case-insensitive substrings of the form name (e.g. newsletter).', 'wncpay' ); ?></p>
					</td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Debug', 'wncpay' ); ?></th><td>
						<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[debug]" value="1" <?php checked( '1', $o['debug'] ); ?> /> <?php esc_html_e( 'console.log the sheet flow (visitors with ?wncpay_debug=1 see it too)', 'wncpay' ); ?></label>
					</td></tr>
				</table>
				<?php submit_button(); ?>
			</form>
			<hr />
			<h2><?php esc_html_e( 'Last submission mirrored', 'wncpay' ); ?></h2>
			<?php if ( ! empty( $status['at'] ) ) : ?>
				<p><?php echo esc_html( wp_date( 'Y-m-d H:i', (int) $status['at'] ) ); ?> — <strong><?php echo esc_html( (string) $status['form'] ); ?></strong> <?php esc_html_e( 'on', 'wncpay' ); ?> <em><?php echo esc_html( (string) $status['page'] ); ?></em>: <?php echo ! empty( $status['ok'] ) ? '✓ ' : '✗ '; ?><?php echo esc_html( (string) $status['detail'] ); ?></p>
			<?php else : ?>
				<p><?php esc_html_e( 'Nothing mirrored yet.', 'wncpay' ); ?></p>
			<?php endif; ?>
			<p class="description"><?php esc_html_e( 'The full log, the filing rules and the CRM-lead outcome are on the platform: Dashboard → Settings → Website form log / Configuration → Website form bridge.', 'wncpay' ); ?></p>
		</div>
		<?php
	}
}
