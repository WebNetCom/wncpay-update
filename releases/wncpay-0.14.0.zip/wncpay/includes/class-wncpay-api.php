<?php
/**
 * Signed platform API client + webhook verification.
 *
 * Every request in both directions is HMAC-SHA256 signed with the Site Key:
 * signature = hex( HMAC( key, "<unix timestamp>.<raw body>" ) ). See the
 * platform's docs/wncpay-gateway-api.md.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Api
 */
final class WNCPAY_Api {

	/**
	 * Acceptable clock skew for incoming webhooks (seconds).
	 *
	 * @var int
	 */
	private const SKEW = 300;

	/**
	 * This site's host as registered on the platform.
	 *
	 * @return string
	 */
	public static function site_host(): string {
		return (string) wp_parse_url( home_url(), PHP_URL_HOST );
	}

	/**
	 * Compute the request signature.
	 *
	 * @param string $timestamp Unix timestamp (seconds).
	 * @param string $body      Raw request body.
	 *
	 * @return string
	 */
	public static function sign( string $timestamp, string $body ): string {
		return hash_hmac( 'sha256', $timestamp . '.' . $body, WNCPAY_Embed::get_option( 'site_key' ) );
	}

	/**
	 * Verify an incoming webhook signature.
	 *
	 * @param string|null $timestamp X-Wncpay-Timestamp header.
	 * @param string|null $signature X-Wncpay-Signature header.
	 * @param string      $body      Raw request body.
	 *
	 * @return bool
	 */
	public static function verify( ?string $timestamp, ?string $signature, string $body ): bool {
		if ( empty( $timestamp ) || empty( $signature ) || '' === WNCPAY_Embed::get_option( 'site_key' ) ) {
			return false;
		}

		if ( abs( time() - (int) $timestamp ) > self::SKEW ) {
			return false;
		}

		return hash_equals( self::sign( $timestamp, $body ), $signature );
	}

	/**
	 * Signed POST to a platform API endpoint.
	 *
	 * @param string $path    Endpoint path (e.g. "/api/wncpay/session").
	 * @param array  $body    Request payload.
	 * @param int    $timeout Seconds (v0.14.0 — the form bridge uses a short one so a form never waits on us).
	 *
	 * @return array|WP_Error Decoded JSON response, or WP_Error.
	 */
	public static function post( string $path, array $body, int $timeout = 20 ) {
		$base = WNCPAY_Embed::platform_url();

		if ( '' === $base ) {
			return new WP_Error( 'wncpay_not_configured', __( 'Platform URL is not configured.', 'wncpay' ) );
		}

		$json      = wp_json_encode( $body );
		$timestamp = (string) time();

		$response = wp_remote_post(
			$base . $path,
			[
				'timeout' => max( 1, $timeout ),
				'headers' => [
					'Content-Type'       => 'application/json',
					'X-Wncpay-Host'      => self::site_host(),
					'X-Wncpay-Timestamp' => $timestamp,
					'X-Wncpay-Signature' => self::sign( $timestamp, $json ),
				],
				'body'    => $json,
			]
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$decoded = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( ! is_array( $decoded ) ) {
			return new WP_Error( 'wncpay_bad_response', __( 'Unexpected platform response.', 'wncpay' ) );
		}

		if ( empty( $decoded['ok'] ) ) {
			return new WP_Error( 'wncpay_api_error', (string) ( $decoded['error'] ?? __( 'Platform request failed.', 'wncpay' ) ) );
		}

		return $decoded;
	}
}
