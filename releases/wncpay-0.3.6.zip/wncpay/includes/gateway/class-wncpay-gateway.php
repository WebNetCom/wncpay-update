<?php
/**
 * WNC Pay WooCommerce payment gateway.
 *
 * Redirect flow: process_payment() creates a payment session on the platform
 * (signed server-to-server call) and sends the customer to the platform's
 * /pay/<reference> page. The order is flipped by the platform's signed webhook
 * (see WNCPAY_Gateway_Webhook), NOT by the customer's return navigation.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Gateway
 */
class WNCPAY_Gateway extends WC_Payment_Gateway {

	/**
	 * WNCPAY_Gateway constructor.
	 */
	public function __construct() {
		$this->id                 = 'wncpay';
		$this->icon               = (string) apply_filters( 'wncpay_gateway_icon', WNCPAY_URL . 'assets/images/wncpay-icon.png' );
		$this->method_title       = __( 'WNC Pay (platform checkout)', 'wncpay' );
		$this->method_description = __( 'Hands checkout to the connected platform: the customer pays on its secure page and is returned to the shop. Deals, documents and payment management stay on the platform.', 'wncpay' );
		$this->has_fields         = false;

		$this->init_form_fields();
		$this->init_settings();

		$this->title       = $this->get_option( 'title' );
		$this->description = $this->get_option( 'description' );

		add_action( "woocommerce_update_options_payment_gateways_{$this->id}", [ $this, 'process_admin_options' ] );
	}

	/**
	 * Gateway settings fields (connection lives in Settings → WNC Pay).
	 *
	 * @return void
	 */
	public function init_form_fields(): void {
		$this->form_fields = [
			'enabled'     => [
				'title'   => __( 'Enable/Disable', 'wncpay' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable WNC Pay', 'wncpay' ),
				'default' => 'no',
			],
			'title'       => [
				'title'       => __( 'Title', 'wncpay' ),
				'type'        => 'text',
				'description' => __( 'Shown to the customer at checkout.', 'wncpay' ),
				'default'     => __( 'Credit card (secure checkout)', 'wncpay' ),
				'desc_tip'    => true,
			],
			'description' => [
				'title'       => __( 'Description', 'wncpay' ),
				'type'        => 'textarea',
				'description' => __( 'Shown under the title at checkout.', 'wncpay' ),
				'default'     => __( 'You will be taken to our secure payment page and returned here after paying.', 'wncpay' ),
				'desc_tip'    => true,
			],
			'connection'  => [
				'title'       => __( 'Connection', 'wncpay' ),
				'type'        => 'title',
				/* translators: %s: settings page URL */
				'description' => sprintf( __( 'Platform URL and Site Key are configured under <a href="%s">Settings → WNC Pay</a>.', 'wncpay' ), esc_url( admin_url( 'options-general.php?page=wncpay' ) ) ),
			],
		];
	}

	/**
	 * The gateway needs the platform connection to work.
	 *
	 * @return bool
	 */
	public function needs_setup(): bool {
		return '' === WNCPAY_Embed::platform_url() || '' === WNCPAY_Embed::get_option( 'site_key' );
	}

	/**
	 * Only offer the gateway for ILS carts with a configured connection.
	 *
	 * @return bool
	 */
	public function is_available(): bool {
		return parent::is_available() && ! $this->needs_setup() && 'ILS' === get_woocommerce_currency();
	}

	/**
	 * Create the platform payment session and redirect the customer to it.
	 *
	 * @param int $order_id Order id.
	 *
	 * @return array
	 */
	public function process_payment( $order_id ): array {
		$order = wc_get_order( $order_id );

		if ( ! $order ) {
			return [ 'result' => 'failure' ];
		}

		$items  = [];
		$people = 0;
		foreach ( $order->get_items() as $item ) {
			$items[] = $item->get_name() . ( $item->get_quantity() > 1 ? ' ×' . $item->get_quantity() : '' );

			// Traveller count: WooCommerce Appointments/Bookings record persons on
			// the line item when the product uses them; fall back to the quantity.
			$persons = 0;
			foreach ( [ '_persons', 'persons', '_booking_persons', 'Persons' ] as $meta_key ) {
				$value = $item->get_meta( $meta_key );
				if ( is_numeric( $value ) && (int) $value > 0 ) {
					$persons = (int) $value;
					break;
				}
				if ( is_array( $value ) && ! empty( $value ) ) {
					$persons = (int) array_sum( array_map( 'intval', $value ) );
					break;
				}
			}
			$people += $persons > 0 ? $persons : (int) $item->get_quantity();
		}
		$product = implode( ', ', $items );
		if ( '' === $product ) {
			$product = sprintf( 'Order #%d', $order->get_id() );
		}

		$lang     = 'he' === substr( (string) apply_filters( 'wpml_current_language', null ) ?: substr( get_locale(), 0, 2 ), 0, 2 ) ? 'he' : 'en';
		$response = WNCPAY_Api::post(
			'/api/wncpay/session',
			[
				'orderId'      => $order->get_id(),
				'orderKey'     => $order->get_order_key(),
				'amountAgorot' => (int) round( (float) $order->get_total() * 100 ),
				'currency'     => 'ILS',
				// Multi-item carts use the platform's multiple-tours document variant.
				'docType'      => count( $order->get_items() ) > 1 ? 'cfc_multiple' : 'cfc_single',
				'people'       => max( 1, min( 500, $people ) ),
				'product'      => mb_substr( $product, 0, 290 ),
				'customer'     => [
					'name'  => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
					'email' => $order->get_billing_email(),
					'phone' => $order->get_billing_phone(),
				],
				'lang'         => $lang,
				'returnUrl'    => $order->get_checkout_order_received_url(),
				'cancelUrl'    => wc_get_checkout_url(),
				'callbackUrl'  => home_url( '/?wc-api=wncpay' ),
			]
		);

		if ( is_wp_error( $response ) ) {
			wc_add_notice( __( 'Payment could not be started. Please try again or contact us.', 'wncpay' ), 'error' );
			$order->add_order_note( sprintf( 'WNC Pay: session creation failed — %s', $response->get_error_message() ) );

			return [ 'result' => 'failure' ];
		}

		$order->update_meta_data( '_wncpay_reference', (string) $response['reference'] );
		$order->update_status( 'pending', __( 'Awaiting platform payment.', 'wncpay' ) );
		$order->add_order_note( sprintf( 'WNC Pay: payment session %s created.', $response['reference'] ) );
		$order->save();

		return [
			'result'   => 'success',
			'redirect' => (string) $response['payUrl'],
		];
	}
}
