<?php
/**
 * Server-rendered tour section (v0.10.0).
 *
 * Talie's "Elementor-hosted synced section": instead of an iframe, the page
 * prints REAL HTML fetched from the platform ("/api/wncpay/section") and
 * cached in a transient (~15 min, with a 24h stale backup for outages). The
 * content is authored once on the platform and stays in sync automatically;
 * context falls back page → product meta → website slug → category.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Section
 */
final class WNCPAY_Section {

	/**
	 * Fresh-cache lifetime (seconds). Filterable via wncpay_section_cache_ttl.
	 */
	private const TTL = 900;

	/**
	 * WNCPAY_Section constructor.
	 */
	public function __construct() {
		add_shortcode( 'wncpay_tour_section', [ $this, 'shortcode' ] );
	}

	/**
	 * [wncpay_tour_section product="" category="" cta="" gift=""]
	 *
	 * @param array|string $atts Shortcode attributes.
	 *
	 * @return string
	 */
	public function shortcode( $atts ): string {
		$args = shortcode_atts(
			[ 'product' => '', 'category' => '', 'cta' => '', 'gift' => '' ],
			is_array( $atts ) ? $atts : [],
			'wncpay_tour_section'
		);

		return self::render( $args );
	}

	/**
	 * Current request path.
	 *
	 * @return string
	 */
	private static function current_path(): string {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';

		return (string) wp_parse_url( $uri, PHP_URL_PATH );
	}

	/**
	 * Render the section (also used by the Elementor widget).
	 *
	 * @param array $args product / category / cta / gift overrides.
	 *
	 * @return string
	 */
	public static function render( array $args ): string {
		$path    = self::current_path();
		$product = trim( (string) ( $args['product'] ?? '' ) );

		// No explicit product → the page's linked product (Quick Edit dropdown).
		if ( '' === $product && is_singular() ) {
			$product = (string) get_post_meta( get_the_ID(), '_wncpay_product', true );
		}

		$body = array_filter(
			[
				'product'  => $product,
				'category' => trim( (string) ( $args['category'] ?? '' ) ),
				'ref'      => $path,
				'lang'     => WNCPAY_Embed::locale(),
			]
		);

		$key    = 'wncpay_sec_' . md5( wp_json_encode( $body ) . WNCPAY_Embed::platform_url() );
		$cached = get_transient( $key );

		if ( ! is_array( $cached ) ) {
			$response = WNCPAY_Api::post( '/api/wncpay/section', $body );

			if ( is_wp_error( $response ) ) {
				// Platform unreachable → serve the stale 24h backup if we have one.
				$backup = get_transient( $key . '_bk' );
				$cached = is_array( $backup ) ? $backup : [ 'kind' => 'none' ];
			} else {
				$cached = $response;
				$ttl    = (int) apply_filters( 'wncpay_section_cache_ttl', self::TTL );
				set_transient( $key, $cached, max( 60, $ttl ) );
				set_transient( $key . '_bk', $cached, DAY_IN_SECONDS );
			}
		}

		if ( empty( $cached['html'] ) || 'none' === ( $cached['kind'] ?? 'none' ) ) {
			if ( current_user_can( 'manage_options' ) ) {
				return '<div class="wncpay-notice" style="padding:12px;border:1px dashed #c90;color:#960;">'
					. esc_html__( 'WNC Pay tour section: no matching tour or category for this page. Link a product in Quick Edit, or pass product="…" / category="…". (Only administrators see this message.)', 'wncpay' )
					. '</div>';
			}

			return '';
		}

		return self::fill_links( (string) $cached['html'], $cached, $args, $path );
	}

	/**
	 * Swap the %%WNCPAY_CTA%% / %%WNCPAY_GIFT%% tokens for this site's pages
	 * (with the tour context attached), falling back to the platform's own
	 * pages when nothing is configured.
	 *
	 * @param array $payload Platform response (tourUrl / giftUrl fallbacks).
	 * @param array $args    Shortcode overrides (cta / gift).
	 * @param string $path   Current page path (context for ?fromtour=).
	 * @param string $html   Fragment HTML.
	 *
	 * @return string
	 */
	private static function fill_links( string $html, array $payload, array $args, string $path ): string {
		$product = (string) ( $payload['productId'] ?? '' );

		$cta = trim( (string) ( $args['cta'] ?? '' ) );
		if ( '' === $cta ) {
			$cta = trim( WNCPAY_Embed::get_option( 'section_cta_page' ) );
		}
		if ( '' !== $cta ) {
			$cta = add_query_arg( array_filter( [ 'fromtour' => rawurlencode( $path ) ] ), $cta );
		} else {
			$cta = (string) ( $payload['tourUrl'] ?? '#' );
		}

		$gift = trim( (string) ( $args['gift'] ?? '' ) );
		if ( '' === $gift ) {
			$gift = trim( WNCPAY_Embed::get_option( 'gift_button_page' ) );
		}
		if ( '' !== $gift ) {
			$gift = add_query_arg( array_filter( [ 'fromtour' => rawurlencode( $path ), 'product' => $product ] ), $gift );
		} else {
			$gift = (string) ( $payload['giftUrl'] ?? '#' );
		}

		return str_replace(
			[ '%%WNCPAY_CTA%%', '%%WNCPAY_GIFT%%' ],
			[ esc_url( $cta ), esc_url( $gift ) ],
			$html
		);
	}
}
