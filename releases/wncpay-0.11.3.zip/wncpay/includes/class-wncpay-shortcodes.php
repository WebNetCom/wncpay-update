<?php
/**
 * Shortcodes.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Shortcodes
 */
final class WNCPAY_Shortcodes {

	/**
	 * Display-only attributes that are never forwarded as query parameters.
	 *
	 * @var string[]
	 */
	private const DISPLAY_ATTS = [ 'path', 'min_height', 'title', 'mode', 'id', 'reference' ];

	/**
	 * WNCPAY_Shortcodes constructor.
	 */
	public function __construct() {
		add_shortcode( 'wncpay_embed', [ $this, 'render_embed' ] );
		add_shortcode( 'wncpay_gift_designer', [ $this, 'render_gift_designer' ] );
		add_shortcode( 'wncpay_trip_planner', [ $this, 'render_trip_planner' ] );
		add_shortcode( 'wncpay_tour_catalog', [ $this, 'render_tour_catalog' ] );
		// v0.8.0 -- more element types, so site pages can embed anything.
		add_shortcode( 'wncpay_tour', [ $this, 'render_tour' ] );
		add_shortcode( 'wncpay_how_it_works', [ $this, 'render_how_it_works' ] );
		add_shortcode( 'wncpay_pay', [ $this, 'render_pay' ] );
	}

	/**
	 * Generic embed shortcode: [wncpay_embed path="/gift" amount="750" min_height="900"].
	 *
	 * Every attribute except path/min_height/title is forwarded as a query parameter.
	 *
	 * @param array|string $atts Shortcode attributes.
	 *
	 * @return string
	 */
	public function render_embed( $atts ): string {
		$atts = is_array( $atts ) ? $atts : [];
		$path = ! empty( $atts['path'] ) ? (string) $atts['path'] : '/';

		return WNCPAY_Embed::render( $path, $this->extract_params( $atts ), $this->extract_args( $atts ) );
	}

	/**
	 * Trip-builder wizard: [wncpay_trip_planner]. The visitor builds an
	 * interactive itinerary without leaving the site (v0.6.0).
	 *
	 * @param array|string $atts Shortcode attributes.
	 *
	 * @return string
	 */
	public function render_trip_planner( $atts ): string {
		$atts = is_array( $atts ) ? $atts : [];
		$path = ! empty( $atts['path'] ) ? (string) $atts['path'] : (string) apply_filters( 'wncpay_trip_planner_path', '/plan' );

		return WNCPAY_Embed::render( $path, $this->extract_params( $atts ), $this->extract_args( $atts ) );
	}

	/**
	 * Interactive tour catalog: [wncpay_tour_catalog]. The visitor browses and
	 * picks multiple tours in one place instead of a contact form per tour (v0.6.0).
	 *
	 * @param array|string $atts Shortcode attributes.
	 *
	 * @return string
	 */
	public function render_tour_catalog( $atts ): string {
		$atts = is_array( $atts ) ? $atts : [];
		$path = ! empty( $atts['path'] ) ? (string) $atts['path'] : (string) apply_filters( 'wncpay_tour_catalog_path', '/tours' );

		// v0.7.2 -- the catalog uses window mode by default (frame sized to
		// the screen, content scrolls inside; sticky bar + cart popup behave
		// natively). [wncpay_tour_catalog mode="auto"] restores page mode.
		$args = $this->extract_args( $atts );
		if ( empty( $args['mode'] ) ) {
			$args['mode'] = 'window';
		}

		return WNCPAY_Embed::render( $path, $this->extract_params( $atts ), $args );
	}

	/**
	 * A single tour's full page: [wncpay_tour id="<product id>"] (v0.8.0).
	 * The id is the product id from the platform catalog (Dashboard -> Catalog).
	 *
	 * @param array|string $atts Shortcode attributes.
	 *
	 * @return string
	 */
	public function render_tour( $atts ): string {
		$atts = is_array( $atts ) ? $atts : [];
		$id   = ! empty( $atts['id'] ) ? sanitize_text_field( (string) $atts['id'] ) : '';

		if ( '' === $id ) {
			if ( current_user_can( 'manage_options' ) ) {
				return '<div class="wncpay-notice" style="padding:12px;border:1px dashed #c00;color:#c00;">'
					. esc_html__( 'WNC Pay: [wncpay_tour] needs an id attribute (the tour/product id from the platform catalog). Only administrators see this message.', 'wncpay' )
					. '</div>';
			}

			return '';
		}

		$args = $this->extract_args( $atts );
		if ( empty( $args['mode'] ) ) {
			$args['mode'] = 'window';
		}
		if ( empty( $args['title'] ) ) {
			$args['title'] = __( 'Tour details', 'wncpay' );
		}
		// A dedicated tour embed must NOT auto-expand to full screen on load
		// (that behavior is for in-catalog navigation only).
		$args['noexpand'] = true;

		return WNCPAY_Embed::render( '/tours/' . rawurlencode( $id ), $this->extract_params( $atts ), $args );
	}

	/**
	 * The planner's "How it works" explainer: [wncpay_how_it_works] (v0.8.0).
	 *
	 * @param array|string $atts Shortcode attributes.
	 *
	 * @return string
	 */
	public function render_how_it_works( $atts ): string {
		$atts = is_array( $atts ) ? $atts : [];
		$path = ! empty( $atts['path'] ) ? (string) $atts['path'] : '/plan/how-it-works';

		return WNCPAY_Embed::render( $path, $this->extract_params( $atts ), $this->extract_args( $atts ) );
	}

	/**
	 * A specific payment request's pay page: [wncpay_pay reference="<ref>"] (v0.8.0).
	 * Rarely needed on public pages; useful for one-off landing pages.
	 *
	 * @param array|string $atts Shortcode attributes.
	 *
	 * @return string
	 */
	public function render_pay( $atts ): string {
		$atts = is_array( $atts ) ? $atts : [];
		$ref  = ! empty( $atts['reference'] ) ? sanitize_text_field( (string) $atts['reference'] ) : '';

		if ( '' === $ref ) {
			if ( current_user_can( 'manage_options' ) ) {
				return '<div class="wncpay-notice" style="padding:12px;border:1px dashed #c00;color:#c00;">'
					. esc_html__( 'WNC Pay: [wncpay_pay] needs a reference attribute (the payment request reference from the platform). Only administrators see this message.', 'wncpay' )
					. '</div>';
			}

			return '';
		}

		$args = $this->extract_args( $atts );
		if ( empty( $args['title'] ) ) {
			$args['title'] = __( 'Payment', 'wncpay' );
		}

		return WNCPAY_Embed::render( '/pay/' . rawurlencode( $ref ), $this->extract_params( $atts ), $args );
	}

	/**
	 * Gift designer shortcode: [wncpay_gift_designer amount="750" matchkey="..."].
	 *
	 * @param array|string $atts Shortcode attributes.
	 *
	 * @return string
	 */
	public function render_gift_designer( $atts ): string {
		$atts = is_array( $atts ) ? $atts : [];

		/**
		 * Filter the platform path of the gift designer element.
		 *
		 * @param string $path Default path.
		 */
		$path = ! empty( $atts['path'] )
			? (string) $atts['path']
			: (string) apply_filters( 'wncpay_gift_designer_path', '/gift' );

		$args = $this->extract_args( $atts );

		if ( empty( $args['title'] ) ) {
			$args['title'] = __( 'Gift card designer', 'wncpay' );
		}

		return WNCPAY_Embed::render( $path, $this->extract_params( $atts ), $args );
	}

	/**
	 * Forwardable query parameters from shortcode attributes.
	 *
	 * @param array $atts Shortcode attributes.
	 *
	 * @return array
	 */
	private function extract_params( array $atts ): array {
		$params = [];

		foreach ( $atts as $key => $value ) {
			if ( is_int( $key ) || in_array( $key, self::DISPLAY_ATTS, true ) ) {
				continue;
			}

			$key = sanitize_key( $key );

			if ( '' !== $key ) {
				$params[ $key ] = sanitize_text_field( (string) $value );
			}
		}

		return $params;
	}

	/**
	 * Display arguments from shortcode attributes.
	 *
	 * @param array $atts Shortcode attributes.
	 *
	 * @return array
	 */
	private function extract_args( array $atts ): array {
		$args = [];

		if ( ! empty( $atts['min_height'] ) ) {
			$args['min_height'] = absint( $atts['min_height'] );
		}

		// v0.8.0 -- explicit embed mode: window (frame = screen, scrolls
		// inside) or auto (frame grows to content, page scrolls).
		if ( ! empty( $atts['mode'] ) && in_array( $atts['mode'], [ 'window', 'auto' ], true ) ) {
			$args['mode'] = $atts['mode'];
		}

		if ( ! empty( $atts['title'] ) ) {
			$args['title'] = sanitize_text_field( (string) $atts['title'] );
		}

		return $args;
	}
}
