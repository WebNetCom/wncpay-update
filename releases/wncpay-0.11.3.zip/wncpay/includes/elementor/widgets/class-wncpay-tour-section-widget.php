<?php
/**
 * Tour Section Elementor widget (v0.10.0) — the server-rendered synced section.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Tour_Section_Widget
 */
class WNCPAY_Tour_Section_Widget extends \Elementor\Widget_Base {

	public function get_name(): string {
		return 'wncpay-tour-section';
	}

	public function get_title(): string {
		return __( 'Tour Section (synced)', 'wncpay' );
	}

	public function get_icon(): string {
		return 'eicon-post-content';
	}

	public function get_categories(): array {
		return [ 'wncpay' ];
	}

	public function get_keywords(): array {
		return [ 'tour', 'section', 'synced', 'catalog', 'wnc', 'pay' ];
	}

	protected function register_controls(): void {
		$this->start_controls_section( 'wncpay_section_content', [ 'label' => __( 'Tour Section', 'wncpay' ) ] );
		$this->add_control( 'notice', [
			'type' => \Elementor\Controls_Manager::RAW_HTML,
			'raw'  => __( 'Real HTML synced from the platform (no iframe). Leave both fields empty to auto-detect from this page: its linked WNC Tour (Quick Edit), then its URL, then its category.', 'wncpay' ),
		] );
		$this->add_control( 'product', [
			'label'       => __( 'Product id (optional)', 'wncpay' ),
			'type'        => \Elementor\Controls_Manager::TEXT,
			'description' => __( 'Overrides auto-detection. Dashboard → Catalog → ✎ shows the id in the URL.', 'wncpay' ),
		] );
		$this->add_control( 'category', [
			'label'       => __( 'Category (optional)', 'wncpay' ),
			'type'        => \Elementor\Controls_Manager::TEXT,
			'description' => __( 'e.g. "Caving" — shows the category grid instead of one tour.', 'wncpay' ),
		] );
		$this->end_controls_section();
	}

	protected function render(): void {
		$s = $this->get_settings_for_display();
		echo WNCPAY_Section::render( [ // phpcs:ignore WordPress.Security.EscapeOutput
			'product'  => (string) ( $s['product'] ?? '' ),
			'category' => (string) ( $s['category'] ?? '' ),
		] );
	}
}
