<?php
/**
 * Gift Card Designer Elementor widget.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Gift_Designer_Widget
 */
class WNCPAY_Gift_Designer_Widget extends \Elementor\Widget_Base {

	/**
	 * Widget slug.
	 *
	 * @return string
	 */
	public function get_name(): string {
		return 'wncpay-gift-designer';
	}

	/**
	 * Widget title.
	 *
	 * @return string
	 */
	public function get_title(): string {
		return __( 'Gift Card Designer', 'wncpay' );
	}

	/**
	 * Widget icon.
	 *
	 * @return string
	 */
	public function get_icon(): string {
		return 'eicon-cart-medium';
	}

	/**
	 * Widget categories.
	 *
	 * @return array
	 */
	public function get_categories(): array {
		return [ 'wncpay' ];
	}

	/**
	 * Search keywords.
	 *
	 * @return array
	 */
	public function get_keywords(): array {
		return [ 'gift', 'card', 'voucher', 'wnc', 'pay', 'embed' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @return void
	 */
	protected function register_controls(): void {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Gift Card Designer', 'wncpay' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'amount',
			[
				'label'       => __( 'Preset amount', 'wncpay' ),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'description' => __( 'Optional. Pre-select a gift card amount.', 'wncpay' ),
				'min'         => 0,
			]
		);

		$this->add_control(
			'matchkey',
			[
				'label'       => __( 'Match key', 'wncpay' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'description' => __( 'Optional. Platform match key for attribution.', 'wncpay' ),
			]
		);

		$this->add_control(
			'extra_params',
			[
				'label'       => __( 'Extra parameters', 'wncpay' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'description' => __( 'Optional. Query-string format, e.g. dealId=123&theme=dark', 'wncpay' ),
			]
		);

		$this->add_control(
			'min_height',
			[
				'label'       => __( 'Minimum height (px)', 'wncpay' ),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'default'     => 900,
				'min'         => 200,
				'max'         => 20000,
				'description' => __( 'Shown until the embed reports its real height.', 'wncpay' ),
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget.
	 *
	 * @return void
	 */
	protected function render(): void {
		$settings = $this->get_settings_for_display();
		$params   = [];

		if ( ! empty( $settings['amount'] ) ) {
			$params['amount'] = sanitize_text_field( (string) $settings['amount'] );
		}

		if ( ! empty( $settings['matchkey'] ) ) {
			$params['matchkey'] = sanitize_text_field( (string) $settings['matchkey'] );
		}

		if ( ! empty( $settings['extra_params'] ) ) {
			wp_parse_str( (string) $settings['extra_params'], $extra );

			foreach ( $extra as $key => $value ) {
				$key = sanitize_key( $key );

				if ( '' !== $key && ! isset( $params[ $key ] ) && is_scalar( $value ) ) {
					$params[ $key ] = sanitize_text_field( (string) $value );
				}
			}
		}

		$path = (string) apply_filters( 'wncpay_gift_designer_path', '/gift' );

		// WNCPAY_Embed::render() escapes all output.
		echo WNCPAY_Embed::render( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$path,
			$params,
			[
				'min_height' => absint( $settings['min_height'] ?? 900 ),
				'title'      => __( 'Gift card designer', 'wncpay' ),
			]
		);
	}
}
