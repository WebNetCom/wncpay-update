<?php
/**
 * Page ↔ platform-product link (v0.10.0).
 *
 * A "WNC Tour" dropdown in the page editor sidebar AND in Quick Edit, fed by
 * the platform's product list (cached ~15 min). The chosen product id is saved
 * as _wncpay_product post meta and becomes the explicit link every feature
 * uses — the server-rendered tour section, the floating gift button, and any
 * future match — instead of guessing from URL slugs.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Product_Meta
 */
final class WNCPAY_Product_Meta {

	private const META  = '_wncpay_product';
	private const NONCE = 'wncpay_product_meta';

	/**
	 * WNCPAY_Product_Meta constructor.
	 */
	public function __construct() {
		add_action( 'add_meta_boxes', [ $this, 'add_meta_box' ] );
		add_action( 'save_post', [ $this, 'save' ] );

		foreach ( [ 'page', 'post' ] as $type ) {
			add_filter( "manage_{$type}_posts_columns", [ $this, 'add_column' ] );
			add_action( "manage_{$type}_posts_custom_column", [ $this, 'render_column' ], 10, 2 );
		}
		add_action( 'quick_edit_custom_box', [ $this, 'quick_edit_field' ], 10, 2 );
		add_action( 'admin_footer-edit.php', [ $this, 'quick_edit_js' ] );
	}

	/**
	 * The product linked to a post (empty string when none).
	 *
	 * @param int $post_id Post id.
	 *
	 * @return string
	 */
	public static function product_for( int $post_id ): string {
		return (string) get_post_meta( $post_id, self::META, true );
	}

	/**
	 * Product list from the platform, cached ~15 min (+ a 24h stale backup).
	 *
	 * @return array[] Each: [ id, nameEn, nameHe, matchKey, category ].
	 */
	public static function products(): array {
		$key    = 'wncpay_products_' . md5( WNCPAY_Embed::platform_url() );
		$cached = get_transient( $key );

		if ( is_array( $cached ) ) {
			return $cached;
		}

		$response = WNCPAY_Api::post( '/api/wncpay/products', [] );

		if ( is_wp_error( $response ) || empty( $response['products'] ) || ! is_array( $response['products'] ) ) {
			$backup = get_transient( $key . '_bk' );

			return is_array( $backup ) ? $backup : [];
		}

		$list = array_values( $response['products'] );
		set_transient( $key, $list, 15 * MINUTE_IN_SECONDS );
		set_transient( $key . '_bk', $list, DAY_IN_SECONDS );

		return $list;
	}

	/**
	 * The <select> shared by the meta box and Quick Edit.
	 *
	 * @param string $selected Selected product id.
	 *
	 * @return string
	 */
	private static function dropdown( string $selected ): string {
		$out = '<select name="wncpay_product" class="wncpay-product-select" style="max-width:100%">'
			. '<option value="">' . esc_html__( '— No linked tour —', 'wncpay' ) . '</option>';

		foreach ( self::products() as $p ) {
			$id    = (string) ( $p['id'] ?? '' );
			$label = trim( (string) ( $p['nameEn'] ?? '' ) );
			$he    = trim( (string) ( $p['nameHe'] ?? '' ) );
			$mk    = trim( (string) ( $p['matchKey'] ?? '' ) );
			if ( '' === $label ) {
				$label = $he;
			}
			if ( '' !== $mk && strcasecmp( $mk, $label ) !== 0 ) {
				$label .= ' · ' . $mk;
			}
			$out .= sprintf( '<option value="%s"%s>%s</option>', esc_attr( $id ), selected( $selected, $id, false ), esc_html( $label ) );
		}

		return $out . '</select>';
	}

	/**
	 * Editor sidebar meta box.
	 *
	 * @return void
	 */
	public function add_meta_box(): void {
		foreach ( [ 'page', 'post' ] as $type ) {
			add_meta_box( 'wncpay_product', __( 'WNC Tour', 'wncpay' ), [ $this, 'render_meta_box' ], $type, 'side' );
		}
	}

	/**
	 * Meta box body.
	 *
	 * @param \WP_Post $post Current post.
	 *
	 * @return void
	 */
	public function render_meta_box( $post ): void {
		wp_nonce_field( self::NONCE, self::NONCE );
		echo self::dropdown( self::product_for( (int) $post->ID ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<p class="description">' . esc_html__( 'Links this page to a platform catalog item — used by the tour section, the gift button, and cross-system matching.', 'wncpay' ) . '</p>';
	}

	/**
	 * Save from the editor OR Quick Edit.
	 *
	 * @param int $post_id Post id.
	 *
	 * @return void
	 */
	public function save( $post_id ): void {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		// Full editor sends our nonce; Quick Edit sends the inline-edit nonce.
		$via_box   = isset( $_POST[ self::NONCE ] ) && wp_verify_nonce( sanitize_key( $_POST[ self::NONCE ] ), self::NONCE );
		$via_quick = isset( $_POST['_inline_edit'] ) && wp_verify_nonce( sanitize_key( $_POST['_inline_edit'] ), 'inlineeditnonce' );
		if ( ( ! $via_box && ! $via_quick ) || ! isset( $_POST['wncpay_product'] ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$value = sanitize_text_field( wp_unslash( $_POST['wncpay_product'] ) );
		if ( '' === $value ) {
			delete_post_meta( $post_id, self::META );
		} else {
			update_post_meta( $post_id, self::META, $value );
		}
	}

	/**
	 * "WNC Tour" list-table column.
	 *
	 * @param array $columns Existing columns.
	 *
	 * @return array
	 */
	public function add_column( array $columns ): array {
		$columns['wncpay_product'] = __( 'WNC Tour', 'wncpay' );

		return $columns;
	}

	/**
	 * Column cell: linked product name + a hidden value for the Quick Edit JS.
	 *
	 * @param string $column  Column key.
	 * @param int    $post_id Post id.
	 *
	 * @return void
	 */
	public function render_column( string $column, int $post_id ): void {
		if ( 'wncpay_product' !== $column ) {
			return;
		}
		$id   = self::product_for( $post_id );
		$name = '—';
		if ( '' !== $id ) {
			foreach ( self::products() as $p ) {
				if ( (string) ( $p['id'] ?? '' ) === $id ) {
					$name = (string) ( $p['nameEn'] ?: ( $p['nameHe'] ?? $id ) );
					break;
				}
			}
			if ( '—' === $name ) {
				$name = $id; // product list unavailable — show the raw id
			}
		}
		printf( '<span class="wncpay-product-cell" data-product="%s">%s</span>', esc_attr( $id ), esc_html( $name ) );
	}

	/**
	 * Quick Edit field.
	 *
	 * @param string $column    Column key.
	 * @param string $post_type Post type.
	 *
	 * @return void
	 */
	public function quick_edit_field( string $column, string $post_type ): void {
		if ( 'wncpay_product' !== $column || ! in_array( $post_type, [ 'page', 'post' ], true ) ) {
			return;
		}
		echo '<fieldset class="inline-edit-col-right"><div class="inline-edit-col"><label>'
			. '<span class="title">' . esc_html__( 'WNC Tour', 'wncpay' ) . '</span>'
			. self::dropdown( '' ) // phpcs:ignore WordPress.Security.EscapeOutput
			. '</label></div></fieldset>';
	}

	/**
	 * Quick Edit: preselect the row's current product when the editor opens.
	 *
	 * @return void
	 */
	public function quick_edit_js(): void {
		?>
		<script>
		jQuery( function ( $ ) {
			var wpInlineEdit = window.inlineEditPost && window.inlineEditPost.edit;
			if ( ! wpInlineEdit ) { return; }
			window.inlineEditPost.edit = function ( id ) {
				wpInlineEdit.apply( this, arguments );
				var postId = 0;
				if ( typeof id === 'object' ) { postId = parseInt( this.getId( id ), 10 ); }
				if ( ! postId ) { return; }
				var current = $( '#post-' + postId + ' .wncpay-product-cell' ).data( 'product' ) || '';
				$( '#edit-' + postId + ' select.wncpay-product-select' ).val( current );
			};
		} );
		</script>
		<?php
	}
}
