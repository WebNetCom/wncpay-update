<?php
/**
 * Gutenberg blocks.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Blocks
 */
final class WNCPAY_Blocks {

	/**
	 * WNCPAY_Blocks constructor.
	 */
	public function __construct() {
		add_action( 'init', [ $this, 'register' ] );
	}

	/**
	 * Register editor assets and the gift designer block.
	 *
	 * @return void
	 */
	public function register(): void {
		wp_register_script(
			'wncpay-blocks',
			WNCPAY_URL . 'assets/js/blocks.js',
			[ 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n' ],
			WNCPAY_VERSION,
			true
		);

		register_block_type(
			'wncpay/gift-designer',
			[
				'api_version'     => 2,
				'editor_script'   => 'wncpay-blocks',
				'render_callback' => [ $this, 'render_gift_designer' ],
				'attributes'      => [
					'amount'      => [
						'type'    => 'string',
						'default' => '',
					],
					'matchkey'    => [
						'type'    => 'string',
						'default' => '',
					],
					'extraParams' => [
						'type'    => 'string',
						'default' => '',
					],
					'minHeight'   => [
						'type'    => 'number',
						'default' => 900,
					],
				],
			]
		);
	}

	/**
	 * Server-render the gift designer block.
	 *
	 * @param array $attributes Block attributes.
	 *
	 * @return string
	 */
	public function render_gift_designer( array $attributes ): string {
		$params = [];

		if ( ! empty( $attributes['amount'] ) ) {
			$params['amount'] = sanitize_text_field( (string) $attributes['amount'] );
		}

		if ( ! empty( $attributes['matchkey'] ) ) {
			$params['matchkey'] = sanitize_text_field( (string) $attributes['matchkey'] );
		}

		if ( ! empty( $attributes['extraParams'] ) ) {
			wp_parse_str( (string) $attributes['extraParams'], $extra );

			foreach ( $extra as $key => $value ) {
				$key = sanitize_key( $key );

				if ( '' !== $key && ! isset( $params[ $key ] ) && is_scalar( $value ) ) {
					$params[ $key ] = sanitize_text_field( (string) $value );
				}
			}
		}

		$path = (string) apply_filters( 'wncpay_gift_designer_path', '/gift' );

		return WNCPAY_Embed::render(
			$path,
			$params,
			[
				'min_height' => absint( $attributes['minHeight'] ?? 900 ),
				'title'      => __( 'Gift card designer', 'wncpay' ),
			]
		);
	}
}
