<?php
/**
 * Product-level options + checkout fields for the WNC Pay gateway.
 *
 * - Product editor checkbox "Full payment (no office confirmation)": flagged
 *   products charge 100% immediately and get no preferred-date field. Unflagged
 *   products are treated as tours: the order charges the configured deposit and
 *   the office confirms availability.
 * - Checkout: every unflagged cart item gets a required "Preferred date" field
 *   (WooCommerce Appointments is not licensed on the site, so plain products
 *   carry no date). Saved as visible line-item meta → appears on the order,
 *   the emails, and rides into the platform product summary + CRM deal.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Product_Options
 */
final class WNCPAY_Product_Options {

	/**
	 * Product meta key for the full-payment flag.
	 *
	 * @var string
	 */
	public const META_FULL_PAYMENT = '_wncpay_full_payment';

	/**
	 * Line-item meta label for the preferred date (visible meta).
	 *
	 * @var string
	 */
	public const ITEM_DATE_LABEL = 'Preferred date';

	/**
	 * WNCPAY_Product_Options constructor.
	 */
	public function __construct() {
		// Product editor checkbox.
		add_action( 'woocommerce_product_options_general_product_data', [ $this, 'render_product_checkbox' ] );
		add_action( 'woocommerce_process_product_meta', [ $this, 'save_product_checkbox' ] );

		// Checkout preferred-date fields.
		add_action( 'woocommerce_before_order_notes', [ $this, 'render_date_fields' ] );
		add_action( 'woocommerce_checkout_process', [ $this, 'validate_date_fields' ] );
		add_action( 'woocommerce_checkout_create_order_line_item', [ $this, 'save_date_to_item' ], 10, 3 );
	}

	/**
	 * Whether a product requires office confirmation (i.e. is NOT flagged full-payment).
	 *
	 * @param int $product_id Product id.
	 *
	 * @return bool
	 */
	public static function requires_confirmation( int $product_id ): bool {
		return 'yes' !== get_post_meta( $product_id, self::META_FULL_PAYMENT, true );
	}

	/**
	 * Product editor: the full-payment checkbox.
	 *
	 * @return void
	 */
	public function render_product_checkbox(): void {
		woocommerce_wp_checkbox(
			[
				'id'          => self::META_FULL_PAYMENT,
				'label'       => __( 'WNC Pay: full payment', 'wncpay' ),
				'description' => __( 'No office confirmation needed — charge 100% immediately and skip the preferred-date question. Leave unchecked for tours that must be confirmed for availability (deposit flow).', 'wncpay' ),
			]
		);
	}

	/**
	 * Save the checkbox.
	 *
	 * @param int $post_id Product id.
	 *
	 * @return void
	 */
	public function save_product_checkbox( $post_id ): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Woo verifies its own nonce for this screen.
		update_post_meta( $post_id, self::META_FULL_PAYMENT, isset( $_POST[ self::META_FULL_PAYMENT ] ) ? 'yes' : 'no' );
	}

	/**
	 * Cart items that need a preferred date (unflagged products).
	 *
	 * @return array<string, array> cart_item_key => cart item.
	 */
	private function date_items(): array {
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return [];
		}

		$needing = [];
		foreach ( WC()->cart->get_cart() as $key => $item ) {
			$product_id = (int) ( $item['product_id'] ?? 0 );
			if ( $product_id && self::requires_confirmation( $product_id ) ) {
				$needing[ $key ] = $item;
			}
		}

		return $needing;
	}

	/**
	 * Checkout: render one date input per tour item.
	 *
	 * @return void
	 */
	public function render_date_fields(): void {
		$items = $this->date_items();

		if ( empty( $items ) ) {
			return;
		}

		$he = 'he' === WNCPAY_Embed::locale();

		echo '<div class="wncpay-preferred-dates" style="margin:1em 0;">';
		echo '<h3>' . esc_html( $he ? 'תאריך מועדף לטיול' : 'Preferred tour date' ) . '</h3>';
		echo '<p style="font-size:0.9em;">' . esc_html( $he ? 'בחרו את התאריך המבוקש לכל טיול — המשרד יאשר זמינות לפני החיוב הסופי.' : 'Pick your intended date for each tour — the office confirms availability before the final charge.' ) . '</p>';

		foreach ( $items as $key => $item ) {
			$product = $item['data'] ?? null;
			$name    = $product instanceof WC_Product ? $product->get_name() : __( 'Tour', 'wncpay' );
			$field   = 'wncpay_date_' . md5( $key );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- re-render after validation error only.
			$value = isset( $_POST[ $field ] ) ? sanitize_text_field( wp_unslash( $_POST[ $field ] ) ) : '';
			printf(
				'<p class="form-row form-row-wide"><label for="%1$s">%2$s&nbsp;<abbr class="required" title="required">*</abbr></label><input type="date" id="%1$s" name="%1$s" value="%3$s" min="%4$s" required /></p>',
				esc_attr( $field ),
				esc_html( $name ),
				esc_attr( $value ),
				esc_attr( gmdate( 'Y-m-d' ) )
			);
		}
		echo '</div>';
	}

	/**
	 * Checkout validation: every tour item needs a valid future-or-today date.
	 *
	 * @return void
	 */
	public function validate_date_fields(): void {
		$he = 'he' === WNCPAY_Embed::locale();

		foreach ( $this->date_items() as $key => $item ) {
			$field = 'wncpay_date_' . md5( $key );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Woo checkout handles the nonce.
			$value   = isset( $_POST[ $field ] ) ? sanitize_text_field( wp_unslash( $_POST[ $field ] ) ) : '';
			$product = $item['data'] ?? null;
			$name    = $product instanceof WC_Product ? $product->get_name() : __( 'Tour', 'wncpay' );

			if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) || $value < gmdate( 'Y-m-d' ) ) {
				wc_add_notice(
					sprintf(
						/* translators: %s: product name */
						$he ? 'נא לבחור תאריך מועדף עבור "%s".' : 'Please pick a preferred date for "%s".',
						esc_html( $name )
					),
					'error'
				);
			}
		}
	}

	/**
	 * Persist the chosen date as VISIBLE line-item meta (shows on order + emails).
	 *
	 * @param WC_Order_Item_Product $item          Line item.
	 * @param string                $cart_item_key Cart key.
	 * @param array                 $values        Cart item values.
	 *
	 * @return void
	 */
	public function save_date_to_item( $item, $cart_item_key, $values ): void {
		$product_id = (int) ( $values['product_id'] ?? 0 );

		if ( ! $product_id || ! self::requires_confirmation( $product_id ) ) {
			return;
		}

		$field = 'wncpay_date_' . md5( $cart_item_key );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Woo checkout handles the nonce.
		$value = isset( $_POST[ $field ] ) ? sanitize_text_field( wp_unslash( $_POST[ $field ] ) ) : '';

		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ) {
			$item->add_meta_data( self::ITEM_DATE_LABEL, $value, true );
		}
	}
}
