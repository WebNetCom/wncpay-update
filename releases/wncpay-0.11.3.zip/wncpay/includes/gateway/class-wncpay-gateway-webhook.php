<?php
/**
 * Signed webhook receiver: the platform flips Woo orders here.
 *
 * Endpoint: https://<site>/?wc-api=wncpay  (woocommerce_api_wncpay).
 * Payload + signature scheme: platform docs/wncpay-gateway-api.md.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Gateway_Webhook
 */
final class WNCPAY_Gateway_Webhook {

	/**
	 * WNCPAY_Gateway_Webhook constructor.
	 */
	public function __construct() {
		add_action( 'woocommerce_api_wncpay', [ $this, 'handle' ] );
	}

	/**
	 * Handle a platform webhook.
	 *
	 * @return void
	 */
	public function handle(): void {
		$body = (string) file_get_contents( 'php://input' );

		$timestamp = isset( $_SERVER['HTTP_X_WNCPAY_TIMESTAMP'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_WNCPAY_TIMESTAMP'] ) ) : null;
		$signature = isset( $_SERVER['HTTP_X_WNCPAY_SIGNATURE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_WNCPAY_SIGNATURE'] ) ) : null;

		if ( ! WNCPAY_Api::verify( $timestamp, $signature, $body ) ) {
			wp_send_json( [ 'ok' => false, 'error' => 'bad_signature' ], 401 );
		}

		$data = json_decode( $body, true );

		if ( ! is_array( $data ) || empty( $data['orderId'] ) || empty( $data['orderKey'] ) || empty( $data['event'] ) ) {
			wp_send_json( [ 'ok' => false, 'error' => 'bad_payload' ], 400 );
		}

		$order = wc_get_order( absint( $data['orderId'] ) );

		if ( ! $order || ! hash_equals( $order->get_order_key(), (string) $data['orderKey'] ) ) {
			wp_send_json( [ 'ok' => false, 'error' => 'order_not_found' ], 404 );
		}

		$reference = (string) ( $data['reference'] ?? '' );
		$paid_ag   = (int) ( $data['paidAgorot'] ?? $data['amountAgorot'] ?? 0 );
		$remaining = isset( $data['remainingAgorot'] ) ? (int) $data['remainingAgorot'] : 0;
		$total_ag  = (int) ( $data['totalAgorot'] ?? $paid_ag );
		$amount    = number_format( $paid_ag / 100, 2 );

		// TEST transaction (0.7.0): the platform marks payments that ran against
		// the PayMe sandbox — via the gateway's Test-mode setting OR the magic
		// test ID typed at checkout. Stamp the order loudly so a test order can
		// never be mistaken for real revenue.
		$is_test = ! empty( $data['test'] );

		if ( 'paid' === $data['event'] ) {
			if ( $order->is_paid() ) {
				// IPNs multi-fire — already handled.
				wp_send_json( [ 'ok' => true, 'note' => 'already_paid' ] );
			}

			if ( $is_test && 'yes' !== $order->get_meta( '_wncpay_test' ) ) {
				$order->update_meta_data( '_wncpay_test', 'yes' );
				$order->add_order_note( '🧪 WNC Pay: TEST transaction — processed via the PayMe sandbox; NO real money moved. Exclude from revenue.' );
			}

			if ( $remaining > 0 ) {
				// Deposit received — the office confirms availability and charges the
				// balance on the platform; a later webhook (remaining 0) completes it.
				$order->update_status(
					'on-hold',
					sprintf(
						'WNC Pay: deposit received — ₪%s of ₪%s (platform reference %s). Awaiting office availability confirmation; balance ₪%s is charged on the platform after confirmation.',
						$amount,
						number_format( $total_ag / 100, 2 ),
						$reference,
						number_format( $remaining / 100, 2 )
					)
				);
				$order->save();

				wp_send_json( [ 'ok' => true, 'note' => 'deposit' ] );
			}

			$order->payment_complete( (string) ( $data['transactionId'] ?? $reference ) );
			$order->add_order_note( sprintf( 'WNC Pay: payment received in full — ₪%s (platform reference %s).', $amount, $reference ) );
			$order->save();

			wp_send_json( [ 'ok' => true ] );
		}

		if ( 'failed' === $data['event'] ) {
			// A late failure must NEVER flip an already-paid order (races with the
			// paid webhook / IPN multi-fire).
			if ( $order->is_paid() ) {
				wp_send_json( [ 'ok' => true, 'note' => 'paid_wins' ] );
			}

			$detail = (string) ( $data['detail'] ?? '' );
			$order->update_status( 'failed', sprintf( 'WNC Pay: payment failed%s (platform reference %s). The customer can retry from the same platform link.', '' !== $detail ? ' — ' . $detail : '', $reference ) );

			wp_send_json( [ 'ok' => true ] );
		}

		wp_send_json( [ 'ok' => false, 'error' => 'unknown_event' ], 400 );
	}
}
