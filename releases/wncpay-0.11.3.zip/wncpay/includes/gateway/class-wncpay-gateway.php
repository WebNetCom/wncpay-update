<?php
/**
 * WNC Pay WooCommerce payment gateway.
 *
 * Redirect flow: process_payment() creates a payment session on the platform
 * (signed server-to-server call) and sends the customer to the platform's
 * /pay/<reference> page. The order is flipped by the platform's signed webhook
 * (see WNCPAY_Gateway_Webhook), NOT by the customer's return navigation.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Gateway
 */
class WNCPAY_Gateway extends WC_Payment_Gateway {

	/**
	 * WNCPAY_Gateway constructor.
	 */
	public function __construct() {
		$this->id                 = 'wncpay';
		$this->icon               = (string) apply_filters( 'wncpay_gateway_icon', WNCPAY_URL . 'assets/images/wncpay-icon.png' );
		$this->method_title       = __( 'WNC Pay (platform checkout)', 'wncpay' );
		$this->method_description = __( 'Hands checkout to the connected platform: the customer pays on its secure page and is returned to the shop. Deals, documents and payment management stay on the platform.', 'wncpay' );
		$this->has_fields         = false;

		$this->init_form_fields();
		$this->init_settings();

		$this->title       = $this->get_option( 'title' );
		$this->description = $this->get_option( 'description' );

		add_action( "woocommerce_update_options_payment_gateways_{$this->id}", [ $this, 'process_admin_options' ] );
	}

	/**
	 * Gateway settings fields (connection lives in Settings → WNC Pay).
	 *
	 * @return void
	 */
	public function init_form_fields(): void {
		$this->form_fields = [
			'enabled'     => [
				'title'   => __( 'Enable/Disable', 'wncpay' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable WNC Pay', 'wncpay' ),
				'default' => 'no',
			],
			'title'       => [
				'title'       => __( 'Title', 'wncpay' ),
				'type'        => 'text',
				'description' => __( 'Shown to the customer at checkout.', 'wncpay' ),
				'default'     => __( 'Credit card (secure checkout)', 'wncpay' ),
				'desc_tip'    => true,
			],
			'description' => [
				'title'       => __( 'Description', 'wncpay' ),
				'type'        => 'textarea',
				'description' => __( 'Shown under the title at checkout.', 'wncpay' ),
				'default'     => __( 'You will be taken to our secure payment page and returned here after paying.', 'wncpay' ),
				'desc_tip'    => true,
			],
			'deposit_percent' => [
				'title'             => __( 'Deposit %', 'wncpay' ),
				'type'              => 'number',
				'description'       => __( 'Orders that need office availability confirmation charge this deposit now; the office charges the balance after confirming. Products marked "full payment" in the product editor always charge 100% immediately. Set 100 to disable deposits entirely.', 'wncpay' ),
				'default'           => '30',
				'custom_attributes' => [ 'min' => '5', 'max' => '100', 'step' => '1' ],
			],
			'test_mode'   => [
				'title'       => __( 'Test mode', 'wncpay' ),
				'type'        => 'checkbox',
				'label'       => __( 'Send orders as TEST transactions (PayMe sandbox)', 'wncpay' ),
				'description' => __( 'For integration testing only. Checkouts are processed against the PayMe sandbox: the PayMe test card is approved for real, no actual money moves, and the platform stamps everything [TEST] and excludes it from revenue and the CRM. Turn OFF before going live.', 'wncpay' ),
				'default'     => 'no',
			],
			'connection'  => [
				'title'       => __( 'Connection', 'wncpay' ),
				'type'        => 'title',
				/* translators: %s: settings page URL */
				'description' => sprintf( __( 'Platform URL and Site Key are configured under <a href="%s">Settings → WNC Pay</a>.', 'wncpay' ), esc_url( admin_url( 'options-general.php?page=wncpay' ) ) ),
			],
		];
	}

	/**
	 * The gateway needs the platform connection to work.
	 *
	 * @return bool
	 */
	public function needs_setup(): bool {
		return '' === WNCPAY_Embed::platform_url() || '' === WNCPAY_Embed::get_option( 'site_key' );
	}

	/**
	 * Only offer the gateway for ILS carts with a configured connection.
	 *
	 * @return bool
	 */
	public function is_available(): bool {
		return parent::is_available() && ! $this->needs_setup() && 'ILS' === get_woocommerce_currency();
	}

	/**
	 * Checkout description: append the deposit/confirmation stipulation when the
	 * cart contains tours that need office confirmation.
	 *
	 * @return void
	 */
	public function payment_fields(): void {
		parent::payment_fields();

		// Loud yellow banner while test mode is on, so a real customer is never
		// charged into the sandbox unknowingly.
		if ( 'yes' === $this->get_option( 'test_mode', 'no' ) ) {
			echo '<div style="margin:8px 0;padding:8px 12px;border:1px solid #f0b429;background:#fffbea;border-radius:8px;font-weight:600">🧪 ' . esc_html__( 'TEST MODE — payments run against the PayMe sandbox. Use the PayMe test card; no real charge will occur.', 'wncpay' ) . '</div>';
		}

		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return;
		}

		$needs_confirm = false;
		foreach ( WC()->cart->get_cart() as $item ) {
			if ( ! empty( $item['product_id'] ) && WNCPAY_Product_Options::requires_confirmation( (int) $item['product_id'] ) ) {
				$needs_confirm = true;
				break;
			}
		}

		$percent = max( 5, min( 100, (int) $this->get_option( 'deposit_percent', '30' ) ) );

		if ( ! $needs_confirm || $percent >= 100 ) {
			return;
		}

		$he = 'he' === WNCPAY_Embed::locale();
		printf(
			'<p class="wncpay-stipulation" style="font-size:0.9em;margin-top:6px;">%s</p>',
			esc_html(
				$he
					? sprintf( 'טיולים כפופים לאישור זמינות של המשרד: כעת נגבה מקדמה של %d%% בלבד (או תשלום מלא, לבחירתכם), והיתרה תיגבה לאחר האישור. אם טיול לא יאושר — נציע חלופה או נחזיר את המקדמה.', $percent )
					: sprintf( 'Tours are subject to office availability confirmation: only a %d%% deposit is charged now (or pay in full — your choice), and the balance is charged after confirmation. If a tour cannot be confirmed we will offer an alternative or refund your deposit.', $percent )
			)
		);
	}

	/**
	 * Create the platform payment session and redirect the customer to it.
	 *
	 * @param int $order_id Order id.
	 *
	 * @return array
	 */
	public function process_payment( $order_id ): array {
		$order = wc_get_order( $order_id );

		if ( ! $order ) {
			return [ 'result' => 'failure' ];
		}

		$items         = [];
		$people        = 0;
		$needs_confirm = false;
		foreach ( $order->get_items() as $item ) {
			$label = $item->get_name() . ( $item->get_quantity() > 1 ? ' ×' . $item->get_quantity() : '' );

			// Tour items (not flagged full-payment): deposit flow + preferred date.
			if ( $item instanceof WC_Order_Item_Product && WNCPAY_Product_Options::requires_confirmation( (int) $item->get_product_id() ) ) {
				$needs_confirm = true;
				$date          = (string) $item->get_meta( WNCPAY_Product_Options::ITEM_DATE_LABEL );
				if ( '' !== $date ) {
					$label .= ' (' . $date . ')';
				}
			}

			$items[] = $label;

			// Traveller count: WooCommerce Appointments/Bookings record persons on
			// the line item when the product uses them; fall back to the quantity.
			$persons = 0;
			foreach ( [ '_persons', 'persons', '_booking_persons', 'Persons' ] as $meta_key ) {
				$value = $item->get_meta( $meta_key );
				if ( is_numeric( $value ) && (int) $value > 0 ) {
					$persons = (int) $value;
					break;
				}
				if ( is_array( $value ) && ! empty( $value ) ) {
					$persons = (int) array_sum( array_map( 'intval', $value ) );
					break;
				}
			}
			$people += $persons > 0 ? $persons : (int) $item->get_quantity();
		}
		$product = implode( ', ', $items );
		if ( '' === $product ) {
			$product = sprintf( 'Order #%d', $order->get_id() );
		}

		$lang = 'he' === substr( (string) apply_filters( 'wpml_current_language', null ) ?: substr( get_locale(), 0, 2 ), 0, 2 ) ? 'he' : 'en';

		// Deposit flow: orders with tours that need office confirmation charge the
		// configured deposit now (the platform pay page also offers "pay in full");
		// the office charges the balance after confirming availability. Deposits
		// below PayMe's ₪5 minimum, or a 100% setting, mean full payment.
		$total_agorot   = (int) round( (float) $order->get_total() * 100 );
		$percent        = max( 5, min( 100, (int) $this->get_option( 'deposit_percent', '30' ) ) );
		$deposit_agorot = 0;
		if ( $needs_confirm && $percent < 100 ) {
			$candidate = (int) round( $total_agorot * $percent / 100 );
			if ( $candidate >= 500 && $candidate < $total_agorot ) {
				$deposit_agorot = $candidate;
			}
		}

		$payload = [
				'orderId'      => $order->get_id(),
				'orderKey'     => $order->get_order_key(),
				'amountAgorot' => $total_agorot,
				'currency'     => 'ILS',
				// Multi-item carts use the platform's multiple-tours document variant.
				'docType'      => count( $order->get_items() ) > 1 ? 'cfc_multiple' : 'cfc_single',
				'people'       => max( 1, min( 500, $people ) ),
				'product'      => mb_substr( $product, 0, 290 ),
				'customer'     => [
					'name'  => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
					'email' => $order->get_billing_email(),
					'phone' => $order->get_billing_phone(),
				],
				'lang'         => $lang,
				'returnUrl'    => $order->get_checkout_order_received_url(),
				'cancelUrl'    => wc_get_checkout_url(),
				'callbackUrl'  => home_url( '/?wc-api=wncpay' ),
		];
		if ( $deposit_agorot > 0 ) {
			$payload['depositAgorot'] = $deposit_agorot;
		}

		// Test mode (v0.5.0): the platform processes this order against the PayMe
		// SANDBOX seller — stamped [TEST] end-to-end, no real money, excluded from
		// revenue and the CRM. The flag rides inside the signed session body.
		$test_mode = 'yes' === $this->get_option( 'test_mode', 'no' );
		if ( $test_mode ) {
			$payload['test'] = true;
		}

		$response = WNCPAY_Api::post( '/api/wncpay/session', $payload );

		if ( is_wp_error( $response ) ) {
			wc_add_notice( __( 'Payment could not be started. Please try again or contact us.', 'wncpay' ), 'error' );
			$order->add_order_note( sprintf( 'WNC Pay: session creation failed — %s', $response->get_error_message() ) );

			return [ 'result' => 'failure' ];
		}

		$order->update_meta_data( '_wncpay_reference', (string) $response['reference'] );
		if ( $test_mode ) {
			$order->update_meta_data( '_wncpay_test', 'yes' );
			$order->add_order_note( 'WNC Pay: TEST transaction — processed via the PayMe sandbox; no real money moved.' );
		}
		$order->update_status( 'pending', __( 'Awaiting platform payment.', 'wncpay' ) );
		$order->add_order_note(
			$deposit_agorot > 0
				? sprintf( 'WNC Pay: payment session %s created — %d%% deposit (₪%s of ₪%s); office confirms availability, balance charged after.', $response['reference'], $percent, number_format( $deposit_agorot / 100, 2 ), number_format( $total_agorot / 100, 2 ) )
				: sprintf( 'WNC Pay: payment session %s created.', $response['reference'] )
		);
		$order->save();

		return [
			'result'   => 'success',
			'redirect' => (string) $response['payUrl'],
		];
	}
}
