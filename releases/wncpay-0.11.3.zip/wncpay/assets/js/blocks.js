/**
 * WNC Pay editor blocks.
 *
 * @package WNCPay
 */

( function ( blocks, element, blockEditor, components, i18n ) {
	'use strict';

	var el = element.createElement;
	var __ = i18n.__;

	blocks.registerBlockType( 'wncpay/gift-designer', {
		apiVersion: 2,
		title: __( 'Gift Card Designer (WNC Pay)', 'wncpay' ),
		description: __( 'Embeds the platform gift card designer. Rendered on the live site.', 'wncpay' ),
		icon: 'tickets-alt',
		category: 'embed',
		keywords: [ __( 'gift', 'wncpay' ), __( 'card', 'wncpay' ), 'wncpay' ],
		attributes: {
			amount: { type: 'string', default: '' },
			matchkey: { type: 'string', default: '' },
			extraParams: { type: 'string', default: '' },
			minHeight: { type: 'number', default: 900 }
		},
		edit: function ( props ) {
			var a = props.attributes;

			function set( key ) {
				return function ( value ) {
					var update = {};
					update[ key ] = value;
					props.setAttributes( update );
				};
			}

			return el(
				'div',
				blockEditor.useBlockProps(),
				el(
					components.Placeholder,
					{
						icon: 'tickets-alt',
						label: __( 'WNC Pay — Gift Card Designer', 'wncpay' ),
						instructions: __( 'This block renders the platform gift card designer on the live site.', 'wncpay' )
					},
					el( 'div', { style: { width: '100%' } },
						el( components.TextControl, {
							label: __( 'Preset amount (optional)', 'wncpay' ),
							value: a.amount,
							onChange: set( 'amount' )
						} ),
						el( components.TextControl, {
							label: __( 'Match key (optional)', 'wncpay' ),
							value: a.matchkey,
							onChange: set( 'matchkey' )
						} ),
						el( components.TextControl, {
							label: __( 'Extra parameters (optional)', 'wncpay' ),
							help: __( 'Query-string format, e.g. dealId=123&theme=dark', 'wncpay' ),
							value: a.extraParams,
							onChange: set( 'extraParams' )
						} ),
						el( components.TextControl, {
							label: __( 'Minimum height (px)', 'wncpay' ),
							type: 'number',
							value: a.minHeight,
							onChange: function ( value ) {
								props.setAttributes( { minHeight: parseInt( value, 10 ) || 900 } );
							}
						} )
					)
				)
			);
		},
		save: function () {
			return null;
		}
	} );
} )( window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.components, window.wp.i18n );
