<?php
/**
 * Uninstall cleanup.
 *
 * @package WNCPay
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'wncpay_options' );
