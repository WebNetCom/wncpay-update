<?php
/**
 * WooCommerce integration bootstrap: registers the gateway + webhook only when
 * WooCommerce is active, declares HPOS compatibility.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_WooCommerce
 */
final class WNCPAY_WooCommerce {

	/**
	 * WNCPAY_WooCommerce constructor.
	 */
	public function __construct() {
		add_action( 'plugins_loaded', [ $this, 'maybe_boot' ], 20 );
		add_action( 'before_woocommerce_init', [ $this, 'declare_compatibility' ] );
	}

	/**
	 * Load the gateway pieces when WooCommerce is present.
	 *
	 * @return void
	 */
	public function maybe_boot(): void {
		if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
			return;
		}

		require_once WNCPAY_PATH . 'includes/gateway/class-wncpay-gateway.php';
		require_once WNCPAY_PATH . 'includes/gateway/class-wncpay-gateway-webhook.php';

		new WNCPAY_Gateway_Webhook();

		add_filter( 'woocommerce_payment_gateways', [ $this, 'register_gateway' ] );
		add_action( 'woocommerce_thankyou_wncpay', [ $this, 'thankyou_account_link' ] );
		add_action( 'woocommerce_email_after_order_table', [ $this, 'email_account_link' ], 10, 3 );
	}

	/**
	 * The customer's account URL on the platform (locale-aware).
	 *
	 * @return string Empty when the platform is not configured.
	 */
	public static function account_url(): string {
		$base = WNCPAY_Embed::platform_url();

		if ( '' === $base ) {
			return '';
		}

		$url = $base . ( 'he' === WNCPAY_Embed::locale() ? '/he' : '' ) . '/account';

		/**
		 * Filter the customer account URL shown after checkout and in emails.
		 *
		 * @param string $url Account URL.
		 */
		return (string) apply_filters( 'wncpay_account_url', $url );
	}

	/**
	 * Order-received page: point the customer at their platform account.
	 *
	 * @param int $order_id Order id.
	 *
	 * @return void
	 */
	public function thankyou_account_link( $order_id ): void {
		$url = self::account_url();

		if ( '' === $url ) {
			return;
		}

		printf(
			'<section class="wncpay-account-note" style="margin:1.2em 0;padding:14px 18px;border:1px solid #e2e2e2;border-radius:8px;">%s <a href="%s">%s</a></section>',
			esc_html__( 'Your booking, receipts, balance and documents are available anytime in your account:', 'wncpay' ),
			esc_url( $url ),
			esc_html( preg_replace( '#^https?://#', '', $url ) )
		);
	}

	/**
	 * Order emails: same pointer, only for orders paid via WNC Pay.
	 *
	 * @param WC_Order $order         Order.
	 * @param bool     $sent_to_admin Whether this email goes to the admin.
	 * @param bool     $plain_text    Plain-text email flag.
	 *
	 * @return void
	 */
	public function email_account_link( $order, $sent_to_admin, $plain_text ): void {
		if ( $sent_to_admin || ! $order instanceof WC_Order || 'wncpay' !== $order->get_payment_method() ) {
			return;
		}

		$url = self::account_url();

		if ( '' === $url ) {
			return;
		}

		if ( $plain_text ) {
			echo "\n" . esc_html__( 'Your booking, receipts, balance and documents are available anytime in your account:', 'wncpay' ) . ' ' . esc_url( $url ) . "\n";

			return;
		}

		printf(
			'<p style="margin:16px 0;">%s <a href="%s">%s</a></p>',
			esc_html__( 'Your booking, receipts, balance and documents are available anytime in your account:', 'wncpay' ),
			esc_url( $url ),
			esc_html( preg_replace( '#^https?://#', '', $url ) )
		);
	}

	/**
	 * Add the gateway to WooCommerce's list.
	 *
	 * @param array $gateways Registered gateway classes.
	 *
	 * @return array
	 */
	public function register_gateway( array $gateways ): array {
		$gateways[] = WNCPAY_Gateway::class;

		return $gateways;
	}

	/**
	 * HPOS (custom order tables) compatibility.
	 *
	 * @return void
	 */
	public function declare_compatibility(): void {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', WNCPAY_FILE, true );
		}
	}
}
