<?php
/**
 * Signed webhook receiver: the platform flips Woo orders here.
 *
 * Endpoint: https://<site>/?wc-api=wncpay  (woocommerce_api_wncpay).
 * Payload + signature scheme: platform docs/wncpay-gateway-api.md.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Gateway_Webhook
 */
final class WNCPAY_Gateway_Webhook {

	/**
	 * WNCPAY_Gateway_Webhook constructor.
	 */
	public function __construct() {
		add_action( 'woocommerce_api_wncpay', [ $this, 'handle' ] );
	}

	/**
	 * Handle a platform webhook.
	 *
	 * @return void
	 */
	public function handle(): void {
		$body = (string) file_get_contents( 'php://input' );

		$timestamp = isset( $_SERVER['HTTP_X_WNCPAY_TIMESTAMP'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_WNCPAY_TIMESTAMP'] ) ) : null;
		$signature = isset( $_SERVER['HTTP_X_WNCPAY_SIGNATURE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_WNCPAY_SIGNATURE'] ) ) : null;

		if ( ! WNCPAY_Api::verify( $timestamp, $signature, $body ) ) {
			wp_send_json( [ 'ok' => false, 'error' => 'bad_signature' ], 401 );
		}

		$data = json_decode( $body, true );

		if ( ! is_array( $data ) || empty( $data['orderId'] ) || empty( $data['orderKey'] ) || empty( $data['event'] ) ) {
			wp_send_json( [ 'ok' => false, 'error' => 'bad_payload' ], 400 );
		}

		$order = wc_get_order( absint( $data['orderId'] ) );

		if ( ! $order || ! hash_equals( $order->get_order_key(), (string) $data['orderKey'] ) ) {
			wp_send_json( [ 'ok' => false, 'error' => 'order_not_found' ], 404 );
		}

		$reference = (string) ( $data['reference'] ?? '' );
		$amount    = isset( $data['amountAgorot'] ) ? number_format( ( (int) $data['amountAgorot'] ) / 100, 2 ) : '?';

		if ( 'paid' === $data['event'] ) {
			if ( $order->is_paid() ) {
				// IPNs multi-fire — already handled.
				wp_send_json( [ 'ok' => true, 'note' => 'already_paid' ] );
			}

			$order->payment_complete( (string) ( $data['transactionId'] ?? $reference ) );
			$order->add_order_note( sprintf( 'WNC Pay: payment received — ₪%s (platform reference %s).', $amount, $reference ) );
			$order->save();

			wp_send_json( [ 'ok' => true ] );
		}

		if ( 'failed' === $data['event'] ) {
			// A late failure must NEVER flip an already-paid order (races with the
			// paid webhook / IPN multi-fire).
			if ( $order->is_paid() ) {
				wp_send_json( [ 'ok' => true, 'note' => 'paid_wins' ] );
			}

			$detail = (string) ( $data['detail'] ?? '' );
			$order->update_status( 'failed', sprintf( 'WNC Pay: payment failed%s (platform reference %s). The customer can retry from the same platform link.', '' !== $detail ? ' — ' . $detail : '', $reference ) );

			wp_send_json( [ 'ok' => true ] );
		}

		wp_send_json( [ 'ok' => false, 'error' => 'unknown_event' ], 400 );
	}
}
