<?php
/**
 * Floating "Gift this adventure" button on tour pages.
 *
 * v0.9.0 -- Talie: on every website tour page, float a small branded tab under
 * the accessibility icon (about a third down the screen) — left edge on EN,
 * right edge on HE — that takes the visitor to the gift-card page WITH the
 * tour context (?fromtour=<path>). The resize script forwards that context
 * into the gift embed as ref=<path>, and the platform resolves the tour by its
 * website slugs, so the designer opens with the tour's photos + name prefilled.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Gift_Button
 */
final class WNCPAY_Gift_Button {

	/**
	 * WNCPAY_Gift_Button constructor.
	 */
	public function __construct() {
		add_action( 'wp_footer', [ $this, 'render' ], 6 );
	}

	/**
	 * Print the floating button when enabled and the current page matches.
	 *
	 * @return void
	 */
	public function render(): void {
		if ( is_admin() || '1' !== WNCPAY_Embed::get_option( 'gift_button' ) ) {
			return;
		}

		$gift_page = trim( WNCPAY_Embed::get_option( 'gift_button_page' ) );
		if ( '' === $gift_page ) {
			return;
		}

		$prefix = trim( WNCPAY_Embed::get_option( 'gift_button_prefix' ) );
		$prefix = '' === $prefix ? '/sites/' : $prefix;

		$path = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ) : '';
		// Match any of the comma-separated prefixes (default: tour pages only).
		$matched = false;
		foreach ( array_filter( array_map( 'trim', explode( ',', $prefix ) ) ) as $p ) {
			// The prefix may appear after a WPML language folder (/he/sites/…).
			if ( 0 === strpos( $path, $p ) || false !== strpos( $path, $p ) ) {
				$matched = true;
				break;
			}
		}
		if ( ! $matched ) {
			return;
		}

		$is_he = ( 'he' === WNCPAY_Embed::locale() );
		$href  = add_query_arg( 'fromtour', rawurlencode( $path ), $gift_page );
		$label = $is_he ? 'העניקו את החוויה במתנה' : 'Gift this adventure';
		$side  = $is_he ? 'right' : 'left';
		$rad   = $is_he ? '999px 0 0 999px' : '0 999px 999px 0';

		printf(
			'<a href="%s" class="wncpay-gift-fab" aria-label="%s" style="position:fixed;top:36%%;%s:0;z-index:99990;display:flex;align-items:center;gap:8px;background:#f5a623;color:#111;font-weight:700;font-size:14px;line-height:1;padding:11px 14px;border-radius:%s;box-shadow:0 4px 14px rgba(0,0,0,.25);text-decoration:none;font-family:inherit">'
			. '<span style="font-size:18px">🎁</span><span class="wncpay-gift-fab-label">%s</span></a>'
			. '<style>@media(max-width:640px){.wncpay-gift-fab-label{display:none}.wncpay-gift-fab{padding:11px 12px}}.wncpay-gift-fab:hover{filter:brightness(1.05)}</style>',
			esc_url( $href ),
			esc_attr( $label ),
			esc_attr( $side ),
			esc_attr( $rad ),
			esc_html( $label )
		);
	}
}
