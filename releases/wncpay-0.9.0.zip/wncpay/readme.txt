=== WNC Pay ===
Contributors: webnetcom
Tags: embed, gift cards, elementor, shortcode, block
Requires at least: 6.0
Tested up to: 7.0
Stable tag: 0.9.0
Requires PHP: 8.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Embed elements from your connected platform — gift card designer and more — via shortcode, Elementor widget, or block.

== Description ==

WNC Pay connects a WordPress site to an operator platform and lets the site builder place platform elements anywhere on the site. Each element is available three ways, so you can use whatever fits your workflow:

* **Elementor widgets** — a native "WNC Pay" category.
* **Shortcodes** — e.g. `[wncpay_gift_designer amount="750"]`, or the generic `[wncpay_embed path="/gift"]`.
* **Blocks** — search for "WNC Pay" in the block inserter.

= Shortcode examples =

* `[wncpay_gift_designer]` — the gift designer, no options needed.
* `[wncpay_gift_designer amount="750"]` — pre-selected amount.
* `[wncpay_gift_designer matchkey="masada-sunrise"]` — a specific tour's photo card.
* `[wncpay_gift_designer dealid="123456789012" name="Dana" email="dana@example.com"]` — filed on a CRM deal, buyer prefilled.
* `[wncpay_embed path="/gift" product="abc123" min_height="1200"]` — generic embed of any platform path; unknown attributes pass through as URL parameters.

The site language (WPML) is passed automatically. The full attribute reference lives on Settings → WNC Pay.

Elements render as secure embeds of the platform with automatic height, and follow the site language (WPML-aware). The plugin's job ends at rendering the embed: styling and placement belong to the site developer; the content and flows inside the frame belong to the platform. No payment data, checkout flow, or personal information is processed or stored by this plugin or by WordPress.

= Elements =

* Gift Card Designer (first release)
* More elements (balance checker, catalog, pay-by-link, quote request) planned.

== External Services ==

This plugin embeds pages served from the platform URL configured by the site administrator under Settings → WNC Pay. When a visitor views a page containing a WNC Pay element, the visitor's browser loads that element directly from the configured platform, which will receive the visitor's IP address and user agent as with any embedded content. All checkout and payment flows run entirely on the connected platform and are subject to the platform operator's terms of service and privacy policy. No data is sent to the platform by the plugin itself.

The plugin also periodically contacts github.com (the public wncpay-update repository) to check for new plugin versions; only standard HTTP request metadata is transmitted. This mechanism is removed when the plugin is distributed through wordpress.org.

When the WNC Pay payment gateway is enabled, checkout sends the order summary and the customer's billing name, email and phone to the configured platform over an authenticated server-to-server call, so the platform can process the payment and issue documents. No card data ever touches WordPress. Payment confirmations arrive as cryptographically signed webhooks from the platform.

== Installation ==

1. Upload and activate the plugin.
2. Go to Settings → WNC Pay and enter the Platform URL and Site Key provided by your platform operator.
3. Place an element via an Elementor widget, shortcode, or block.

= Shortcodes =

* [wncpay_tour_catalog] — interactive tour catalog (window mode by default; mode="auto" for full-height; context-aware "Get more info")
* [wncpay_tour id="..."] — a single tour's full page (id = product id from the platform catalog)
* [wncpay_trip_planner] — build-your-itinerary wizard
* [wncpay_gift_designer] — gift card designer (amount, matchkey, product, dealid, name/email/phone)
* [wncpay_how_it_works] — the planner's "How it works" explainer page
* [wncpay_pay reference="..."] — a specific payment request's pay page
* [wncpay_embed path="/..."] — any platform path; extra attributes become URL parameters

All accept min_height and title. Full reference with examples: Settings → WNC Pay.

= Performance / caching note =

Embeds are page-cache safe. If your site delays JavaScript execution (e.g. WP Rocket's "Delay JavaScript execution"), add `wncpay` to the exclusion list so embeds resize immediately.

== Changelog ==

= 0.9.0 =
* New: floating "🎁 Gift this adventure" tab on tour pages (Settings → WNC Pay → Gift button) — left edge in English, right edge in Hebrew, about a third down the screen. It opens your gift-card page with the tour context, and the gift designer preselects that tour's photos + name on the card.
* Gift-designer embeds now receive the visitor's tour context (?fromtour= from the button, or the same-site referrer) as ref=, like the catalog does.

= 0.8.1 =
* Smoother catalog scrolling: when the page pauses with the catalog window partly visible, it now docks flush under the site menu automatically — one scroll instead of two competing ones. Scrolling up from the catalog top (or deliberately past it) still reaches the rest of the page.

= 0.8.0 =
* Three new shortcodes: [wncpay_tour id="..."] (a single tour's full page), [wncpay_how_it_works] (the planner explainer), and [wncpay_pay reference="..."] (a specific payment request's pay page).
* mode="window|auto" is now a proper attribute on every shortcode.
* Settings → WNC Pay gained a full shortcode reference table — every element, its attributes, and examples in one place.

= 0.7.5 =
* "Get more info" is now context-aware: the catalog embed learns which page of the site the visitor came from and opens the matching tour directly, or pre-filters to the matching category, instead of always showing everything. Same-site referrers only; nothing to configure.

= 0.7.4 =
* Individual tour pages opened from the embedded catalog now take the whole screen while viewed (a full tour page was unusable squeezed into the catalog window); Back returns to the catalog and restores the window.

= 0.7.3 =
* Forms and popups opened inside an embed (quote basket, request form, previews) now expand the frame to cover the full screen for as long as they're open — they stack above the site menu and floating contact buttons, then the frame shrinks back on close.

= 0.7.2 =
* Tour catalog now embeds in "window mode": the frame is sized to the visitor's screen (below the site menu) and the catalog scrolls inside it. The toolbar sticks natively with zero lag, and the quote cart and popups open centered in view. [wncpay_tour_catalog mode="auto"] restores the old full-height behavior.

= 0.7.1 =
* Embedded pages can now pin their own toolbar below the site's menu while the visitor scrolls: the plugin streams each embed frame's viewport position (scroll pin offset, including the height of any fixed/sticky site header) into the frame. Purely visual; nothing to configure.

= 0.7.0 =
* Test transactions are now stamped on the WooCommerce order itself: when the platform reports a payment as TEST (gateway Test mode OR the magic test ID typed at checkout), the order gets a loud TEST order note and the _wncpay_test meta — a test order can never be mistaken for real revenue.

= 0.6.0 =
* New embeds: [wncpay_trip_planner] (interactive trip-builder wizard) and [wncpay_tour_catalog] (browse and pick multiple tours in one place) — host the platform's planner and catalog inside the site so visitors never leave.
* Cross-site failover: if an embed cannot load (privacy mode, proxy, content blocker), it is replaced automatically with an "Open it in a new tab" card instead of a blank frame. Armed per-frame on visibility, so lazy-loaded embeds are unaffected.

= 0.5.0 =
* Test mode (gateway setting): checkouts are sent as TEST transactions — the platform processes them against the PayMe sandbox, the PayMe test card approves for real, no actual money moves, everything is stamped [TEST] and excluded from revenue and the CRM. A yellow TEST banner shows at checkout while enabled.

= 0.4.0 =
* Deposit flow: orders containing tours that need office availability confirmation charge a configurable deposit now (default 30%; the platform pay page also offers "pay in full"), with the stipulation shown at checkout; the office confirms and charges the balance on the platform, and the order completes automatically when the balance webhook arrives (on-hold until then).
* Product editor checkbox "WNC Pay: full payment" — flagged products (non-tours / instant items) charge 100% immediately, skip confirmation and the date question.
* Preferred-date question at checkout for every tour item (sites without a booking plugin): required, saved on the order line, shown in emails, and sent to the platform + CRM deal.

= 0.3.6 =
* Gateway sends the traveller count with each order (WooCommerce Appointments persons meta when present, item quantities otherwise) — lands in the CRM deal's Amount of People field automatically.

= 0.3.5 =
* Full shortcode reference with examples on Settings → WNC Pay (and in this readme) — amount, matchkey, product, dealid, name/email/phone prefills, min_height, title.
* Fix: dealid attribute now reaches the platform correctly (WordPress lowercases shortcode attributes; the plugin maps it back to dealId).

= 0.3.4 =
* Multi-item carts use the platform's multiple-tours document variant (docType cfc_multiple).

= 0.3.3 =
* After a WNC Pay payment, the order-received page and the customer's order emails link to their platform account (locale-aware; filter: wncpay_account_url).

= 0.3.2 =
* Brand logo: checkout icon for the WNC Pay gateway, Settings page header, and plugin icons on the WordPress update screens.

= 0.3.1 =
* Rebuild: the 0.3.0 package was built from the pre-release commit and shipped 0.2.0 code. Identical feature set to 0.3.0.

= 0.3.0 =
* WooCommerce payment gateway: "WNC Pay" appears under WooCommerce → Settings → Payments. Checkout redirects to the platform's secure payment page and returns; orders are completed by a signed platform webhook (HMAC, replay-protected, late failures never overwrite a paid order). ILS carts only. HPOS compatible.
* Connection status indicator on Settings → WNC Pay (live authorize check against the platform).

= 0.2.0 =
* Native WordPress updates via the public wncpay-update release channel (Plugin Update Checker).

= 0.1.0 =
* First release: settings page, embed core with auto-height and WPML-aware locale, Gift Card Designer as Elementor widget + shortcode + block.
