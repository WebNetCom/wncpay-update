<?php
/**
 * Shortcodes.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Shortcodes
 */
final class WNCPAY_Shortcodes {

	/**
	 * Display-only attributes that are never forwarded as query parameters.
	 *
	 * @var string[]
	 */
	private const DISPLAY_ATTS = [ 'path', 'min_height', 'title' ];

	/**
	 * WNCPAY_Shortcodes constructor.
	 */
	public function __construct() {
		add_shortcode( 'wncpay_embed', [ $this, 'render_embed' ] );
		add_shortcode( 'wncpay_gift_designer', [ $this, 'render_gift_designer' ] );
		add_shortcode( 'wncpay_trip_planner', [ $this, 'render_trip_planner' ] );
		add_shortcode( 'wncpay_tour_catalog', [ $this, 'render_tour_catalog' ] );
	}

	/**
	 * Generic embed shortcode: [wncpay_embed path="/gift" amount="750" min_height="900"].
	 *
	 * Every attribute except path/min_height/title is forwarded as a query parameter.
	 *
	 * @param array|string $atts Shortcode attributes.
	 *
	 * @return string
	 */
	public function render_embed( $atts ): string {
		$atts = is_array( $atts ) ? $atts : [];
		$path = ! empty( $atts['path'] ) ? (string) $atts['path'] : '/';

		return WNCPAY_Embed::render( $path, $this->extract_params( $atts ), $this->extract_args( $atts ) );
	}

	/**
	 * Trip-builder wizard: [wncpay_trip_planner]. The visitor builds an
	 * interactive itinerary without leaving the site (v0.6.0).
	 *
	 * @param array|string $atts Shortcode attributes.
	 *
	 * @return string
	 */
	public function render_trip_planner( $atts ): string {
		$atts = is_array( $atts ) ? $atts : [];
		$path = ! empty( $atts['path'] ) ? (string) $atts['path'] : (string) apply_filters( 'wncpay_trip_planner_path', '/plan' );

		return WNCPAY_Embed::render( $path, $this->extract_params( $atts ), $this->extract_args( $atts ) );
	}

	/**
	 * Interactive tour catalog: [wncpay_tour_catalog]. The visitor browses and
	 * picks multiple tours in one place instead of a contact form per tour (v0.6.0).
	 *
	 * @param array|string $atts Shortcode attributes.
	 *
	 * @return string
	 */
	public function render_tour_catalog( $atts ): string {
		$atts = is_array( $atts ) ? $atts : [];
		$path = ! empty( $atts['path'] ) ? (string) $atts['path'] : (string) apply_filters( 'wncpay_tour_catalog_path', '/tours' );

		return WNCPAY_Embed::render( $path, $this->extract_params( $atts ), $this->extract_args( $atts ) );
	}

	/**
	 * Gift designer shortcode: [wncpay_gift_designer amount="750" matchkey="..."].
	 *
	 * @param array|string $atts Shortcode attributes.
	 *
	 * @return string
	 */
	public function render_gift_designer( $atts ): string {
		$atts = is_array( $atts ) ? $atts : [];

		/**
		 * Filter the platform path of the gift designer element.
		 *
		 * @param string $path Default path.
		 */
		$path = ! empty( $atts['path'] )
			? (string) $atts['path']
			: (string) apply_filters( 'wncpay_gift_designer_path', '/gift' );

		$args = $this->extract_args( $atts );

		if ( empty( $args['title'] ) ) {
			$args['title'] = __( 'Gift card designer', 'wncpay' );
		}

		return WNCPAY_Embed::render( $path, $this->extract_params( $atts ), $args );
	}

	/**
	 * Forwardable query parameters from shortcode attributes.
	 *
	 * @param array $atts Shortcode attributes.
	 *
	 * @return array
	 */
	private function extract_params( array $atts ): array {
		$params = [];

		foreach ( $atts as $key => $value ) {
			if ( is_int( $key ) || in_array( $key, self::DISPLAY_ATTS, true ) ) {
				continue;
			}

			$key = sanitize_key( $key );

			if ( '' !== $key ) {
				$params[ $key ] = sanitize_text_field( (string) $value );
			}
		}

		return $params;
	}

	/**
	 * Display arguments from shortcode attributes.
	 *
	 * @param array $atts Shortcode attributes.
	 *
	 * @return array
	 */
	private function extract_args( array $atts ): array {
		$args = [];

		if ( ! empty( $atts['min_height'] ) ) {
			$args['min_height'] = absint( $atts['min_height'] );
		}

		if ( ! empty( $atts['title'] ) ) {
			$args['title'] = sanitize_text_field( (string) $atts['title'] );
		}

		return $args;
	}
}
