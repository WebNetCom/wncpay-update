<?php
/**
 * Elementor integration.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Elementor
 */
final class WNCPAY_Elementor {

	/**
	 * WNCPAY_Elementor constructor.
	 */
	public function __construct() {
		add_action( 'elementor/elements/categories_registered', [ $this, 'register_category' ] );
		add_action( 'elementor/widgets/register', [ $this, 'register_widgets' ] );
	}

	/**
	 * Register the "WNC Pay" widget category.
	 *
	 * @param \Elementor\Elements_Manager $elements_manager Elementor elements manager.
	 *
	 * @return void
	 */
	public function register_category( $elements_manager ): void {
		$elements_manager->add_category(
			'wncpay',
			[
				'title' => __( 'WNC Pay', 'wncpay' ),
				'icon'  => 'eicon-cart-medium',
			]
		);
	}

	/**
	 * Register widgets.
	 *
	 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
	 *
	 * @return void
	 */
	public function register_widgets( $widgets_manager ): void {
		require_once WNCPAY_PATH . 'includes/elementor/widgets/class-wncpay-gift-designer-widget.php';

		$widgets_manager->register( new WNCPAY_Gift_Designer_Widget() );
	}
}
