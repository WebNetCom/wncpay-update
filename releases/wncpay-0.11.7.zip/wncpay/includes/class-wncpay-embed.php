<?php
/**
 * Embed URL building and iframe rendering.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Embed
 */
final class WNCPAY_Embed {

	/**
	 * Whether at least one embed was rendered on this page.
	 *
	 * @var bool
	 */
	private static bool $rendered = false;

	/**
	 * Get a plugin option value.
	 *
	 * @param string $key Option key.
	 *
	 * @return string
	 */
	public static function get_option( string $key ): string {
		$options = get_option( 'wncpay_options', [] );

		return isset( $options[ $key ] ) ? (string) $options[ $key ] : '';
	}

	/**
	 * Configured platform base URL (no trailing slash), or empty string.
	 *
	 * @return string
	 */
	public static function platform_url(): string {
		return untrailingslashit( self::get_option( 'platform_url' ) );
	}

	/**
	 * The scheme://host[:port] origin of the platform URL, or empty string.
	 *
	 * @return string
	 */
	public static function platform_origin(): string {
		$parts = wp_parse_url( self::platform_url() );

		if ( empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			return '';
		}

		$origin = $parts['scheme'] . '://' . $parts['host'];

		if ( ! empty( $parts['port'] ) ) {
			$origin .= ':' . $parts['port'];
		}

		return $origin;
	}

	/**
	 * Current two-letter locale, WPML-aware.
	 *
	 * @return string
	 */
	public static function locale(): string {
		$lang = apply_filters( 'wpml_current_language', null );

		if ( ! is_string( $lang ) || '' === $lang ) {
			$lang = substr( get_locale(), 0, 2 );
		}

		return sanitize_key( $lang );
	}

	/**
	 * Build an embed URL for a platform path.
	 *
	 * @param string $path   Path on the platform (e.g. "/gift").
	 * @param array  $params Extra query parameters.
	 *
	 * @return string Empty string when the platform URL is not configured.
	 */
	public static function url( string $path, array $params = [] ): string {
		$base = self::platform_url();

		if ( '' === $base ) {
			return '';
		}

		$params = array_filter(
			$params,
			static function ( $value ) {
				return null !== $value && '' !== $value;
			}
		);

		// WordPress lowercases shortcode attribute names (and sanitize_key does
		// the same for widget/block params), but the platform reads camelCase
		// `dealId` — map it back so [wncpay_gift_designer dealid="…"] works.
		if ( isset( $params['dealid'] ) && ! isset( $params['dealId'] ) ) {
			$params['dealId'] = $params['dealid'];
			unset( $params['dealid'] );
		}

		$params['embed'] = '1';
		$params['lang']  = self::locale();

		$url = add_query_arg( urlencode_deep( $params ), $base . '/' . ltrim( $path, '/' ) );

		/**
		 * Filter the final embed URL.
		 *
		 * @param string $url    Embed URL.
		 * @param string $path   Requested platform path.
		 * @param array  $params Query parameters.
		 */
		return (string) apply_filters( 'wncpay_embed_url', $url, $path, $params );
	}

	/**
	 * Render an embed iframe.
	 *
	 * @param string $path   Path on the platform (e.g. "/gift").
	 * @param array  $params Extra query parameters.
	 * @param array  $args   Display arguments: min_height (int), title (string).
	 *
	 * @return string
	 */
	public static function render( string $path, array $params = [], array $args = [] ): string {
		$url = self::url( $path, $params );

		if ( '' === $url ) {
			if ( current_user_can( 'manage_options' ) ) {
				return '<div class="wncpay-notice" style="padding:12px;border:1px dashed #c00;color:#c00;">'
					. esc_html__( 'WNC Pay: set the Platform URL under Settings → WNC Pay to display this element. (Only administrators see this message.)', 'wncpay' )
					. '</div>';
			}

			return '';
		}

		$min_height = isset( $args['min_height'] ) ? absint( $args['min_height'] ) : 0;
		$min_height = $min_height > 0 ? max( 200, min( 20000, $min_height ) ) : 900;
		$title      = ! empty( $args['title'] ) ? (string) $args['title'] : __( 'Embedded platform content', 'wncpay' );
		// v0.7.2 -- embed mode: 'auto' (frame grows to full content height,
		// page scrolls normally) or 'window' (frame is sized to the visitor's
		// screen and the content scrolls INSIDE it -- sticky toolbars and
		// popups behave natively; used by the tour catalog).
		$mode = ( isset( $args['mode'] ) && 'window' === $args['mode'] ) ? 'window' : 'auto';
		// v0.8.0 -- dedicated single-page embeds (e.g. [wncpay_tour]) must not
		// auto-expand to full screen on load; that behavior is for in-catalog
		// navigation. The JS honors this attribute for wncpay:page messages.
		$noexpand = ! empty( $args['noexpand'] ) ? ' data-wncpay-noexpand="1"' : '';

		self::$rendered = true;

		// Cross-site failover (v0.6.0): some environments never let the frame
		// load (aggressive privacy modes, corporate proxies, content blockers).
		// The platform posts a wncpay:resize message as soon as the page runs;
		// if no message arrives within the timeout, the resize script below
		// swaps the frame for this card, whose button opens the same page
		// full-screen (without embed=1). The visitor is never left with a blank hole.
		$full_url = remove_query_arg( 'embed', $url );
		$fallback = sprintf(
			'<div class="wncpay-embed-fallback" hidden style="padding:28px 20px;border:1px solid #e5e7eb;border-radius:14px;text-align:center;background:#fafafa">'
			. '<p style="margin:0 0 14px;font-size:15px">%s</p>'
			. '<a href="%s" target="_blank" rel="noopener" style="display:inline-block;background:#f5a623;color:#111;font-weight:700;padding:10px 22px;border-radius:999px;text-decoration:none">%s</a>'
			. '</div>',
			esc_html__( 'This section could not load inside the page (a browser privacy setting may be blocking it).', 'wncpay' ),
			esc_url( $full_url ),
			esc_html__( 'Open it in a new tab', 'wncpay' )
		);

		return sprintf(
			'<div class="wncpay-embed-wrap" data-wncpay-pending="1"><iframe class="wncpay-embed" data-wncpay-mode="%s"%s src="%s" title="%s" loading="lazy" allow="payment" style="width:100%%;border:0;display:block;min-height:%dpx"></iframe>%s</div>',
			esc_attr( $mode ),
			$noexpand,
			esc_url( $url ),
			esc_attr( $title ),
			$min_height,
			$fallback
		);
	}

	/**
	 * Print the auto-height listener once per page.
	 *
	 * Inlined (not enqueued) so page optimizers that defer or delay JavaScript
	 * do not postpone iframe resizing. Only messages from the configured
	 * platform origin are accepted, and only for frames this plugin rendered.
	 *
	 * @return void
	 */
	public static function print_resize_script(): void {
		// v0.11.6 -- cart-icon capture is SITE-WIDE: pages without an embed
		// still need the click handler (fallback to the order page) and the
		// remembered badge count. The frame-specific listeners are no-ops when
		// no frame exists on the page.
		if ( ! self::$rendered && self::get_option( 'cart_capture' ) !== '1' ) {
			return;
		}

		$origin = self::platform_origin();

		if ( '' === $origin ) {
			return;
		}

		?>
		<script id="wncpay-resize" data-cfasync="false" data-no-optimize="1">
		( function () {
			var allowed = <?php echo wp_json_encode( $origin ); ?>;
			// v0.11.0 -- cart icon capture (Settings -> WNC Pay -> Cart icon).
			var cartCapture = <?php echo self::get_option( 'cart_capture' ) === '1' ? 'true' : 'false'; ?>;
			var cartSel = <?php echo wp_json_encode( '' !== self::get_option( 'cart_selector' ) ? self::get_option( 'cart_selector' ) : '.elementor-menu-cart__toggle_button, a.cart-contents' ); ?>;
			var cartFallback = <?php echo wp_json_encode( self::get_option( 'section_cta_page' ) ); ?>;

			// v0.7.5 -- pass the SAME-SITE page the visitor came from into
			// catalog frames (ref=<path>) BEFORE they lazy-load: the platform
			// opens the matching tour directly or pre-filters its category
			// ("Get more info" from an individual tour page). Cross-site
			// referrers are never sent.
			// v0.9.0 -- gift-designer frames get the same context: the floating
			// "Gift this adventure" button links with ?fromtour=<path>, which
			// wins over the referrer; the platform prefills that tour's photos
			// + name on the card.
			try {
				var ctxPath = '';
				try { ctxPath = new URLSearchParams( window.location.search ).get( 'fromtour' ) || ''; } catch ( qErr ) {}
				var refUrl  = document.referrer ? new URL( document.referrer ) : null;
				var refPath = ( refUrl && refUrl.host === window.location.host && refUrl.pathname && '/' !== refUrl.pathname ) ? refUrl.pathname : '';
				var refFrames = document.querySelectorAll( 'iframe.wncpay-embed' );
				for ( var r = 0; r < refFrames.length; r++ ) {
					var refSrc = refFrames[ r ].getAttribute( 'src' ) || '';
					if ( refSrc.indexOf( 'ref=' ) !== -1 ) {
						continue;
					}
					var want = '';
					if ( refSrc.indexOf( '/tours' ) !== -1 ) {
						want = refPath;
					} else if ( refSrc.indexOf( '/gift' ) !== -1 ) {
						want = ctxPath || refPath;
					}
					if ( ! want ) {
						continue;
					}
					refFrames[ r ].setAttribute( 'src', refSrc + ( refSrc.indexOf( '?' ) === -1 ? '?' : '&' ) + 'ref=' + encodeURIComponent( want ) );
				}
			} catch ( refErr ) {
				// URL() unsupported or blocked referrer -- catalog just shows everything.
			}
			window.addEventListener( 'message', function ( e ) {
				if ( e.origin !== allowed ) {
					return;
				}
				var d = e.data;
				if ( ! d || 'wncpay:resize' !== d.type ) {
					return;
				}
				var h = parseInt( d.height, 10 );
				if ( ! h || h < 100 || h > 20000 ) {
					return;
				}
				var frames = document.querySelectorAll( 'iframe.wncpay-embed' );
				for ( var i = 0; i < frames.length; i++ ) {
					if ( frames[ i ].contentWindow === e.source ) {
						// v0.7.2 -- window-mode frames keep their viewport-based
						// height (set below); the content scrolls inside them.
						// v0.10.3 -- unless the page asked to FLOW (tour pages):
						// then the frame takes its full content height so the
						// site page scrolls as ONE document (header above,
						// site footer after the content).
						// v0.10.5 -- never while EXPANDED (modal open): the
						// expansion pins the frame to the visitor's screen at
						// 100vh; a content-height resize arriving mid-modal was
						// stretching that overlay to thousands of px, pushing
						// the modal below the fold ("the popup never shows").
						if ( ( 'window' !== frames[ i ].getAttribute( 'data-wncpay-mode' ) || frames[ i ].__wncpayFlow ) && ! frames[ i ].__wncpayExpanded ) {
							frames[ i ].style.height = h + 'px';
							frames[ i ].style.minHeight = '0';
						}
						var wrap = frames[ i ].closest( '.wncpay-embed-wrap' );
						if ( wrap ) {
							// First message = the embed is alive; cancel the failover.
							wrap.removeAttribute( 'data-wncpay-pending' );
						}
						break;
					}
				}
			} );

			// Failover: an embed that has not posted a resize message within the
			// timeout AFTER becoming visible is assumed blocked (privacy mode /
			// proxy / content blocker). Swap the frame for the open-in-new-tab
			// card so the visitor is never stuck on a blank hole. The countdown
			// is armed per-frame on visibility because loading="lazy" means an
			// off-screen frame legitimately hasn't even started loading yet.
			var swapOne = function ( wrap ) {
				if ( ! wrap.hasAttribute( 'data-wncpay-pending' ) ) {
					return;
				}
				var frame = wrap.querySelector( 'iframe.wncpay-embed' );
				var card  = wrap.querySelector( '.wncpay-embed-fallback' );
				if ( frame ) { frame.style.display = 'none'; }
				if ( card ) { card.hidden = false; }
			};
			var arm = function ( wrap ) {
				if ( wrap.__wncpayArmed ) {
					return;
				}
				wrap.__wncpayArmed = true;
				setTimeout( function () { swapOne( wrap ); }, 10000 );
			};
			var wraps = document.querySelectorAll( '.wncpay-embed-wrap[data-wncpay-pending]' );
			if ( 'IntersectionObserver' in window ) {
				var io = new IntersectionObserver( function ( entries ) {
					for ( var i = 0; i < entries.length; i++ ) {
						if ( entries[ i ].isIntersecting ) {
							arm( entries[ i ].target );
							io.unobserve( entries[ i ].target );
						}
					}
				}, { rootMargin: '200px' } );
				for ( var i = 0; i < wraps.length; i++ ) {
					io.observe( wraps[ i ] );
				}
			} else {
				for ( var j = 0; j < wraps.length; j++ ) {
					arm( wraps[ j ] );
				}
			}

			// v0.7.1 -- Viewport streaming: the platform pages can't use CSS
			// sticky inside the auto-height iframe (the frame never scrolls
			// itself), so on parent scroll/resize we stream each frame's pin
			// offset -- how far the frame's top has scrolled past the visible
			// top of the viewport, plus the height of any fixed/sticky site
			// menu bar -- and the embedded page pins its own toolbar there.
			// Purely visual; the platform ignores it outside embed mode.
			var menuOffset = function () {
				var best = 0;
				if ( ! document.elementsFromPoint ) {
					return best;
				}
				var els = document.elementsFromPoint( Math.max( 1, window.innerWidth / 2 ), 1 ) || [];
				for ( var i = 0; i < els.length; i++ ) {
					var el = els[ i ];
					if ( el === document.documentElement || el === document.body ) {
						continue;
					}
					var cs = window.getComputedStyle( el );
					if ( 'fixed' !== cs.position && 'sticky' !== cs.position ) {
						continue;
					}
					var r = el.getBoundingClientRect();
					if ( r.top <= 1 && r.width > window.innerWidth * 0.5 && r.bottom > best && r.bottom < window.innerHeight * 0.4 ) {
						best = r.bottom;
					}
				}
				return best;
			};
			var vpRaf = 0;
			var sendViewport = function () {
				vpRaf = 0;
				var frames = document.querySelectorAll( 'iframe.wncpay-embed' );
				if ( ! frames.length ) {
					return;
				}
				var offset = menuOffset();
				for ( var i = 0; i < frames.length; i++ ) {
					// v0.7.2 -- window mode: the frame fills the visible screen
					// below the site's menu and its content scrolls internally.
					// Sticky bars and popups then behave natively -- no pin
					// streaming (and none is sent to these frames).
					if ( 'window' === frames[ i ].getAttribute( 'data-wncpay-mode' ) && ! frames[ i ].__wncpayFlow ) {
						var wh = Math.max( 480, window.innerHeight - offset );
						frames[ i ].style.height = wh + 'px';
						frames[ i ].style.minHeight = '0';
						continue;
					}
					var win = frames[ i ].contentWindow;
					if ( ! win ) {
						continue;
					}
					var rect = frames[ i ].getBoundingClientRect();
					var pin = Math.max( 0, offset - rect.top );
					// Don't pin past the bottom of the frame (small frames).
					pin = Math.min( pin, Math.max( 0, rect.height - 200 ) );
					try {
						// v0.10.4 -- vh: visible height of the frame region (screen minus the
						// sticky menu). The embed centers floating chips with it.
						win.postMessage( { type: 'wncpay:viewport', pin: pin, vh: Math.max( 240, window.innerHeight - offset ) }, allowed );
					} catch ( err ) {
						// Frame not on the platform origin (failover card shown) -- ignore.
					}
				}
			};
			var scheduleViewport = function () {
				if ( ! vpRaf ) {
					vpRaf = window.requestAnimationFrame( sendViewport );
				}
			};
			window.addEventListener( 'scroll', scheduleViewport, { passive: true } );
			window.addEventListener( 'resize', scheduleViewport, { passive: true } );

			// v0.8.1 -- Dock-on-pause: a window-mode frame half-visible on the
			// page leaves the visitor juggling two scrollbars ("jumpy"). When
			// scrolling pauses with the frame's top in the docking band (below
			// the menu, above mid-screen), glide the page so the frame sits
			// FLUSH under the menu -- from there the inner scroll takes over,
			// and scrolling up past the catalog's top chains back to the page
			// naturally. Deliberately scrolling past the frame is never fought.
			var dockTimer = 0;
			var dockFrames = function () {
				var frames = document.querySelectorAll( 'iframe.wncpay-embed[data-wncpay-mode="window"]' );
				if ( ! frames.length ) {
					return;
				}
				var offset = menuOffset();
				for ( var i = 0; i < frames.length; i++ ) {
					if ( frames[ i ].__wncpayExpanded || frames[ i ].__wncpayFlow ) {
						continue;
					}
					var rect = frames[ i ].getBoundingClientRect();
					if ( rect.top > offset + 1 && rect.top < window.innerHeight * 0.55 ) {
						window.scrollTo( { top: window.pageYOffset + rect.top - offset, behavior: 'smooth' } );
						break;
					}
				}
			};
			window.addEventListener( 'scroll', function () {
				if ( dockTimer ) {
					clearTimeout( dockTimer );
				}
				dockTimer = setTimeout( dockFrames, 170 );
			}, { passive: true } );

			// v0.7.3/0.7.4 -- Full-screen expansion. Two triggers, one behavior:
			//   wncpay:modal {open}  -- transient (quote form / basket open)
			//   wncpay:page {expand} -- per-page (individual tour pages, which
			//                           are unusable squeezed into the window)
			// While either flag is on, the frame covers the whole screen (above
			// the site menu and floating buttons); when both are off it is
			// restored and re-sized. Messages only from the platform origin.
			var applyExpand = function ( f ) {
				var want = !! ( f.__wncpayModal || f.__wncpayPage );
				if ( want && ! f.__wncpayExpanded ) {
					f.__wncpayExpanded = true;
					f.__wncpaySavedStyle = f.getAttribute( 'style' ) || '';
					f.__wncpaySavedScrollLock = document.documentElement.style.overflow || '';
					f.__wncpaySavedScrollY = window.pageYOffset || 0;
					// v0.10.7 -- an ancestor with its own z-index (page builders
					// wrap embeds in sections with explicit stacking, e.g.
					// z-index:1200) creates a stacking context the fullscreen
					// frame can NEVER escape -- other page sections (footer at
					// z 99999) painted over the open popup. Neutralize ancestor
					// z-indexes for the duration; restored on close.
					f.__wncpayZSaved = [];
					var anc = f.parentElement;
					while ( anc && anc !== document.body && anc !== document.documentElement ) {
						try {
							if ( 'auto' !== window.getComputedStyle( anc ).zIndex ) {
								f.__wncpayZSaved.push( [ anc, anc.style.zIndex ] );
								anc.style.zIndex = 'auto';
							}
						} catch ( err ) {}
						anc = anc.parentElement;
					}
					f.style.position = 'fixed';
					f.style.top = '0';
					f.style.left = '0';
					f.style.width = '100vw';
					f.style.height = '100vh';
					f.style.minHeight = '0';
					f.style.zIndex = '2147483000';
					f.style.border = '0';
					f.style.background = '#000';
					document.documentElement.style.overflow = 'hidden';
				} else if ( ! want && f.__wncpayExpanded ) {
					f.__wncpayExpanded = false;
					f.setAttribute( 'style', f.__wncpaySavedStyle || '' );
					document.documentElement.style.overflow = f.__wncpaySavedScrollLock || '';
					if ( f.__wncpayZSaved ) {
						for ( var zi = 0; zi < f.__wncpayZSaved.length; zi++ ) {
							f.__wncpayZSaved[ zi ][ 0 ].style.zIndex = f.__wncpayZSaved[ zi ][ 1 ];
						}
						f.__wncpayZSaved = null;
					}
					// v0.10.7 -- the fullscreen frame left the page flow, so the
					// page collapsed and the browser clamped the scroll to the
					// shrunken bottom (the footer). Put the visitor back where
					// they were once the frame is back in the flow.
					if ( 'number' === typeof f.__wncpaySavedScrollY ) {
						window.scrollTo( 0, f.__wncpaySavedScrollY );
					}
					scheduleViewport();
				}
			};
			window.addEventListener( 'message', function ( e ) {
				if ( e.origin !== allowed ) {
					return;
				}
				var d = e.data;
				if ( ! d || ( 'wncpay:modal' !== d.type && 'wncpay:page' !== d.type && 'wncpay:scrolltop' !== d.type && 'wncpay:scrollto' !== d.type ) ) {
					return;
				}
				var frames = document.querySelectorAll( 'iframe.wncpay-embed' );
				for ( var i = 0; i < frames.length; i++ ) {
					var f = frames[ i ];
					if ( f.contentWindow !== e.source ) {
						continue;
					}
					// v0.10.1 -- after an in-frame page change (e.g. the short
					// thank-you page after paying), glide the page so the frame's
					// top is back in view instead of stranding the visitor in
					// empty space. Full-screen frames need no alignment.
					// v0.11.5 -- scroll the PAGE to a position INSIDE the frame
					// (in-page anchors like the tour hero's "Request a quote"):
					// a flow/auto frame can't scroll itself, so the embed sends
					// the target's offset and the page glides there. Window-mode
					// frames scroll internally -- ignore unless flowing.
					if ( 'wncpay:scrollto' === d.type ) {
						if ( ! f.__wncpayExpanded && ( 'window' !== f.getAttribute( 'data-wncpay-mode' ) || f.__wncpayFlow ) ) {
							var offA = menuOffset();
							var rcA = f.getBoundingClientRect();
							var yA = window.pageYOffset + rcA.top + ( parseInt( d.top, 10 ) || 0 ) - offA - 8;
							window.scrollTo( { top: Math.max( 0, yA ), behavior: 'smooth' } );
						}
						break;
					}
					if ( 'wncpay:scrolltop' === d.type ) {
						if ( ! f.__wncpayExpanded ) {
							// v0.10.6 -- INSTANT jump, re-asserted for a few
							// frames: the frame's height collapses right after
							// an in-frame navigation (shorter page), the browser
							// clamps the scroll to the new page bottom, and that
							// reflow cancelled the old smooth glide -- visitors
							// landed at the site footer instead of the page top.
							var alignTop = function () {
								var off = menuOffset();
								var rc = f.getBoundingClientRect();
								if ( rc.top < off - 4 || rc.top > window.innerHeight * 0.6 ) {
									window.scrollTo( 0, window.pageYOffset + rc.top - off );
								}
							};
							alignTop();
							// v0.11.1 -- the new page's height can arrive later
							// than a few frames (React render + resize message),
							// and the clamp then knocked the visitor off the top
							// again. Keep re-asserting for ~700ms -- but stop the
							// moment the visitor scrolls on their own.
							var atLive = true;
							var atStop = function () {
								atLive = false;
								window.removeEventListener( 'wheel', atStop );
								window.removeEventListener( 'touchstart', atStop );
							};
							window.addEventListener( 'wheel', atStop, { passive: true } );
							window.addEventListener( 'touchstart', atStop, { passive: true } );
							var atN = 0;
							var atTick = function () {
								if ( ! atLive ) {
									return;
								}
								alignTop();
								if ( ++atN < 4 ) {
									window.requestAnimationFrame( atTick );
								}
							};
							window.requestAnimationFrame( atTick );
							var atDelays = [ 150, 350, 700 ];
							for ( var ad = 0; ad < atDelays.length; ad++ ) {
								window.setTimeout( function () {
									if ( atLive ) {
										alignTop();
									}
								}, atDelays[ ad ] );
							}
							window.setTimeout( atStop, 800 );
						}
						break;
					}
					if ( 'wncpay:modal' === d.type ) {
						f.__wncpayModal = !! d.open;
					} else {
						// v0.8.0 -- dedicated single-page embeds opt out of
						// page-level expansion ([wncpay_tour] etc.).
						if ( f.hasAttribute( 'data-wncpay-noexpand' ) ) {
							return;
						}
						f.__wncpayPage = !! d.expand;
						// v0.10.3 -- FLOW mode (tour pages): frame grows to its
						// content height inside the page instead of covering
						// the screen; leaving the tour restores window mode.
						f.__wncpayFlow = !! d.flow;
					}
					applyExpand( f );
					break;
				}
			} );
			sendViewport();
			window.setTimeout( sendViewport, 1500 );

			// v0.11.0 -- the site's own cart icon drives the platform quote
			// cart: clicking it opens our cart drawer inside the embed (or
			// sends the visitor to the order page when no frame is on this
			// page), and the badge count mirrors the quote cart. Runs only
			// when enabled in Settings -> WNC Pay -> Cart icon.
			if ( cartCapture ) {
				document.addEventListener( 'click', function ( e ) {
					var t = e.target && e.target.closest ? e.target.closest( cartSel ) : null;
					if ( ! t ) {
						return;
					}
					e.preventDefault();
					e.stopPropagation();
					var frames = document.querySelectorAll( 'iframe.wncpay-embed' );
					for ( var i = 0; i < frames.length; i++ ) {
						if ( frames[ i ].contentWindow ) {
							try {
								frames[ i ].contentWindow.postMessage( { type: 'wncpay:opencart' }, allowed );
								return;
							} catch ( err ) {
								// failover card frame -- try the next one.
							}
						}
					}
					if ( cartFallback ) {
						window.location.href = cartFallback;
					}
				}, true );
				// v0.11.6 -- paint + remember: the count only ever CHANGES inside
				// an embed, so the last reported value stays correct on pages
				// with no frame (the home page showed an empty badge).
				var paintCartCount = function ( n ) {
					// Elementor menu-cart badge (data-counter renders via CSS),
					// v0.11.1 -- including the visible qty span, which is what
					// actually displays the number in current Elementor.
					var badges = document.querySelectorAll( '.elementor-menu-cart__toggle_button .elementor-button-icon, .elementor-menu-cart__toggle .elementor-button-icon' );
					for ( var b = 0; b < badges.length; b++ ) {
						badges[ b ].setAttribute( 'data-counter', String( n ) );
					}
					var qtys = document.querySelectorAll( '.elementor-menu-cart__toggle_button .elementor-button-icon-qty, .elementor-menu-cart__toggle .elementor-button-icon-qty' );
					for ( var q = 0; q < qtys.length; q++ ) {
						qtys[ q ].setAttribute( 'data-counter', String( n ) );
						qtys[ q ].textContent = String( n );
					}
					// v0.11.1 -- hide the WooCommerce subtotal next to the icon:
					// the quote cart has no prices, a permanent 0.00 reads broken.
					var subs = document.querySelectorAll( '.elementor-menu-cart__toggle_button .elementor-button-text' );
					for ( var s2 = 0; s2 < subs.length; s2++ ) {
						subs[ s2 ].style.display = 'none';
					}
					// Classic WooCommerce cart-contents count.
					var counts = document.querySelectorAll( 'a.cart-contents .count' );
					for ( var c2 = 0; c2 < counts.length; c2++ ) {
						counts[ c2 ].textContent = String( n );
					}
					// v0.11.7 -- our own injected cart icon (headers with no cart widget).
					var own = document.querySelectorAll( '.wncpay-cart-icon .wncpay-cart-badge' );
					for ( var o = 0; o < own.length; o++ ) {
						own[ o ].textContent = String( n );
						own[ o ].style.display = n > 0 ? 'block' : 'none';
					}
				};
				// v0.11.7 -- Hebrew/RTL header templates ship WITHOUT a cart
				// widget, so capture had nothing to hook and the cart was
				// unreachable. When nothing on the page matches the cart
				// selector, inject our own icon beside the wncpay login icon
				// (same header spot as the English site's cart).
				var ensureCartIcon = function () {
					if ( document.querySelector( '.wncpay-cart-icon' ) ) {
						return;
					}
					try {
						if ( document.querySelector( cartSel ) ) {
							return;
						}
					} catch ( err ) {
						return;
					}
					var host = document.querySelector( '.wncpay-login-icon' );
					if ( ! host ) {
						var links = document.querySelectorAll( 'header a, .elementor-location-header a' );
						for ( var li = 0; li < links.length; li++ ) {
							var href = links[ li ].getAttribute( 'href' ) || '';
							if ( href.indexOf( '/gift' ) !== -1 ) {
								host = links[ li ].closest( '.elementor-widget' ) || links[ li ];
								break;
							}
						}
					}
					if ( ! host ) {
						return;
					}
					var a = document.createElement( 'a' );
					a.className = 'wncpay-cart-icon';
					a.href = cartFallback || '#';
					a.setAttribute( 'aria-label', 'Cart' );
					a.title = 'Cart';
					a.style.cssText = 'position:relative;display:inline-flex;align-items:center;justify-content:center;margin-inline-start:10px;opacity:.9;flex:0 0 auto;';
					a.style.setProperty( 'color', '#fff', 'important' );
					a.onmouseover = function () { a.style.opacity = '1'; };
					a.onmouseout = function () { a.style.opacity = '.9'; };
					a.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#fff" style="stroke:#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1.6"/><circle cx="19" cy="21" r="1.6"/><path d="M2.5 3h2l2.6 12.5a2 2 0 0 0 2 1.5h9.2a2 2 0 0 0 2-1.6L22 8H6"/></svg><span class="wncpay-cart-badge" style="position:absolute;top:-6px;inset-inline-end:-8px;min-width:16px;height:16px;border-radius:8px;background:#f5a623;color:#111;font:700 10px/16px -apple-system,sans-serif;text-align:center;padding:0 3px;display:none"></span>';
					a.addEventListener( 'click', function ( e ) {
						e.preventDefault();
						var frames2 = document.querySelectorAll( 'iframe.wncpay-embed' );
						for ( var f2 = 0; f2 < frames2.length; f2++ ) {
							if ( frames2[ f2 ].contentWindow ) {
								try {
									frames2[ f2 ].contentWindow.postMessage( { type: 'wncpay:opencart' }, allowed );
									return;
								} catch ( err ) {}
							}
						}
						if ( cartFallback ) {
							window.location.href = cartFallback;
						}
					} );
					// Cart sits BEFORE the account icon, matching the English header's order.
					host.insertAdjacentElement( 'beforebegin', a );
				};
				window.addEventListener( 'message', function ( e ) {
					if ( e.origin !== allowed ) {
						return;
					}
					var d = e.data;
					if ( ! d || 'wncpay:cartcount' !== d.type ) {
						return;
					}
					var n = parseInt( d.count, 10 );
					if ( isNaN( n ) || n < 0 ) {
						return;
					}
					paintCartCount( n );
					try { window.localStorage.setItem( 'wncpay_cart_count', String( n ) ); } catch ( err ) {}
				} );
				// Frameless pages: paint the remembered count right away (and
				// again after load for Elementor sticky-header clones).
				var paintCached = function () {
					ensureCartIcon();
					try {
						var c = parseInt( window.localStorage.getItem( 'wncpay_cart_count' ) || '', 10 );
						if ( ! isNaN( c ) && c >= 0 ) {
							paintCartCount( c );
						}
					} catch ( err ) {}
				};
				if ( 'loading' === document.readyState ) {
					document.addEventListener( 'DOMContentLoaded', paintCached );
				} else {
					paintCached();
				}
				window.setTimeout( paintCached, 1500 );
				// The login icon lands ~1.2s after load (sticky-header clones):
				// one more pass so the injected cart finds its neighbour.
				window.setTimeout( paintCached, 2600 );
			}
		} )();
		</script>
		<?php
	}
}
