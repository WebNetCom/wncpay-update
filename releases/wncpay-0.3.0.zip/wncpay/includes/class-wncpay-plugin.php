<?php
/**
 * Main plugin bootstrap.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Plugin
 */
final class WNCPAY_Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var WNCPAY_Plugin|null
	 */
	private static ?WNCPAY_Plugin $instance = null;

	/**
	 * Get the singleton instance.
	 *
	 * @return WNCPAY_Plugin
	 */
	public static function instance(): WNCPAY_Plugin {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * WNCPAY_Plugin constructor.
	 */
	private function __construct() {
		add_action( 'init', [ $this, 'load_textdomain' ] );

		new WNCPAY_Settings();
		new WNCPAY_Shortcodes();
		new WNCPAY_Blocks();
		new WNCPAY_Elementor();

		add_action( 'wp_footer', [ 'WNCPAY_Embed', 'print_resize_script' ], 5 );
	}

	/**
	 * Load translations.
	 *
	 * @return void
	 */
	public function load_textdomain(): void {
		load_plugin_textdomain( 'wncpay', false, dirname( plugin_basename( WNCPAY_FILE ) ) . '/languages' );
	}
}
