<?php
/**
 * Admin settings page.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Settings
 */
final class WNCPAY_Settings {

	/**
	 * Option name.
	 *
	 * @var string
	 */
	public const OPTION = 'wncpay_options';

	/**
	 * WNCPAY_Settings constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', [ $this, 'register_page' ] );
		add_action( 'admin_init', [ $this, 'register_settings' ] );
		add_filter( 'plugin_action_links_' . plugin_basename( WNCPAY_FILE ), [ $this, 'action_links' ] );
	}

	/**
	 * Add "Settings" link on the plugins screen.
	 *
	 * @param array $links Existing action links.
	 *
	 * @return array
	 */
	public function action_links( array $links ): array {
		$url = admin_url( 'options-general.php?page=wncpay' );

		array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'wncpay' ) . '</a>' );

		return $links;
	}

	/**
	 * Register the options page.
	 *
	 * @return void
	 */
	public function register_page(): void {
		add_options_page(
			__( 'WNC Pay', 'wncpay' ),
			__( 'WNC Pay', 'wncpay' ),
			'manage_options',
			'wncpay',
			[ $this, 'render_page' ]
		);
	}

	/**
	 * Register settings, section and fields.
	 *
	 * @return void
	 */
	public function register_settings(): void {
		register_setting(
			'wncpay',
			self::OPTION,
			[
				'type'              => 'array',
				'sanitize_callback' => [ $this, 'sanitize' ],
				'default'           => [],
			]
		);

		add_settings_section(
			'wncpay_connection',
			__( 'Platform Connection', 'wncpay' ),
			[ $this, 'render_section_intro' ],
			'wncpay'
		);

		add_settings_field(
			'platform_url',
			__( 'Platform URL', 'wncpay' ),
			[ $this, 'render_platform_url_field' ],
			'wncpay',
			'wncpay_connection'
		);

		add_settings_field(
			'site_key',
			__( 'Site Key', 'wncpay' ),
			[ $this, 'render_site_key_field' ],
			'wncpay',
			'wncpay_connection'
		);
	}

	/**
	 * Sanitize submitted options.
	 *
	 * @param mixed $input Raw input.
	 *
	 * @return array
	 */
	public function sanitize( $input ): array {
		$input = is_array( $input ) ? $input : [];

		$output = [
			'platform_url' => '',
			'site_key'     => '',
		];

		if ( ! empty( $input['platform_url'] ) ) {
			$url = esc_url_raw( trim( (string) $input['platform_url'] ) );

			if ( '' !== $url && ! in_array( wp_parse_url( $url, PHP_URL_SCHEME ), [ 'http', 'https' ], true ) ) {
				$url = '';
			}

			$output['platform_url'] = untrailingslashit( $url );
		}

		if ( ! empty( $input['site_key'] ) ) {
			$output['site_key'] = sanitize_text_field( (string) $input['site_key'] );
		}

		return $output;
	}

	/**
	 * Section intro text.
	 *
	 * @return void
	 */
	public function render_section_intro(): void {
		echo '<p>' . esc_html__( 'Connect this site to your platform. The Platform URL is where embedded elements are loaded from; the Site Key identifies this site for authenticated platform features (it is never exposed in embed URLs).', 'wncpay' ) . '</p>';
	}

	/**
	 * Platform URL field.
	 *
	 * @return void
	 */
	public function render_platform_url_field(): void {
		printf(
			'<input type="url" class="regular-text code" name="%s[platform_url]" value="%s" placeholder="https://app.example.com" />',
			esc_attr( self::OPTION ),
			esc_attr( WNCPAY_Embed::get_option( 'platform_url' ) )
		);
	}

	/**
	 * Site key field.
	 *
	 * @return void
	 */
	public function render_site_key_field(): void {
		printf(
			'<input type="text" class="regular-text code" name="%s[site_key]" value="%s" autocomplete="off" />',
			esc_attr( self::OPTION ),
			esc_attr( WNCPAY_Embed::get_option( 'site_key' ) )
		);
	}

	/**
	 * Render the settings page.
	 *
	 * @return void
	 */
	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'WNC Pay', 'wncpay' ); ?></h1>

			<form action="options.php" method="post">
				<?php
				settings_fields( 'wncpay' );
				do_settings_sections( 'wncpay' );
				submit_button();
				?>
			</form>

			<hr />

			<h2><?php esc_html_e( 'Usage', 'wncpay' ); ?></h2>
			<p><?php esc_html_e( 'Each element is available three ways — use whichever fits your workflow:', 'wncpay' ); ?></p>
			<ul style="list-style:disc;padding-left:20px;">
				<li><strong><?php esc_html_e( 'Elementor', 'wncpay' ); ?></strong> — <?php esc_html_e( 'look for the "WNC Pay" widget category.', 'wncpay' ); ?></li>
				<li><strong><?php esc_html_e( 'Shortcode', 'wncpay' ); ?></strong> — <code>[wncpay_gift_designer amount="750"]</code> <?php esc_html_e( 'or the generic', 'wncpay' ); ?> <code>[wncpay_embed path="/gift" amount="750"]</code></li>
				<li><strong><?php esc_html_e( 'Block', 'wncpay' ); ?></strong> — <?php esc_html_e( 'search for "WNC Pay" in the block inserter.', 'wncpay' ); ?></li>
			</ul>
			<p><?php esc_html_e( 'Embedded elements resize automatically. If you use a JavaScript delay/optimization feature (e.g. WP Rocket "Delay JavaScript execution"), add "wncpay" to its exclusion list.', 'wncpay' ); ?></p>
		</div>
		<?php
	}
}
