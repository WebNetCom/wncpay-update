=== WNC Pay ===
Contributors: webnetcom
Tags: embed, gift cards, elementor, shortcode, block
Requires at least: 6.0
Tested up to: 7.0
Stable tag: 0.2.0
Requires PHP: 8.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Embed elements from your connected platform — gift card designer and more — via shortcode, Elementor widget, or block.

== Description ==

WNC Pay connects a WordPress site to an operator platform and lets the site builder place platform elements anywhere on the site. Each element is available three ways, so you can use whatever fits your workflow:

* **Elementor widgets** — a native "WNC Pay" category.
* **Shortcodes** — e.g. `[wncpay_gift_designer amount="750"]`, or the generic `[wncpay_embed path="/gift"]`.
* **Blocks** — search for "WNC Pay" in the block inserter.

Elements render as secure embeds of the platform with automatic height, and follow the site language (WPML-aware). The plugin's job ends at rendering the embed: styling and placement belong to the site developer; the content and flows inside the frame belong to the platform. No payment data, checkout flow, or personal information is processed or stored by this plugin or by WordPress.

= Elements =

* Gift Card Designer (first release)
* More elements (balance checker, catalog, pay-by-link, quote request) planned.

== External Services ==

This plugin embeds pages served from the platform URL configured by the site administrator under Settings → WNC Pay. When a visitor views a page containing a WNC Pay element, the visitor's browser loads that element directly from the configured platform, which will receive the visitor's IP address and user agent as with any embedded content. All checkout and payment flows run entirely on the connected platform and are subject to the platform operator's terms of service and privacy policy. No data is sent to the platform by the plugin itself.

The plugin also periodically contacts github.com (the public wncpay-update repository) to check for new plugin versions; only standard HTTP request metadata is transmitted. This mechanism is removed when the plugin is distributed through wordpress.org.

== Installation ==

1. Upload and activate the plugin.
2. Go to Settings → WNC Pay and enter the Platform URL and Site Key provided by your platform operator.
3. Place an element via an Elementor widget, shortcode, or block.

= Performance / caching note =

Embeds are page-cache safe. If your site delays JavaScript execution (e.g. WP Rocket's "Delay JavaScript execution"), add `wncpay` to the exclusion list so embeds resize immediately.

== Changelog ==

= 0.2.0 =
* Native WordPress updates via the public wncpay-update release channel (Plugin Update Checker).

= 0.1.0 =
* First release: settings page, embed core with auto-height and WPML-aware locale, Gift Card Designer as Elementor widget + shortcode + block.
