=== WNC Pay ===
Contributors: webnetcom
Tags: embed, gift cards, elementor, shortcode, block
Requires at least: 6.0
Tested up to: 7.0
Stable tag: 0.3.4
Requires PHP: 8.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Embed elements from your connected platform — gift card designer and more — via shortcode, Elementor widget, or block.

== Description ==

WNC Pay connects a WordPress site to an operator platform and lets the site builder place platform elements anywhere on the site. Each element is available three ways, so you can use whatever fits your workflow:

* **Elementor widgets** — a native "WNC Pay" category.
* **Shortcodes** — e.g. `[wncpay_gift_designer amount="750"]`, or the generic `[wncpay_embed path="/gift"]`.
* **Blocks** — search for "WNC Pay" in the block inserter.

Elements render as secure embeds of the platform with automatic height, and follow the site language (WPML-aware). The plugin's job ends at rendering the embed: styling and placement belong to the site developer; the content and flows inside the frame belong to the platform. No payment data, checkout flow, or personal information is processed or stored by this plugin or by WordPress.

= Elements =

* Gift Card Designer (first release)
* More elements (balance checker, catalog, pay-by-link, quote request) planned.

== External Services ==

This plugin embeds pages served from the platform URL configured by the site administrator under Settings → WNC Pay. When a visitor views a page containing a WNC Pay element, the visitor's browser loads that element directly from the configured platform, which will receive the visitor's IP address and user agent as with any embedded content. All checkout and payment flows run entirely on the connected platform and are subject to the platform operator's terms of service and privacy policy. No data is sent to the platform by the plugin itself.

The plugin also periodically contacts github.com (the public wncpay-update repository) to check for new plugin versions; only standard HTTP request metadata is transmitted. This mechanism is removed when the plugin is distributed through wordpress.org.

When the WNC Pay payment gateway is enabled, checkout sends the order summary and the customer's billing name, email and phone to the configured platform over an authenticated server-to-server call, so the platform can process the payment and issue documents. No card data ever touches WordPress. Payment confirmations arrive as cryptographically signed webhooks from the platform.

== Installation ==

1. Upload and activate the plugin.
2. Go to Settings → WNC Pay and enter the Platform URL and Site Key provided by your platform operator.
3. Place an element via an Elementor widget, shortcode, or block.

= Performance / caching note =

Embeds are page-cache safe. If your site delays JavaScript execution (e.g. WP Rocket's "Delay JavaScript execution"), add `wncpay` to the exclusion list so embeds resize immediately.

== Changelog ==

= 0.3.4 =
* Multi-item carts use the platform's multiple-tours document variant (docType cfc_multiple).

= 0.3.3 =
* After a WNC Pay payment, the order-received page and the customer's order emails link to their platform account (locale-aware; filter: wncpay_account_url).

= 0.3.2 =
* Brand logo: checkout icon for the WNC Pay gateway, Settings page header, and plugin icons on the WordPress update screens.

= 0.3.1 =
* Rebuild: the 0.3.0 package was built from the pre-release commit and shipped 0.2.0 code. Identical feature set to 0.3.0.

= 0.3.0 =
* WooCommerce payment gateway: "WNC Pay" appears under WooCommerce → Settings → Payments. Checkout redirects to the platform's secure payment page and returns; orders are completed by a signed platform webhook (HMAC, replay-protected, late failures never overwrite a paid order). ILS carts only. HPOS compatible.
* Connection status indicator on Settings → WNC Pay (live authorize check against the platform).

= 0.2.0 =
* Native WordPress updates via the public wncpay-update release channel (Plugin Update Checker).

= 0.1.0 =
* First release: settings page, embed core with auto-height and WPML-aware locale, Gift Card Designer as Elementor widget + shortcode + block.
