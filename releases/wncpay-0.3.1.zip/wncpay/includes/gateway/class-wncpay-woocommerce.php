<?php
/**
 * WooCommerce integration bootstrap: registers the gateway + webhook only when
 * WooCommerce is active, declares HPOS compatibility.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_WooCommerce
 */
final class WNCPAY_WooCommerce {

	/**
	 * WNCPAY_WooCommerce constructor.
	 */
	public function __construct() {
		add_action( 'plugins_loaded', [ $this, 'maybe_boot' ], 20 );
		add_action( 'before_woocommerce_init', [ $this, 'declare_compatibility' ] );
	}

	/**
	 * Load the gateway pieces when WooCommerce is present.
	 *
	 * @return void
	 */
	public function maybe_boot(): void {
		if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
			return;
		}

		require_once WNCPAY_PATH . 'includes/gateway/class-wncpay-gateway.php';
		require_once WNCPAY_PATH . 'includes/gateway/class-wncpay-gateway-webhook.php';

		new WNCPAY_Gateway_Webhook();

		add_filter( 'woocommerce_payment_gateways', [ $this, 'register_gateway' ] );
	}

	/**
	 * Add the gateway to WooCommerce's list.
	 *
	 * @param array $gateways Registered gateway classes.
	 *
	 * @return array
	 */
	public function register_gateway( array $gateways ): array {
		$gateways[] = WNCPAY_Gateway::class;

		return $gateways;
	}

	/**
	 * HPOS (custom order tables) compatibility.
	 *
	 * @return void
	 */
	public function declare_compatibility(): void {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', WNCPAY_FILE, true );
		}
	}
}
