<?php
/**
 * Link previews + item deep links — v0.15.0.
 *
 * 1. Item links. A site page holding a WNC Pay catalog / group-tours element can be
 *    opened with ?ie=<key> (g-<departure id> = a group tour, t-<tour id> = a tour).
 *    The element then loads straight at that item. The platform's share button,
 *    when it runs inside this site, shares exactly these links (shortened to
 *    ie-l.ink), so a shared tour opens HERE, on the site, with the tour shown.
 *
 * 2. Link previews. When a page shows a group tour, the group-tours list, a single
 *    tour, or an ?ie= item, the page's WhatsApp / Facebook preview (og: + twitter:
 *    tags) is taken from the platform page of that item — its real title, photo
 *    and description — instead of the bare page title and no image. Works with
 *    any SEO plugin: the head is adjusted just before the page is sent. Previews
 *    are cached for 30 minutes. Turn off with:
 *    add_filter( 'wncpay_link_preview', '__return_false' );
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Link_Preview
 */
final class WNCPAY_Link_Preview {

	/**
	 * Platform path whose preview this page should carry (null = leave the head alone).
	 *
	 * @var string|null
	 */
	private static ?string $path = null;

	/**
	 * True once the ?ie= item was placed into an element on this page.
	 *
	 * @var bool
	 */
	private static bool $item_used = false;

	/**
	 * WNCPAY_Link_Preview constructor.
	 */
	public function __construct() {
		add_action( 'template_redirect', [ $this, 'start' ], 0 );
	}

	/**
	 * The validated ?ie= key of this request, or ''.
	 *
	 * @return string
	 */
	public static function item_key(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- public, read-only.
		$v = isset( $_GET['ie'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['ie'] ) ) : '';

		return preg_match( '/^[gt]-[A-Za-z0-9_-]{4,64}$/', $v ) ? $v : '';
	}

	/**
	 * Platform path of the ?ie= item, or ''.
	 *
	 * @return string
	 */
	public static function item_path(): string {
		$k = self::item_key();
		if ( '' === $k ) {
			return '';
		}

		return ( 'g' === $k[0] ? '/group/' : '/tours/' ) . substr( $k, 2 );
	}

	/**
	 * Called by WNCPAY_Embed::render() for every element: may swap the element's
	 * path for the ?ie= item (catalog / group-tours / single-item elements only,
	 * once per page) and records which path the page preview should use.
	 *
	 * @param string $path Requested platform path.
	 *
	 * @return string The path to embed.
	 */
	public static function route( string $path ): string {
		$item = self::item_path();
		$kind = '/' . trim( $path, '/' );
		$swappable = (bool) preg_match( '#^/(tours|group-tours|group/[^/]+|tours/[^/]+)$#', $kind );

		if ( '' !== $item && $swappable && ! self::$item_used ) {
			self::$item_used = true;
			self::$path      = $item;

			return $item;
		}

		// No item link: preview pages that show ONE thing, or the group-tours list.
		// (The general catalog / gift designer / home page keep the site's own preview.)
		if ( null === self::$path && preg_match( '#^/(group-tours|group/[^/]+|tours/[^/]+)$#', $kind ) ) {
			self::$path = $kind;
		}

		return $path;
	}

	/**
	 * This page's address without its query string — handed to the frames as ?host=
	 * so the platform can build share links that point back here.
	 *
	 * @return string
	 */
	public static function host_url(): string {
		$id = get_queried_object_id();
		if ( $id && is_singular() ) {
			$link = get_permalink( $id );
			if ( is_string( $link ) && '' !== $link ) {
				return $link;
			}
		}
		$req = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';

		return home_url( (string) wp_parse_url( $req, PHP_URL_PATH ) );
	}

	/**
	 * Begin buffering the front-end page so the head can be adjusted at the end.
	 *
	 * @return void
	 */
	public function start(): void {
		if ( is_admin() || wp_doing_ajax() || is_feed() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}
		if ( ! apply_filters( 'wncpay_link_preview', true ) || '' === WNCPAY_Embed::platform_url() ) {
			return;
		}
		ob_start( [ $this, 'filter_html' ] );
	}

	/**
	 * Output-buffer callback: replace the page's og:/twitter: preview tags.
	 *
	 * @param string $html Page HTML.
	 *
	 * @return string
	 */
	public function filter_html( $html ) {
		if ( ! is_string( $html ) || null === self::$path || false === stripos( $html, '</head>' ) ) {
			return $html;
		}
		try {
			$og = self::fetch( self::$path );
			if ( ! $og ) {
				return $html;
			}

			$tags = [ 'og:title', 'og:description', 'og:image', 'og:image:width', 'og:image:height', 'og:image:alt', 'og:image:type', 'og:image:secure_url', 'twitter:title', 'twitter:description', 'twitter:image', 'twitter:card' ];
			if ( '' !== self::item_key() ) {
				$tags[] = 'og:url';
			}
			$quoted = implode( '|', array_map( static fn( $t ) => preg_quote( $t, '#' ), $tags ) );
			$html   = (string) preg_replace( '#<meta\s[^>]*(?:property|name)\s*=\s*["\'](?:' . $quoted . ')["\'][^>]*>\s*#i', '', $html );

			$out   = [];
			$out[] = '<!-- WNC Pay link preview -->';
			$out[] = sprintf( '<meta property="og:title" content="%s" />', esc_attr( $og['title'] ) );
			if ( '' !== $og['description'] ) {
				$out[] = sprintf( '<meta property="og:description" content="%s" />', esc_attr( $og['description'] ) );
			}
			if ( '' !== $og['image'] ) {
				$out[] = sprintf( '<meta property="og:image" content="%s" />', self::attr_url( $og['image'] ) );
				$out[] = '<meta property="og:image:width" content="1200" />';
				$out[] = '<meta property="og:image:height" content="630" />';
				$out[] = '<meta property="og:image:type" content="image/jpeg" />';
			}
			if ( '' !== self::item_key() ) {
				$out[] = sprintf( '<meta property="og:url" content="%s" />', self::attr_url( add_query_arg( 'ie', self::item_key(), self::host_url() ) ) );
			}
			$out[] = '<meta name="twitter:card" content="summary_large_image" />';
			$out[] = sprintf( '<meta name="twitter:title" content="%s" />', esc_attr( $og['title'] ) );
			if ( '' !== $og['description'] ) {
				$out[] = sprintf( '<meta name="twitter:description" content="%s" />', esc_attr( $og['description'] ) );
			}
			if ( '' !== $og['image'] ) {
				$out[] = sprintf( '<meta name="twitter:image" content="%s" />', self::attr_url( $og['image'] ) );
			}

			$pos = stripos( $html, '</head>' );

			return substr( $html, 0, $pos ) . implode( "\n", $out ) . "\n" . substr( $html, $pos );
		} catch ( \Throwable $e ) {
			return $html; // never break the page over a preview
		}
	}

	/**
	 * A URL for a meta content="" attribute with its & written as &amp; (v0.15.1). esc_url()
	 * writes &#038;, which WhatsApp does not decode: it cut the image address at the "#",
	 * fetched the full-size photo instead of the small preview one, and dropped it as too big.
	 *
	 * @param string $url URL.
	 *
	 * @return string
	 */
	private static function attr_url( string $url ): string {
		$url = esc_url_raw( $url, [ 'https', 'http' ] );

		return esc_attr( $url );
	}

	/**
	 * The platform page's preview (title / description / image), cached 30 minutes.
	 *
	 * @param string $path Platform path.
	 *
	 * @return array{title:string,description:string,image:string}|null
	 */
	public static function fetch( string $path ): ?array {
		$lang = WNCPAY_Embed::locale();
		$key  = 'wncpay_og_' . md5( $path . '|' . $lang );
		$hit  = get_transient( $key );
		if ( is_array( $hit ) ) {
			return ! empty( $hit['title'] ) ? $hit : null;
		}

		$url = add_query_arg( 'lang', 'he' === $lang ? 'he' : 'en', WNCPAY_Embed::platform_url() . $path );
		$res = wp_remote_get(
			$url,
			[
				'timeout'    => 4,
				'user-agent' => 'WNCPay-LinkPreview/' . ( defined( 'WNCPAY_VERSION' ) ? WNCPAY_VERSION : '0' ) . ' (+' . home_url() . ')',
			]
		);
		$body = is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ? '' : (string) wp_remote_retrieve_body( $res );

		$get = static function ( string $prop ) use ( $body ): string {
			if ( '' === $body ) {
				return '';
			}
			if ( preg_match( '#<meta\s[^>]*property=["\']' . preg_quote( $prop, '#' ) . '["\'][^>]*content=["\']([^"\']*)["\']#i', $body, $m )
				|| preg_match( '#<meta\s[^>]*content=["\']([^"\']*)["\'][^>]*property=["\']' . preg_quote( $prop, '#' ) . '["\']#i', $body, $m ) ) {
				return trim( html_entity_decode( $m[1], ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
			}

			return '';
		};

		$og = [
			'title'       => $get( 'og:title' ),
			'description' => $get( 'og:description' ),
			'image'       => $get( 'og:image' ),
		];
		// Never a preview from a page that failed or has no title; retry in 5 minutes.
		set_transient( $key, $og, '' !== $og['title'] ? 30 * MINUTE_IN_SECONDS : 5 * MINUTE_IN_SECONDS );

		return '' !== $og['title'] ? $og : null;
	}
}
