<?php
/**
 * Admin settings page.
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WNCPAY_Settings
 */
final class WNCPAY_Settings {

	/**
	 * Option name.
	 *
	 * @var string
	 */
	public const OPTION = 'wncpay_options';

	/**
	 * WNCPAY_Settings constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', [ $this, 'register_page' ] );
		add_action( 'admin_init', [ $this, 'register_settings' ] );
		add_filter( 'plugin_action_links_' . plugin_basename( WNCPAY_FILE ), [ $this, 'action_links' ] );
	}

	/**
	 * Add "Settings" link on the plugins screen.
	 *
	 * @param array $links Existing action links.
	 *
	 * @return array
	 */
	public function action_links( array $links ): array {
		$url = admin_url( 'options-general.php?page=wncpay' );

		array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'wncpay' ) . '</a>' );

		return $links;
	}

	/**
	 * Register the options page.
	 *
	 * @return void
	 */
	public function register_page(): void {
		add_options_page(
			__( 'WNC Pay', 'wncpay' ),
			__( 'WNC Pay', 'wncpay' ),
			'manage_options',
			'wncpay',
			[ $this, 'render_page' ]
		);
	}

	/**
	 * Register settings, section and fields.
	 *
	 * @return void
	 */
	public function register_settings(): void {
		register_setting(
			'wncpay',
			self::OPTION,
			[
				'type'              => 'array',
				'sanitize_callback' => [ $this, 'sanitize' ],
				'default'           => [],
			]
		);

		add_settings_section(
			'wncpay_connection',
			__( 'Platform Connection', 'wncpay' ),
			[ $this, 'render_section_intro' ],
			'wncpay'
		);

		add_settings_field(
			'platform_url',
			__( 'Platform URL', 'wncpay' ),
			[ $this, 'render_platform_url_field' ],
			'wncpay',
			'wncpay_connection'
		);

		add_settings_field(
			'site_key',
			__( 'Site Key', 'wncpay' ),
			[ $this, 'render_site_key_field' ],
			'wncpay',
			'wncpay_connection'
		);

		// v0.9.0 -- floating "Gift this adventure" button on tour pages.
		add_settings_section(
			'wncpay_gift_button',
			__( 'Gift button', 'wncpay' ),
			[ $this, 'render_gift_section_intro' ],
			'wncpay'
		);

		add_settings_field(
			'gift_button',
			__( 'Floating gift button', 'wncpay' ),
			[ $this, 'render_gift_button_field' ],
			'wncpay',
			'wncpay_gift_button'
		);

		add_settings_field(
			'gift_button_page',
			__( 'Gift page URL', 'wncpay' ),
			[ $this, 'render_gift_button_page_field' ],
			'wncpay',
			'wncpay_gift_button'
		);

		add_settings_field(
			'gift_button_prefix',
			__( 'Show on paths starting with', 'wncpay' ),
			[ $this, 'render_gift_button_prefix_field' ],
			'wncpay',
			'wncpay_gift_button'
		);

	add_settings_field(
			'section_cta_page',
			__( 'Order page URL (tour section)', 'wncpay' ),
			[ $this, 'render_section_cta_field' ],
			'wncpay',
			'wncpay_gift_button'
		);

		// v0.11.0 -- capture the site's own cart icon for the quote cart.
		add_settings_section(
			'wncpay_cart_capture',
			__( 'Cart icon', 'wncpay' ),
			[ $this, 'render_cart_section_intro' ],
			'wncpay'
		);

		add_settings_field(
			'cart_capture',
			__( 'Capture the cart icon', 'wncpay' ),
			[ $this, 'render_cart_capture_field' ],
			'wncpay',
			'wncpay_cart_capture'
		);

		add_settings_field(
			'cart_selector',
			__( 'Cart icon CSS selector', 'wncpay' ),
			[ $this, 'render_cart_selector_field' ],
			'wncpay',
			'wncpay_cart_capture'
		);

		// v0.11.2 -- header login icon.
		add_settings_field(
			'login_icon',
			__( 'Header login icon', 'wncpay' ),
			[ $this, 'render_login_icon_field' ],
			'wncpay',
			'wncpay_cart_capture'
		);

		add_settings_field(
			'login_icon_after',
			__( 'Place login icon after (CSS selector)', 'wncpay' ),
			[ $this, 'render_login_icon_after_field' ],
			'wncpay',
			'wncpay_cart_capture'
		);
	}

	/**
	 * Sanitize submitted options.
	 *
	 * @param mixed $input Raw input.
	 *
	 * @return array
	 */
	public function sanitize( $input ): array {
		$input = is_array( $input ) ? $input : [];

		$output = [
			'platform_url'       => '',
			'site_key'           => '',
			'gift_button'        => '',
			'gift_button_page'   => '',
			'gift_button_prefix' => '',
			'section_cta_page'   => '',
			'cart_capture'       => '',
			'cart_selector'      => '',
			'login_icon'         => '',
			'login_icon_url'     => '',
			'login_icon_after'   => '',
		];

		if ( ! empty( $input['platform_url'] ) ) {
			$url = esc_url_raw( trim( (string) $input['platform_url'] ) );

			if ( '' !== $url && ! in_array( wp_parse_url( $url, PHP_URL_SCHEME ), [ 'http', 'https' ], true ) ) {
				$url = '';
			}

			$output['platform_url'] = untrailingslashit( $url );
		}

		if ( ! empty( $input['site_key'] ) ) {
			$output['site_key'] = sanitize_text_field( (string) $input['site_key'] );
		}

		// v0.9.0 -- gift button options.
		if ( ! empty( $input['gift_button'] ) ) {
			$output['gift_button'] = '1';
		}
		if ( ! empty( $input['gift_button_page'] ) ) {
			$output['gift_button_page'] = esc_url_raw( trim( (string) $input['gift_button_page'] ) );
		}
		if ( ! empty( $input['gift_button_prefix'] ) ) {
			$output['gift_button_prefix'] = sanitize_text_field( (string) $input['gift_button_prefix'] );
		}
		if ( ! empty( $input['section_cta_page'] ) ) {
			$output['section_cta_page'] = esc_url_raw( trim( (string) $input['section_cta_page'] ) );
		}

		// v0.11.0 -- cart icon capture.
		if ( ! empty( $input['cart_capture'] ) ) {
			$output['cart_capture'] = '1';
		}
		if ( ! empty( $input['cart_selector'] ) ) {
			$output['cart_selector'] = sanitize_text_field( (string) $input['cart_selector'] );
		}

		// v0.11.2 -- header login icon.
		if ( ! empty( $input['login_icon'] ) ) {
			$output['login_icon'] = '1';
		}
		if ( ! empty( $input['login_icon_url'] ) ) {
			$output['login_icon_url'] = esc_url_raw( trim( (string) $input['login_icon_url'] ) );
		}
		if ( ! empty( $input['login_icon_after'] ) ) {
			$output['login_icon_after'] = sanitize_text_field( (string) $input['login_icon_after'] );
		}

		return $output;
	}

	/**
	 * Gift-button section intro.
	 *
	 * @return void
	 */
	public function render_gift_section_intro(): void {
		echo '<p>' . esc_html__( 'Float a small "🎁 Gift this adventure" tab on tour pages (left edge in English, right edge in Hebrew). It opens your gift-card page with the tour already selected on the card.', 'wncpay' ) . '</p>';
	}

	/**
	 * Gift-button enable field.
	 *
	 * @return void
	 */
	public function render_gift_button_field(): void {
		printf(
			'<label><input type="checkbox" name="%s[gift_button]" value="1" %s /> %s</label>',
			esc_attr( self::OPTION ),
			checked( '1', WNCPAY_Embed::get_option( 'gift_button' ), false ),
			esc_html__( 'Show the floating button', 'wncpay' )
		);
	}

	/**
	 * Gift page URL field.
	 *
	 * @return void
	 */
	public function render_gift_button_page_field(): void {
		printf(
			'<input type="url" class="regular-text code" name="%s[gift_button_page]" value="%s" placeholder="https://your-site.com/gift-certificates/" />'
			. '<p class="description">%s</p>',
			esc_attr( self::OPTION ),
			esc_attr( WNCPAY_Embed::get_option( 'gift_button_page' ) ),
			esc_html__( 'The page on THIS site that contains the [wncpay_gift_designer] embed.', 'wncpay' )
		);
	}

	/**
	 * Gift path-prefix field.
	 *
	 * @return void
	 */
	public function render_gift_button_prefix_field(): void {
		printf(
			'<input type="text" class="regular-text code" name="%s[gift_button_prefix]" value="%s" placeholder="/sites/" />'
			. '<p class="description">%s</p>',
			esc_attr( self::OPTION ),
			esc_attr( WNCPAY_Embed::get_option( 'gift_button_prefix' ) ),
			esc_html__( 'Comma-separated path prefixes; default /sites/ (the tour pages).', 'wncpay' )
		);
	}

	/**
	 * Order-page URL for the server-rendered tour section's CTA button.
	 *
	 * @return void
	 */
	public function render_section_cta_field(): void {
		printf(
			'<input type="url" class="regular-text code" name="%s[section_cta_page]" value="%s" placeholder="https://your-site.com/get-more-info/" />'
			. '<p class="description">%s</p>',
			esc_attr( self::OPTION ),
			esc_attr( WNCPAY_Embed::get_option( 'section_cta_page' ) ),
			esc_html__( 'Where the tour section\'s "Order this trip" button leads (e.g. your catalog/quote page). Empty = the platform tour page.', 'wncpay' )
		);
	}

	/**
	 * Section intro text.
	 *
	 * @return void
	 */
	public function render_section_intro(): void {
		echo '<p>' . esc_html__( 'Connect this site to your platform. The Platform URL is where embedded elements are loaded from; the Site Key identifies this site for authenticated platform features (it is never exposed in embed URLs).', 'wncpay' ) . '</p>';
	}

	/**
	 * Platform URL field.
	 *
	 * @return void
	 */
	public function render_platform_url_field(): void {
		printf(
			'<input type="url" class="regular-text code" name="%s[platform_url]" value="%s" placeholder="https://app.example.com" />',
			esc_attr( self::OPTION ),
			esc_attr( WNCPAY_Embed::get_option( 'platform_url' ) )
		);
	}

	/**
	 * Site key field.
	 *
	 * @return void
	 */
	public function render_site_key_field(): void {
		printf(
			'<input type="text" class="regular-text code" name="%s[site_key]" value="%s" autocomplete="off" />',
			esc_attr( self::OPTION ),
			esc_attr( WNCPAY_Embed::get_option( 'site_key' ) )
		);
	}

	/**
	 * Render the settings page.
	 *
	 * @return void
	 */
	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$status = null;
		if ( '' !== WNCPAY_Embed::platform_url() && '' !== WNCPAY_Embed::get_option( 'site_key' ) ) {
			$check  = WNCPAY_Api::post( '/api/wncpay/authorize', [ 'site' => WNCPAY_Api::site_host() ] );
			$status = is_wp_error( $check )
				? [ 'ok' => false, 'text' => $check->get_error_message() ]
				: [ 'ok' => true, 'text' => sprintf( '%s v%s', (string) ( $check['platform'] ?? 'platform' ), (string) ( $check['version'] ?? '' ) ) ];
		}

		?>
		<div class="wrap">
			<h1 style="display:flex;align-items:center;gap:12px;">
				<img src="<?php echo esc_url( WNCPAY_URL . 'assets/images/wncpay-logo.png' ); ?>" alt="" style="height:44px;width:auto;" />
				<?php esc_html_e( 'WNC Pay', 'wncpay' ); ?>
			</h1>

			<?php if ( null !== $status ) : ?>
				<div style="margin:12px 0;padding:10px 14px;border-left:4px solid <?php echo $status['ok'] ? '#46b450' : '#dc3232'; ?>;background:#fff;">
					<?php if ( $status['ok'] ) : ?>
						<strong>✓ <?php esc_html_e( 'Connected to the platform', 'wncpay' ); ?></strong> — <?php echo esc_html( $status['text'] ); ?>
					<?php else : ?>
						<strong>✗ <?php esc_html_e( 'Platform connection failed', 'wncpay' ); ?></strong> — <?php echo esc_html( $status['text'] ); ?>
						<br /><span class="description"><?php esc_html_e( 'Check the Platform URL, and that this site\'s host + Site Key are registered on the platform (WNCPAY_SITE_KEYS).', 'wncpay' ); ?></span>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<form action="options.php" method="post">
				<?php
				settings_fields( 'wncpay' );
				do_settings_sections( 'wncpay' );
				submit_button();
				?>
			</form>

			<hr />

			<?php if ( class_exists( 'WNCPAY_Group_Tours' ) ) { WNCPAY_Group_Tours::render_settings_block(); } ?>

			<hr />

			<h2><?php esc_html_e( 'Usage', 'wncpay' ); ?></h2>
			<p><?php esc_html_e( 'Each element is available three ways — use whichever fits your workflow:', 'wncpay' ); ?></p>
			<ul style="list-style:disc;padding-left:20px;">
				<li><strong><?php esc_html_e( 'Elementor', 'wncpay' ); ?></strong> — <?php esc_html_e( 'look for the "WNC Pay" widget category.', 'wncpay' ); ?></li>
				<li><strong><?php esc_html_e( 'Shortcode', 'wncpay' ); ?></strong> — <?php esc_html_e( 'see the reference below.', 'wncpay' ); ?></li>
				<li><strong><?php esc_html_e( 'Block', 'wncpay' ); ?></strong> — <?php esc_html_e( 'search for "WNC Pay" in the block inserter.', 'wncpay' ); ?></li>
			</ul>

			<h3><?php esc_html_e( 'Shortcode reference — all elements', 'wncpay' ); ?></h3>
			<table class="widefat striped" style="max-width:1000px;">
				<thead><tr><th style="width:290px;"><?php esc_html_e( 'Shortcode', 'wncpay' ); ?></th><th><?php esc_html_e( 'What it embeds', 'wncpay' ); ?></th><th style="width:330px;"><?php esc_html_e( 'Notes', 'wncpay' ); ?></th></tr></thead>
				<tbody>
					<tr><td><code>[wncpay_tour_catalog]</code></td><td><?php esc_html_e( 'The interactive tour catalog — browse, filter, pick several tours, send one quote request.', 'wncpay' ); ?></td><td><?php esc_html_e( 'Window mode by default (scrolls inside a screen-sized frame); mode="auto" for full-height. Context-aware: arriving from a tour page opens that tour or its category.', 'wncpay' ); ?></td></tr>
					<tr><td><code>[wncpay_tour id="abc123"]</code></td><td><?php esc_html_e( 'ONE tour\'s full page (photos, details, add to quote).', 'wncpay' ); ?></td><td><?php esc_html_e( 'id = the product id from the platform catalog (Dashboard → Catalog → copy id).', 'wncpay' ); ?></td></tr>
					<tr><td><code>[wncpay_group_tours]</code></td><td><?php esc_html_e( 'The Group tours page — every open scheduled departure (date, early-bird / regular price per person, seats left) with booking inside the page.', 'wncpay' ); ?></td><td><?php esc_html_e( 'No attributes needed; the "Create the Group Tours page" button above places it for you.', 'wncpay' ); ?></td></tr>
					<tr><td><code>[wncpay_group_tour id="…"]</code></td><td><?php esc_html_e( 'ONE departure\'s flyer page (date, prices, highlights, book).', 'wncpay' ); ?></td><td><?php esc_html_e( 'id = the departure id (Dashboard → Group departures → Share link, the part after /group/).', 'wncpay' ); ?></td></tr>
					<tr><td><code>[wncpay_tour_section]</code></td><td><?php esc_html_e( 'A tour\'s content as REAL synced HTML in the page (no iframe) — hero, description, packages, Order + Gift buttons; or a category grid.', 'wncpay' ); ?></td><td><?php esc_html_e( 'Auto-detects from the page\'s linked WNC Tour / URL / category; product="…" or category="…" override. Refreshes every ~15 minutes.', 'wncpay' ); ?></td></tr>
					<tr><td><code>[wncpay_trip_planner]</code></td><td><?php esc_html_e( 'The build-your-itinerary wizard.', 'wncpay' ); ?></td><td><?php esc_html_e( 'No attributes needed.', 'wncpay' ); ?></td></tr>
					<tr><td><code>[wncpay_gift_designer]</code></td><td><?php esc_html_e( 'The gift card designer + purchase flow.', 'wncpay' ); ?></td><td><?php esc_html_e( 'Attribute table below.', 'wncpay' ); ?></td></tr>
					<tr><td><code>[wncpay_how_it_works]</code></td><td><?php esc_html_e( 'The planner\'s "How it works" explainer page.', 'wncpay' ); ?></td><td><?php esc_html_e( 'No attributes needed.', 'wncpay' ); ?></td></tr>
					<tr><td><code>[wncpay_pay reference="pr_…"]</code></td><td><?php esc_html_e( 'A specific payment request\'s pay page.', 'wncpay' ); ?></td><td><?php esc_html_e( 'Rarely needed on public pages; for one-off landing pages. reference = the platform payment-request reference.', 'wncpay' ); ?></td></tr>
					<tr><td><code>[wncpay_embed path="/…"]</code></td><td><?php esc_html_e( 'ANY platform path — future-proof generic embed.', 'wncpay' ); ?></td><td><?php esc_html_e( 'Every attribute except path/min_height/title/mode becomes a URL parameter.', 'wncpay' ); ?></td></tr>
				</tbody>
			</table>
			<p class="description"><?php esc_html_e( 'All shortcodes accept min_height (px shown until the embed reports its height), title (screen-reader label of the frame), and mode="window|auto" where a mode makes sense. The catalog and single-tour elements default to window mode. Forms and popups inside any embed expand over the whole page automatically while open.', 'wncpay' ); ?></p>

			<h3 style="margin-top:1.2em;"><?php esc_html_e( 'Gift card designer — attributes', 'wncpay' ); ?></h3>
			<p><code>[wncpay_gift_designer]</code> <?php esc_html_e( 'works with no attributes at all. Everything below is optional:', 'wncpay' ); ?></p>
			<table class="widefat striped" style="max-width:860px;">
				<thead><tr><th style="width:170px;"><?php esc_html_e( 'Attribute', 'wncpay' ); ?></th><th><?php esc_html_e( 'What it does', 'wncpay' ); ?></th><th style="width:280px;"><?php esc_html_e( 'Example', 'wncpay' ); ?></th></tr></thead>
				<tbody>
					<tr><td><code>amount</code></td><td><?php esc_html_e( 'Pre-selects the voucher amount (₪, minimum 200).', 'wncpay' ); ?></td><td><code>[wncpay_gift_designer amount="750"]</code></td></tr>
					<tr><td><code>matchkey</code></td><td><?php esc_html_e( 'Shows a specific tour\'s photo card by its match key (the office knows tours by match key).', 'wncpay' ); ?></td><td><code>[wncpay_gift_designer matchkey="masada-sunrise"]</code></td></tr>
					<tr><td><code>product</code></td><td><?php esc_html_e( 'Shows a specific catalog product\'s card by product id (wins over matchkey).', 'wncpay' ); ?></td><td><code>[wncpay_embed path="/gift" product="abc123"]</code></td></tr>
					<tr><td><code>dealid</code></td><td><?php esc_html_e( 'Files the purchase on an existing CRM deal (numeric Zoho deal id).', 'wncpay' ); ?></td><td><code>[wncpay_gift_designer dealid="123456789012"]</code></td></tr>
					<tr><td><code>name</code> / <code>email</code> / <code>phone</code></td><td><?php esc_html_e( 'Prefill the buyer\'s details (e.g. from a campaign landing page).', 'wncpay' ); ?></td><td><code>[wncpay_gift_designer email="a@b.com"]</code></td></tr>
					<tr><td><code>min_height</code></td><td><?php esc_html_e( 'Height in px shown until the embed reports its real height (default 900).', 'wncpay' ); ?></td><td><code>[wncpay_gift_designer min_height="1200"]</code></td></tr>
					<tr><td><code>title</code></td><td><?php esc_html_e( 'Accessible title of the frame (screen readers).', 'wncpay' ); ?></td><td><code>[wncpay_gift_designer title="Gift card"]</code></td></tr>
				</tbody>
			</table>

			<h3 style="margin-top:1.2em;"><?php esc_html_e( 'Generic embed', 'wncpay' ); ?></h3>
			<p>
				<code>[wncpay_embed path="/gift" amount="500"]</code> —
				<?php esc_html_e( 'embeds any platform path; every attribute except path/min_height/title is passed through as a URL parameter. Useful when the platform adds new embeddable pages.', 'wncpay' ); ?>
			</p>

			<p style="margin-top:1em;"><em><?php esc_html_e( 'Good to know:', 'wncpay' ); ?></em>
				<?php esc_html_e( 'the site language (WPML) is passed automatically — the embed follows the page\'s language, no attribute needed. Attributes may be written in any case (WordPress lowercases them; the plugin maps them back). Embeds resize automatically; if you use a JavaScript delay/optimization feature (e.g. WP Rocket "Delay JavaScript execution"), add "wncpay" to its exclusion list.', 'wncpay' ); ?>
			</p>
		</div>
		<?php
	}

	/**
	 * Cart-capture section intro.
	 *
	 * @return void
	 */
	public function render_cart_section_intro(): void {
		echo '<p>' . esc_html__( 'Make the site\'s own cart icon open the platform quote cart, and keep its count badge in sync with the items visitors add. If a page has no embedded platform frame, the icon sends visitors to the Order page URL configured above.', 'wncpay' ) . '</p>';
	}

	/**
	 * Cart-capture enable field.
	 *
	 * @return void
	 */
	public function render_cart_capture_field(): void {
		printf(
			'<label><input type="checkbox" name="%s[cart_capture]" value="1" %s /> %s</label>',
			esc_attr( self::OPTION ),
			checked( '1', WNCPAY_Embed::get_option( 'cart_capture' ), false ),
			esc_html__( 'Clicking the site cart icon opens the quote cart', 'wncpay' )
		);
	}

	/**
	 * Cart selector field.
	 *
	 * @return void
	 */
	public function render_cart_selector_field(): void {
		printf(
			'<input type="text" class="regular-text code" name="%s[cart_selector]" value="%s" placeholder=".elementor-menu-cart__toggle_button, a.cart-contents" />'
			. '<p class="description">%s</p>',
			esc_attr( self::OPTION ),
			esc_attr( WNCPAY_Embed::get_option( 'cart_selector' ) ),
			esc_html__( 'Leave empty for the default (Elementor menu-cart and WooCommerce cart links).', 'wncpay' )
		);
	}

	/**
	 * Login-icon enable field.
	 *
	 * @return void
	 */
	public function render_login_icon_field(): void {
		printf(
			'<label><input type="checkbox" name="%s[login_icon]" value="1" %s /> %s</label>',
			esc_attr( self::OPTION ),
			checked( '1', WNCPAY_Embed::get_option( 'login_icon' ), false ),
			esc_html__( 'Show a small account/login icon in the site header (next to the cart and gift icons). It opens the visitor\'s account on the platform.', 'wncpay' )
		);
	}

	/**
	 * Login-icon placement selector field.
	 *
	 * @return void
	 */
	public function render_login_icon_after_field(): void {
		printf(
			'<input type="text" class="regular-text code" name="%s[login_icon_after]" value="%s" placeholder="" />'
			. '<p class="description">%s</p>',
			esc_attr( self::OPTION ),
			esc_attr( WNCPAY_Embed::get_option( 'login_icon_after' ) ),
			esc_html__( 'Optional: a CSS selector of the header element the icon should appear AFTER. Leave empty for automatic placement (after the gift-page link, else after the cart widget).', 'wncpay' )
		);
	}
}
