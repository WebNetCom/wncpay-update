<?php
/**
 * Plugin Name:       WNC Pay
 * Plugin URI:        https://github.com/WebNetCom/wncpay-plugin
 * Description:       Embed elements from your connected platform — gift card designer and more — via shortcode, Elementor widget, or block. The plugin only places secure embeds; all checkout and payment flows run on the platform.
 * Version:           0.7.2
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            WebNetCom
 * Author URI:        https://webnetcom.co.il
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wncpay
 * Domain Path:       /languages
 *
 * @package WNCPay
 */

defined( 'ABSPATH' ) || exit;

define( 'WNCPAY_VERSION', '0.7.2' );
define( 'WNCPAY_FILE', __FILE__ );
define( 'WNCPAY_PATH', plugin_dir_path( __FILE__ ) );
define( 'WNCPAY_URL', plugin_dir_url( __FILE__ ) );

require_once WNCPAY_PATH . 'includes/class-wncpay-embed.php';
require_once WNCPAY_PATH . 'includes/class-wncpay-api.php';
require_once WNCPAY_PATH . 'includes/class-wncpay-settings.php';
require_once WNCPAY_PATH . 'includes/class-wncpay-shortcodes.php';
require_once WNCPAY_PATH . 'includes/class-wncpay-blocks.php';
require_once WNCPAY_PATH . 'includes/elementor/class-wncpay-elementor.php';
require_once WNCPAY_PATH . 'includes/gateway/class-wncpay-woocommerce.php';
require_once WNCPAY_PATH . 'includes/class-wncpay-plugin.php';

/**
 * Return the main plugin instance.
 *
 * @return WNCPAY_Plugin
 */
function wncpay(): WNCPAY_Plugin {
	return WNCPAY_Plugin::instance();
}

wncpay();

/**
 * Native WordPress updates, served from the public update channel
 * (https://github.com/WebNetCom/wncpay-update — metadata JSON + built ZIPs
 * only, source stays private). When the plugin enters the wordpress.org
 * repository its update system takes over: remove this block.
 */
if ( file_exists( WNCPAY_PATH . 'lib/plugin-update-checker/plugin-update-checker.php' ) ) {
	require_once WNCPAY_PATH . 'lib/plugin-update-checker/plugin-update-checker.php';

	YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
		'https://raw.githubusercontent.com/WebNetCom/wncpay-update/main/wncpay.json',
		WNCPAY_FILE,
		'wncpay'
	);
}
